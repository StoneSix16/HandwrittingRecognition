# python3 search_tiling_BO.py \
#   --binary ./spmm_search \
#   --M 197 --K 768 --N 2304 --sparsity 0.4 --min_tile 16 \
#   --max_evals 80 --init_samples 64 --no_require_divisible \
#   --limit_candidates 20000

python3 search_tiling_sa.py \
  --binary ./spmm_search \
  --M 197 \
  --K 3072 \
  --N 768 \
  --sparsity 0.97 \
  --max_evals 1000 \
  --random_seed 42 \
  --init_temp 1.0 \
  --init 128 512 32 \
  --alpha 0.95 \
  --no_require_divisible \
  --min_tile 16


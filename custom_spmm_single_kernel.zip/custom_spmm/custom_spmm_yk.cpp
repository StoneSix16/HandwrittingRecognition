// optimized: acc_tile init moved outside kb loop, memcpy copy, reuse acc_tile per (cb,rb)
#include "MKL_Sparse_Methods.h"
#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>

// portable aligned alloc/free
static inline void* portable_aligned_alloc(size_t alignment, size_t size) {
    if (size == 0) return nullptr;
    size_t extra = alignment - 1 + sizeof(void*);
    void* raw = malloc(size + extra);
    if (!raw) return nullptr;
    uintptr_t raw_addr = (uintptr_t)raw + sizeof(void*);
    uintptr_t aligned = (raw_addr + (alignment - 1)) & ~(alignment - 1);
    void** store = (void**)(aligned - sizeof(void*));
    *store = raw;
    return (void*)aligned;
}
static inline void portable_aligned_free(void* p) {
    if (!p) return;
    void** store = (void**)((uintptr_t)p - sizeof(void*));
    void* raw = *store;
    free(raw);
}

#if defined(_MSC_VER)
static inline void prefetch_read(const void* p) { _mm_prefetch((const char*)p, _MM_HINT_T0); }
#else
static inline void prefetch_read(const void* p) { __builtin_prefetch(p, 0, 1); }
#endif


bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_B_stationary(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        float* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            if (Ai[j] != 0.0f) ++c;
        }
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float>   val    ((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    const double util_ratio = 0.5;
    const int target_bytes  = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 384, Nb = std::min(colsC, 32), Rb = 64;

    // if (rowsA == 197 && colsA == 768 && colsC == 768)      { Rb = 128, Kc = 256, Nb = 32; }
    // else if (rowsA == 197 && colsA == 768 && colsC == 2304) { Rb = 128, Kc = 128, Nb = 64; }
    // else if (rowsA == 197 && colsA == 768 && colsC == 3072) { Rb = 128, Kc = 512, Nb = 64; }
    // else if (rowsA == 197 && colsA == 3072 && colsC == 768) { Rb = 128, Kc = 768, Nb = 16; }

    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));

    const MKL_INT* row_ptr_p = row_ptr.data();
    const MKL_INT* col_idx_p = col_idx.data();
    const float*   val_p     = val.data();
    const float*   denseB_p  = denseB;
    float*         denseC_p  = denseC;

    // printf("===============\n");

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int cb = 0; cb < colsC; cb += Nb) {
        int nb_eff = std::min(Nb, colsC - cb);
        if (nb_eff <= 0) continue;

        const int nb_pad = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
        const int acc_elems_per_row = nb_pad; 
        const int vec_end = nb_pad;         

        size_t stripe_elems = (size_t)colsA * (size_t)nb_pad;
        if (stripe_elems == 0) continue;

        void* stripe_tmp = portable_aligned_alloc(ACC_ALIGN, stripe_elems * sizeof(float));
        bool  stripe_portable = true;
        if (!stripe_tmp) {
            stripe_tmp = malloc(stripe_elems * sizeof(float));
            stripe_portable = false;
            if (!stripe_tmp) continue;
        }
        float* packed_stripe = (float*)stripe_tmp;

        for (int k = 0; k < colsA; ++k) {
            const float* src = denseB_p + (size_t)k * (size_t)colsC + (size_t)cb;
            float*       dst = packed_stripe + (size_t)k * (size_t)nb_pad;
            if (nb_eff > 0) std::memcpy(dst, src, sizeof(float) * (size_t)nb_eff);
            for (int t = nb_eff; t < nb_pad; ++t) dst[t] = 0.0f;
        }

        for (int rb = 0; rb < rowsA; rb += Rb) {
            int rb_eff = std::min(Rb, rowsA - rb);
            if (rb_eff <= 0) continue;

            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool  acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
                if (!acc_tile_buf_tmp) {
                    continue;
                }
            }
            float* acc_tile = (float*)acc_tile_buf_tmp;

            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow    = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* destrow = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) std::memcpy(destrow, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) destrow[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                if (kc_eff <= 0) continue;
                int kblock_end = kb + kc_eff;

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr_p[i], end = row_ptr_p[i + 1];
                    if (start >= end) continue;

                    MKL_INT* base = col_idx.data(); 
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, (MKL_INT)kb);
                    MKL_INT* p1 = std::lower_bound(p0, e, (MKL_INT)kblock_end);
                    MKL_INT it0 = (MKL_INT)(p0 - base);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    for (MKL_INT p = it0; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];  // [kb, kblock_end)
                        float   v     = val_p[p];

                        const float* Brow = packed_stripe + (size_t)k_col * (size_t)nb_pad;

                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow    + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                    }
                } // local_i
            } // kb

            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow   = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* srcrow = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_load_ps(srcrow + j);   
                        _mm256_storeu_ps(Crow + j, tmpv);     
                    for (; j < nb_eff; ++j) Crow[j] = srcrow[j];
                }
            } // rb
            if (acc_tile_buf_portable) portable_aligned_free(acc_tile);
            else                        free(acc_tile);
        } // cb
        if (stripe_portable) portable_aligned_free(packed_stripe);
        else                 free(packed_stripe);
    }
    return true;
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        float* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            c += (Ai[j] != 0.0f);
        }
        rowCounts[i] = c;
    }

    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    float density = (float)nnz/(float)(rowsA*colsA);
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) {
                int addr = base + off; 
                col_idx[addr] = (MKL_INT)j; 
                val[addr] = x; 
                ++off; 
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (build CSR): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (C set): %.6f s\n",
    //    diff.count());


       // 3) tiling params
    // t_start = std::chrono::steady_clock::now();
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (tiling): %.6f s\n",
    //    diff.count());


    // t_start = std::chrono::steady_clock::now();
    // printf("density=%f\n",density);
    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const float* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }


            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile_buf_tmp) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp); }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (calculation): %.6f s\n",
    //    diff.count());

    return true;
}


inline __m256 apply_sign_scalar(__m256 v, int8_t x) {
    static const __m256 sign_mask = _mm256_set1_ps(-0.0f);
    if (x == 1) {
        return v;
    } else {
        return _mm256_xor_ps(v, sign_mask);
    }
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    float density = (float)nnz/(float)(rowsA*colsA);
    std::vector<int16_t> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            int8_t x = Ai[j];
            if (x != 0) { 
                int addr = base + off;
                col_idx[addr] = (int16_t)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 197, Kc = 96, Nb = 48;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 197, Kc = 96, Nb = 48;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }
    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304 && density > 0.4){
        Rb = 104, Kc = 160, Nb = 72;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304 && density <= 0.4){
        Rb = 136, Kc = 152, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072 && density > 0.4){
        Rb = 48, Kc = 48, Nb = 224;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072 && density <= 0.4){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }



    // if (Rb > rowsA) Rb = rowsA;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }
    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::max(16, std::min(Nb, colsC));
    // Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const int16_t* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // printf("byte=%ld\n",sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    int16_t* base = col_idx.data();
                    int16_t* s = base + start;
                    int16_t* e = base + end;

                    int16_t* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    int16_t* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        int16_t k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}


bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_search(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int Rb,
    int Kc,
    int Nb
)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<int16_t> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { 
                int addr = base + off;
                col_idx[addr] = (int16_t)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    // const double util_ratio = 0.5;
    // const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    // int Kc = 64, Nb = std::min(colsC, 64);
    // int Rb = 64;

    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 197, Kc = 96, Nb = 48;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 197, Kc = 96, Nb = 48;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }
    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 64, Kc = 128, Nb = 128;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 32, Kc = 128, Nb = 256;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }


    // if (Rb > rowsA) Rb = rowsA;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }
    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::max(16, std::min(Nb, colsC));
    // Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const int16_t* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // printf("byte=%ld\n",sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    int16_t* base = col_idx.data();
                    int16_t* s = base + start;
                    int16_t* e = base + end;

                    int16_t* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    int16_t* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        int16_t k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }
    return true;
}




bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_B_rearrange(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int Rb,
    int Kc,
    int Nb,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { 
                int addr = base + off;
                col_idx[addr] = (MKL_INT)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }
    // if (Rb > rowsA) Rb = rowsA;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }
    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::max(16, std::min(Nb, colsC));
    // Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            // int nb_eff = Nb;
            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)Nb;
            // void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            // bool packed_portable = true;
            // if (!packed_tmp) {
            //     packed_tmp = malloc(pack_elems * sizeof(float));
            //     packed_portable = false;
            // }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                int tk = kb / Kc;
                int tc = cb / Nb;
                int num_c_tiles = (colsC + Nb - 1) / Nb;
                float* tile_ptr = denseB_p + ((size_t)tk * (size_t)num_c_tiles + (size_t)tc) * pack_elems;               
                float* packedB = (float*)tile_ptr;
                // memcpy(packedB, tile_ptr, sizeof(float) * (size_t)nb_eff * (size_t)kc_eff);

                // for (int kk = 0; kk < kc_eff; ++kk) {
                //     const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                //     float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                //     memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                //     // printf("byte=%ld\n",sizeof(float) * (size_t)nb_eff);
                // }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    // if(local_i % 2 == 0){
                        MKL_INT p = it0;
                        // singletons
                        for (; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p[p];
                            float v = val_p[p];
                            const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                            __m256 vv = _mm256_set1_ps(v);
                            int j = 0;
                            for (; j < vec_end; j += VEC_WIDTH) {
                                __m256 accv = _mm256_load_ps(acc_row + j);
                                __m256 bvec = _mm256_loadu_ps(Brow + j);
                                accv = _mm256_fmadd_ps(vv, bvec, accv);
                                _mm256_store_ps(acc_row + j, accv);
                            }
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                            }
                        } // singletons
                    // }
                    // else{
                    //     MKL_INT p = it1-1;
                    //     // singletons
                    //     for (; p >= it0; --p) {
                    //         MKL_INT k_col = col_idx_p[p];
                    //         float v = val_p[p];
                    //         const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                    //         __m256 vv = _mm256_set1_ps(v);
                    //         int j = 0;
                    //         for (; j < vec_end; j += VEC_WIDTH) {
                    //             __m256 accv = _mm256_load_ps(acc_row + j);
                    //             __m256 bvec = _mm256_loadu_ps(Brow + j);
                    //             accv = _mm256_fmadd_ps(vv, bvec, accv);
                    //             _mm256_store_ps(acc_row + j, accv);
                    //         }
                    //         if (vec_end < nb_eff) {
                    //             for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                    //         }
                    //     } // singletons
                    // }
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            // if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}



bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_packB(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            int Kblocks = (colsA + Kc - 1) / Kc;
            int Nblocks = (colsC + Nb - 1) / Nb;

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                
                int kb_block = kb / Kc;
                int cb_block = cb / Nb;
                size_t block_id = (size_t)kb_block * (size_t)Nblocks + (size_t)cb_block;
                // pointer to the start of this Kc x Nc packed block
                const float* packed_block = denseB_p + block_id * (size_t)Kc * (size_t)Nb;

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        size_t row_offset = (size_t)(k_col - kb) * (size_t)Nb;
                        const float* Brow = packed_block + row_offset;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_loadu_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}


bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_int(
    int8_t* denseA,
    int8_t* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    float density = (float)nnz/(float)(rowsA*colsA);
    std::vector<int16_t> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            int8_t x = Ai[j];
            if (x != 0) { 
                int addr = base + off;
                col_idx[addr] = (int16_t)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304 && density > 0.4){
        Rb = 104, Kc = 160, Nb = 72;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304 && density <= 0.4){
        Rb = 136, Kc = 152, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072 && density > 0.4){
        Rb = 48, Kc = 48, Nb = 224;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072 && density <= 0.4){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }



    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const int16_t* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            int8_t* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(int32_t));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(int8_t));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(int8_t));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(int32_t) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            std::vector<MKL_INT> cursor(rb_eff);
            for (int local_i = 0; local_i < rb_eff; ++local_i) cursor[local_i] = row_ptr_p[rb + local_i];

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                int8_t* packedB = (int8_t*)packed_tmp;
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const int8_t* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    int8_t* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(int8_t) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    int16_t* base = col_idx.data();
                    int16_t* s = base + start;
                    int16_t* e = base + end;

                    int16_t* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    int16_t* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        int16_t k_col = col_idx_p[p];
                        int8_t v8 = val_p[p]; // ∈ {-1, +1}
                        const int8_t* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;

                        int j = 0;
                        // sign = +1 或 -1（int32）
                        int32_t sign = (int32_t)v8;
                        __m256i sign_vec = _mm256_set1_epi32(sign);

                        for (; j < vec_end; j += VEC_WIDTH) {
                            // load 8 int8 -> widen to 8 int32
                            // 注意：_mm_loadl_epi64 从内存加载 8 字节到 128-bit 寄存器低位
                            __m128i b8  = _mm_loadl_epi64((const __m128i*)(Brow + j));      // loads 8 bytes
                            __m256i b32 = _mm256_cvtepi8_epi32(b8);                         // widen to 8 x i32

                            // prod = sign * b32  (int32)
                            __m256i prod_i32 = _mm256_mullo_epi32(sign_vec, b32);

                            // 转为 float
                            __m256 prod_f = _mm256_cvtepi32_ps(prod_i32);

                            // load current float acc, add, store
                            __m256 acc_f = _mm256_loadu_ps((const float*)(acc_row + j));
                            acc_f = _mm256_add_ps(acc_f, prod_f);
                            _mm256_storeu_ps((float*)(acc_row + j), acc_f);
                        }

                        // tail 标量处理
                        for (; j < nb_eff; ++j) {
                            // 注意 Brow[j] 为 int8_t，sign 为 ±1
                            acc_row[j] += (float)(sign * (int)Brow[j]);
                        }
                    } // end singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (packed_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_high_sparsity(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        float* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    int vec_end = (colsC / VEC_WIDTH) * VEC_WIDTH;

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int rb = 0; rb < rowsA; ++rb) {
        // float* B_row_buffer = (float*)portable_aligned_alloc(ACC_ALIGN, sizeof(float)*colsC);
        MKL_INT start = row_ptr[rb], end = row_ptr[rb + 1];
        // float* C_row_buffer = (float*)portable_aligned_alloc(ACC_ALIGN, sizeof(float)*colsC);
        float* Crow = denseC + (size_t)(rb) * (size_t)colsC;
        // memcpy(C_row_buffer, Crow, sizeof(float)*colsC);

        MKL_INT p = start;
        // singletons
        for (; p < end; ++p) {
            MKL_INT k_col = col_idx[p];
            float v = val[p];
            const float* Brow = denseB + (size_t)(k_col) * (size_t)colsC;
            // memcpy(B_row_buffer, Brow, sizeof(float)*colsC);
            __m256 vv = _mm256_set1_ps(v);
            int j = 0;
            for (; j < vec_end; j += VEC_WIDTH) {
                __m256 accv = _mm256_loadu_ps(Crow + j);
                __m256 bvec = _mm256_loadu_ps(Brow + j);
                accv = _mm256_fmadd_ps(vv, bvec, accv);
                _mm256_storeu_ps(Crow + j, accv);
            }
            if (vec_end < colsC) {
                for (int jj = vec_end; jj < colsC; ++jj) Crow[jj] += v * Brow[jj];
            }
        } // singletons
    }

    return true;
}




uint8_t csr_value_encode(float A, float B, float C, float D) {
    int A1 = A > 0 ? 1 : 0;
    int B1 = B > 0 ? 1 : 0;
    int C1 = C > 0 ? 1 : 0;
    int D1 = D > 0 ? 1 : 0;

    int A2 = A < 0 ? 1 : 0;
    int B2 = B < 0 ? 1 : 0;
    int C2 = C < 0 ? 1 : 0;
    int D2 = D < 0 ? 1 : 0;

    uint8_t result; // 高4位是pos，低四位是neg
    result = ((A1 << 7) + (B1 << 6) + (C1 << 5) + (D1 << 4)) + ((A2 << 3) + (B2 << 2) + (C2 << 1) + D2);
    return result;
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_LUT(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j){
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<uint8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j) {
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) {
                int pos = base + off;
                col_idx[pos] = j;
                // 考虑不能被4整除的情况
                int t = std::min((j + 1) * LWIDTH, colsA) - j * LWIDTH;
                int jj = j * LWIDTH;
                // printf("Ai[jj]=%d, Ai[jj + 1]=%d, Ai[jj + 2]=%d, Ai[jj + 3]=%d\n",Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                if (t == LWIDTH)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                else if (t == LWIDTH - 1)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], 0);
                else if (t == LWIDTH - 2)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], 0, 0);
                else if (t == LWIDTH - 3)
                    val[pos] = csr_value_encode(Ai[jj], 0, 0, 0);
                ++off;
            }
        }
    }
    colsA = (colsA + LWIDTH - 1) / LWIDTH; // calculation of colsA reduce LWIDTH times
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    // 2) zero C
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 128, Kc = 128, Nb = 64;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 128, Kc = 512, Nb = 64;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }

    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("rowsA=%d,colsA=%d,colsC=%d,Kc=%d,Nb=%d,Rb=%d\n",rowsA,colsA,colsC,Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const uint8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)LWIDTH_POW2 * (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }


            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            // for (int local_i = 0; local_i < rb_eff; ++local_i) {
            //     int i = rb + local_i;
            //     float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
            //     float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
            //     if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
            //     for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            // }

            std::vector<MKL_INT> cursor(rb_eff);
            for (int local_i = 0; local_i < rb_eff; ++local_i) cursor[local_i] = row_ptr_p[rb + local_i];

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                // float* packedB = (float*)packed_tmp;
                // for (int lut_idx=0; lut_idx < LWIDTH_POW2; ++lut_idx){
                //     for (int kk = 0; kk < kc_eff; ++kk) {
                //         const float* Brow = denseB_p + (size_t)lut_idx * (size_t)colsA * (size_t)colsC + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                //         float* dest = packedB + (size_t)lut_idx * (size_t)kc_eff * (size_t)nb_eff + (size_t)kk * (size_t)nb_eff;
                //         if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                //     }
                // }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    // MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    // if (start >= end) continue;
                    // MKL_INT* base = col_idx.data();
                    // MKL_INT* s = base + start;
                    // MKL_INT* e = base + end;

                    // MKL_INT* p0 = std::lower_bound(s, e, kb);
                    // MKL_INT it0 = (MKL_INT)(p0 - base);

                    // MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    // MKL_INT it1 = (MKL_INT)(p1 - base);

                    // MKL_INT p = it0;
                    // // singletons
                    // for (; p < it1; ++p) {
                    //     MKL_INT k_col = col_idx_p[p];
                    //     uint8_t v = val_p[p];
                    //     uint8_t pos_idx = (v >> LWIDTH) & 0x0F;
                    //     uint8_t neg_idx = v & 0x0F;
                    //     const float* Brow_pos = packedB + (size_t)pos_idx * (size_t)kc_eff * (size_t)nb_eff + (size_t)(k_col - kb) * (size_t)nb_eff;
                    //     const float* Brow_neg = packedB + (size_t)neg_idx * (size_t)kc_eff * (size_t)nb_eff + (size_t)(k_col - kb) * (size_t)nb_eff;

                    //     // const float* Brow_pos = denseB_p + (size_t)pos_idx * (size_t)colsA * (size_t)colsC + (size_t)k_col * (size_t)colsC + (size_t)cb;
                    //     // const float* Brow_neg = denseB_p + (size_t)neg_idx * (size_t)colsA * (size_t)colsC + (size_t)k_col * (size_t)colsC + (size_t)cb;
                    //     // printf("v=%d, pos_idx=%d, neg_idx=%d, kc_eff=%d, nb_eff=%d, pos_offset=%d, neg_offset=%d, k_col=%d, kb=%d, rb=%d, cb=%d, local_i=%d\n",
                    //     //                             v, pos_idx,neg_idx,kc_eff,nb_eff,int(Brow_pos-denseB_p),int(Brow_neg-denseB_p),k_col,kb,rb,cb,local_i);
                    //     int j = 0;
                    //     for (; j < vec_end; j += VEC_WIDTH) {
                    //         __m256 accv = _mm256_load_ps(acc_row + j);
                    //         __m256 bvec_pos = _mm256_load_ps(Brow_pos + j);
                    //         __m256 bvec_neg = _mm256_load_ps(Brow_neg + j);
                    //         accv = _mm256_add_ps(accv, _mm256_sub_ps(bvec_pos, bvec_neg));
                    //         _mm256_store_ps(acc_row + j, accv);
                    //     }
                    //     if (vec_end < nb_eff) {
                    //         for (int jj = vec_end; jj < nb_eff; ++jj){
                    //             acc_row[jj] += Brow_pos[jj] - Brow_neg[jj];
                    //         }
                    //     }
                    // } // singletons
                }
            }
            // for (int local_i = 0; local_i < rb_eff; ++local_i) {
            //     int i = rb + local_i;
            //     float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
            //     float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
            //     int j = 0;
            //     for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
            //         __m256 tmpv = _mm256_load_ps(src_row + j);
            //         _mm256_storeu_ps(Crow + j, tmpv);
            //     }
            //     for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            // }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}


bool CSRxDenseLUT_new_zjx(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC)
{
    // 1) build CSR 
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j){
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;     // 组内全0则跳过存储
                }
                // printf("Ai[jj]=%d, nonZero=%d\n",Ai[jj], nonZero);
            }
            if (nonZero) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<uint8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j) {
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) {
                int pos = base + off;
                col_idx[pos] = j;
                // 考虑不能被4整除的情况
                int t = std::min((j + 1) * LWIDTH, colsA) - j * LWIDTH;
                int jj = j * LWIDTH;
                // printf("Ai[jj]=%d, Ai[jj + 1]=%d, Ai[jj + 2]=%d, Ai[jj + 3]=%d\n",Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                if (t == LWIDTH)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                else if (t == LWIDTH - 1)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], 0);
                else if (t == LWIDTH - 2)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], 0, 0);
                else if (t == LWIDTH - 3)
                    val[pos] = csr_value_encode(Ai[jj], 0, 0, 0);
                ++off;
            }
        }
    }
    colsA = (colsA + LWIDTH - 1) / LWIDTH; // calculation of colsA reduce LWIDTH times

    // 2) zero C
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);

    // 3) tiling params
    int Rb, Kc, Nb;
    // printf("rowsA=%d, colsA=%d, colsC=%d\n",rowsA, colsA, colsC);
    if (rowsA == 197 && colsA == 192 && colsC == 2304) {
        Rb = 64, Kc = 64, Nb = 32;
    }
    else if (rowsA == 197 && colsA == 192 && colsC == 768) {
        Rb = 64, Kc = 128, Nb = 48;
    }
    else if (rowsA == 197 && colsA == 192 && colsC == 3072) {
        Rb = 64, Kc = 32, Nb = 48;
    }
    else {
        Rb = Kc = Nb = 64;
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));

    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(1)
    for (int cb = 0; cb < colsC; cb += Nb) {
        const MKL_INT* row_ptr_p = row_ptr.data();
        const MKL_INT* col_idx_p = col_idx.data();
        const uint8_t* val_p = val.data();
        float* denseB_p = denseB;
        float* denseC_p = denseC;

        int nb_eff = std::min(Nb, colsC - cb);
        int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
        int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
        size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
        size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;

        void* heap_acc_tile_buf_tmp = nullptr;
        bool acc_tile_buf_portable = true;
        heap_acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
        if (!heap_acc_tile_buf_tmp) {
            heap_acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
            acc_tile_buf_portable = false;
        }
        float *acc_tile_buf = (float*)heap_acc_tile_buf_tmp;
        float* acc_tile = acc_tile_buf;

        for (int kb = 0; kb < colsA; kb += Kc) {
            int kc_eff = std::min(Kc, colsA - kb);
            int kblock_end = kb + kc_eff;

            void* heap_LUT_tile_buf_tmp = nullptr;
            bool LUT_tile_buf_portable = true;
            size_t LUT_tile_elems = LWIDTH_POW2 * kc_eff * nb_eff;
            heap_LUT_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, LUT_tile_elems * sizeof(float));
            if (!heap_LUT_tile_buf_tmp) {
                heap_LUT_tile_buf_tmp = malloc(LUT_tile_elems * sizeof(float));
                LUT_tile_buf_portable = false;
            }
            float *LUT_tile_buf = (float*)heap_LUT_tile_buf_tmp;

            // 预计算常用值
            const size_t lut_stride = (size_t)colsA * (size_t)colsC;
            const size_t col_stride = (size_t)colsC;
            size_t tile_size = kc_eff * nb_eff;

            for(int lut_idx=0; lut_idx < LWIDTH_POW2; ++lut_idx){
                for(int kk = 0; kk < kc_eff; ++kk){
                    memcpy(LUT_tile_buf + (size_t)(lut_idx * tile_size) + (size_t)(kk*nb_eff), 
                    denseB_p + (size_t)lut_idx * lut_stride + (size_t)(kk+kb) * col_stride + cb, 
                    (size_t)nb_eff*sizeof(float));
                }
            }

            for (int rb = 0; rb < rowsA; rb += Rb) {
                int rb_eff = std::min(Rb, rowsA - rb);
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) {
                        memcpy(dest_row, Crow, sizeof(float) * nb_eff);
                    }
                    if (acc_elems_per_row > nb_eff) {
                        memset(dest_row + nb_eff, 0, sizeof(float) * (acc_elems_per_row - nb_eff));
                    }
                }

                if (kc_eff == 0 || nb_eff == 0) continue;

                // 预取指令
                #ifdef __INTEL_COMPILER
                #pragma vector nontemporal
                #endif

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;

                    const MKL_INT* col_start = col_idx_p + start;
                    const MKL_INT* col_end = col_idx_p + end;
                    const MKL_INT* p0 = std::lower_bound(col_start, col_end, kb);
                    const MKL_INT* p1 = std::lower_bound(p0, col_end, kblock_end);
                    const uint8_t* val_ptr = val_p + (p0 - col_idx_p);

                    for (const MKL_INT* p = p0; p < p1; ++p) {
                        MKL_INT k_col = *p;
                        uint8_t v = *val_ptr++;
                        uint8_t pos_idx = (v >> LWIDTH) & 0x0F;
                        uint8_t neg_idx = v & 0x0F;

                        const float* Brow_pos = LUT_tile_buf + 
                            (size_t)pos_idx * tile_size +
                            (size_t)(k_col - kb) * nb_eff;

                        const float* Brow_neg = LUT_tile_buf + 
                            (size_t)neg_idx * tile_size +
                            (size_t)(k_col - kb) * nb_eff;

                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bpos = _mm256_loadu_ps(Brow_pos + j);
                            __m256 bneg = _mm256_loadu_ps(Brow_neg + j);
                            // 优化9: 使用FMA指令（如果可用）
                            #ifdef __FMA__
                            accv = _mm256_fmadd_ps(_mm256_set1_ps(1.0f), 
                                                  _mm256_sub_ps(bpos, bneg), 
                                                  accv);
                            #else
                            accv = _mm256_add_ps(accv, _mm256_sub_ps(bpos, bneg));
                            #endif

                            _mm256_store_ps(acc_row + j, accv);
                        }

                        for (; j < nb_eff; ++j) {
                            acc_row[j] += Brow_pos[j] - Brow_neg[j];
                        }
                    }
                }
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    // 向量化存储
                    int j = 0;
                    #ifdef __AVX2__
                    for (; j + VEC_WIDTH <= nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_load_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    #endif

                    // 标量处理剩余元素
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }                
            }
            portable_aligned_free(heap_LUT_tile_buf_tmp); 
        }
        portable_aligned_free(heap_acc_tile_buf_tmp); 
    }

    return true;
}

bool CSRxDenseLUT_new_zjx_inner(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC)
{
    // 1) build CSR 
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j){
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;     // 组内全0则跳过存储
                }
            }
            if (nonZero) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<uint8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j) {
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) {
                int pos = base + off;
                col_idx[pos] = j;
                // 考虑不能被4整除的情况
                int t = std::min((j + 1) * LWIDTH, colsA) - j * LWIDTH;
                int jj = j * LWIDTH;
                // printf("Ai[jj]=%d, Ai[jj + 1]=%d, Ai[jj + 2]=%d, Ai[jj + 3]=%d\n",Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                if (t == LWIDTH)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                else if (t == LWIDTH - 1)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], 0);
                else if (t == LWIDTH - 2)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], 0, 0);
                else if (t == LWIDTH - 3)
                    val[pos] = csr_value_encode(Ai[jj], 0, 0, 0);
                ++off;
            }
        }
    }
    colsA = (colsA + LWIDTH - 1) / LWIDTH; // calculation of colsA reduce LWIDTH times

    // 2) zero C
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);

    // 3) tiling params
    int Rb, Kc, Nb;
    if (rowsA == 197 && colsA == 768 && colsC == 2304) {
        Rb = 256, Kc = 512, Nb = 32;
    }
    else if (rowsA == 197 && colsA == 768 && colsC == 768) {
        Rb = 4, Kc = 32, Nb = 256;
    }
    else if (rowsA == 197 && colsA == 768 && colsC == 3072) {
        Rb = 4, Kc = 256, Nb = 256;
    }
    else {
        Rb = Kc = Nb = 64;
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));

    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const uint8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;

            void* heap_acc_tile_buf_tmp = nullptr;
            bool acc_tile_buf_portable = true;
            heap_acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            if (!heap_acc_tile_buf_tmp) {
                heap_acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float *acc_tile_buf = (float*)heap_acc_tile_buf_tmp;
            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf;

            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) {
                    memcpy(dest_row, Crow, sizeof(float) * nb_eff);
                }
                if (acc_elems_per_row > nb_eff) {
                    memset(dest_row + nb_eff, 0, sizeof(float) * (acc_elems_per_row - nb_eff));
                }
            }

            // 预计算常用值
            const size_t lut_stride = (size_t)colsA * (size_t)colsC;
            const size_t col_stride = (size_t)colsC;

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;

                // 预取指令
                #ifdef __INTEL_COMPILER
                #pragma vector nontemporal
                #endif

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;

                    const MKL_INT* col_start = col_idx_p + start;
                    const MKL_INT* col_end = col_idx_p + end;
                    const MKL_INT* p0 = std::lower_bound(col_start, col_end, kb);
                    const MKL_INT* p1 = std::lower_bound(p0, col_end, kblock_end);
                    const uint8_t* val_ptr = val_p + (p0 - col_idx_p);

                    for (const MKL_INT* p = p0; p < p1; ++p) {
                        MKL_INT k_col = *p;
                        uint8_t v = *val_ptr++;
                        uint8_t pos_idx = (v >> LWIDTH) & 0x0F;
                        uint8_t neg_idx = v & 0x0F;

                        const float* Brow_pos = denseB_p + 
                            (size_t)pos_idx * lut_stride +
                            (size_t)k_col * col_stride + cb;

                        const float* Brow_neg = denseB_p + 
                            (size_t)neg_idx * lut_stride +
                            (size_t)k_col * col_stride + cb;

                        int j = 0;
                        #ifdef __AVX2__
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bpos = _mm256_loadu_ps(Brow_pos + j);
                            __m256 bneg = _mm256_loadu_ps(Brow_neg + j);

                            // 优化9: 使用FMA指令（如果可用）
                            #ifdef __FMA__
                            accv = _mm256_fmadd_ps(_mm256_set1_ps(1.0f), 
                                                  _mm256_sub_ps(bpos, bneg), 
                                                  accv);
                            #else
                            accv = _mm256_add_ps(accv, _mm256_sub_ps(bpos, bneg));
                            #endif

                            _mm256_store_ps(acc_row + j, accv);
                        }
                        #endif

                        for (; j < nb_eff; ++j) {
                            acc_row[j] += Brow_pos[j] - Brow_neg[j];
                        }
                    }
                }
            }

            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                // 向量化存储
                int j = 0;
                #ifdef __AVX2__
                for (; j + VEC_WIDTH <= nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                #endif

                // 标量处理剩余元素
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }

            portable_aligned_free(heap_acc_tile_buf_tmp); 
        }
    }

    return true;
}

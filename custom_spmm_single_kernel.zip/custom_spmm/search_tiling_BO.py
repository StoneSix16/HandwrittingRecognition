#!/usr/bin/env python3
import argparse
import math
import os
import random
import subprocess
import sys
import time
from typing import List, Tuple, Optional, Dict, Any

import numpy as np
from sklearn.gaussian_process import GaussianProcessRegressor
from sklearn.gaussian_process.kernels import ConstantKernel as C, Matern, WhiteKernel
from sklearn.exceptions import ConvergenceWarning
import warnings
from scipy.stats import norm

warnings.filterwarnings("ignore", category=ConvergenceWarning)


# =========================
# Utils
# =========================
def divisors(n: int, min_val: int = 1, max_val: Optional[int] = None) -> List[int]:
    """Return sorted divisors of n limited to [min_val, max_val]."""
    if n <= 0:
        return []
    if max_val is None:
        max_val = n
    divs = set()
    r = int(math.isqrt(n))
    for i in range(1, r + 1):
        if n % i == 0:
            j = n // i
            if min_val <= i <= max_val:
                divs.add(i)
            if min_val <= j <= max_val:
                divs.add(j)
    return sorted(divs)


def call_binary(binary_path: str,
                M: int, K: int, N: int, sparsity: float,
                tM: int, tK: int, tN: int,
                timeout: float = 60.0) -> float:
    """
    Call the C program and parse latency (float) from stdout.
    Expects the program prints a float somewhere in stdout.
    Raises informative RuntimeError on failure/timeouts.
    """
    cmd = [
        binary_path,
        str(sparsity), str(M), str(K), str(N),
        str(tM), str(tK), str(tN)
    ]
    try:
        res = subprocess.run(
            cmd, capture_output=True, text=True, timeout=timeout, check=False
        )
    except subprocess.TimeoutExpired as e:
        raise RuntimeError(f"Process timeout: {' '.join(cmd)}") from e

    if res.returncode != 0:
        stderr = (res.stderr or "").strip()
        out = (res.stdout or "").strip()
        raise RuntimeError(f"Program returned non-zero code {res.returncode}. stdout: {out!r} stderr: {stderr!r}")

    out = (res.stdout or "").strip()
    # try parse first float-like token (robust to extra text)
    token = None
    for tok in out.replace(",", " ").split():
        try:
            token = float(tok)
            break
        except ValueError:
            # try to strip non-numeric suffix/prefix, e.g., "latency=0.123"
            s = ''.join(ch if (ch.isdigit() or ch in '.-+eE') else ' ' for ch in tok)
            for sub in s.split():
                try:
                    token = float(sub)
                    break
                except ValueError:
                    continue
            if token is not None:
                break

    if token is None or (not math.isfinite(token)):
        raise ValueError(f"Could not parse latency (float) from stdout: {out!r}")
    return float(token)


# Expected Improvement acquisition for minimization
def expected_improvement(mu: np.ndarray, sigma: np.ndarray, best_y: float, xi: float = 0.01) -> np.ndarray:
    """
    EI(x) = E[max(0, best_y - Y(x) - xi)] for minimization
    """
    sigma = np.maximum(sigma, 1e-12)
    imp = best_y - mu - xi
    Z = imp / sigma
    ei = imp * norm.cdf(Z) + sigma * norm.pdf(Z)
    ei[sigma <= 0.0] = 0.0
    return ei


def to_array(points: List[Tuple[int, int, int]]) -> np.ndarray:
    return np.array(points, dtype=int)


# =========================
# BO loop over a discrete candidate set
# =========================
def bo_search(
    binary_path: str,
    M: int, K: int, N: int, sparsity: float,
    max_evals: int = 60,
    init_samples: int = 12,
    random_seed: int = 0,
    limit_candidates: Optional[int] = 5000,
    min_tile: int = 1,
    max_tile_M: Optional[int] = None,
    max_tile_K: Optional[int] = None,
    max_tile_N: Optional[int] = None,
    require_divisible: bool = True,
    timeout_per_eval: float = 60.0
) -> Dict[str, Any]:
    rng = random.Random(random_seed)
    np_rng = np.random.default_rng(random_seed)

    if max_tile_M is None: max_tile_M = M
    if max_tile_K is None: max_tile_K = K
    if max_tile_N is None: max_tile_N = N

    if require_divisible:
        cand_M = divisors(M, min_tile, max_tile_M)
        cand_K = divisors(K, min_tile, max_tile_K)
        cand_N = divisors(N, min_tile, max_tile_N)
    else:
        # coarse grid if not requiring divisibility
        step = max(1, min(8, max(1, int(min(M, max_tile_M) // 16))))
        cand_M = list(range(min_tile, min(max_tile_M, M) + 1, step))
        cand_K = list(range(min_tile, min(max_tile_K, K) + 1, step))
        cand_N = list(range(min_tile, min(max_tile_N, N) + 1, step))

    # build candidates (avoid itertools if you prefer)
    candidates = []
    for a in cand_M:
        for b in cand_K:
            for c in cand_N:
                candidates.append((a, b, c))

    if not candidates:
        raise ValueError("No candidate tilings. Loosen constraints or set require_divisible=False.")

    # optionally downsample in reproducible way
    if limit_candidates is not None and len(candidates) > limit_candidates:
        idxs = np_rng.choice(len(candidates), size=limit_candidates, replace=False)
        candidates = [candidates[i] for i in idxs]

    X_all = to_array(candidates)  # shape [C, 3] ints

    # initial design
    init = min(init_samples, len(candidates))
    init_idxs = np_rng.choice(len(candidates), size=init, replace=False)
    X_init = X_all[init_idxs]  # raw int triples

    # storage
    X_evaluated = []  # raw triples (int)
    X_feat = []       # normalized features [tM/M, tK/K, tN/N]
    y_list: List[float] = []
    tried = set()

    # GP model (length scales set to rough fraction of dims)
    kernel = C(1.0, (1e-3, 1e3)) * Matern(length_scale=[max(1.0, M/4), max(1.0, K/4), max(1.0, N/4)], nu=2.5) \
             + WhiteKernel(noise_level=1e-5, noise_level_bounds=(1e-8, 1e-2))
    gpr = GaussianProcessRegressor(kernel=kernel, alpha=0.0, normalize_y=True, n_restarts_optimizer=3, random_state=random_seed)

    # evaluation cache
    eval_cache: Dict[Tuple[int, int, int], float] = {}

    def eval_point(tM: int, tK: int, tN: int) -> float:
        key = (int(tM), int(tK), int(tN))
        if key in eval_cache:
            return eval_cache[key]
        lat = call_binary(binary_path, M, K, N, sparsity, tM, tK, tN, timeout=timeout_per_eval)
        eval_cache[key] = lat
        return lat

    # evaluate initial points
    for (tM, tK, tN) in X_init.astype(int):
        key = (int(tM), int(tK), int(tN))
        if key in tried:
            continue
        try:
            y = eval_point(tM, tK, tN)
        except Exception as e:
            # if a single eval fails, continue but warn
            print(f"[WARN] initial eval failed for {key}: {e}", file=sys.stderr)
            continue
        tried.add(key)
        X_evaluated.append(key)
        X_feat.append([tM / M, tK / K, tN / N])
        y_list.append(float(y))

    if not y_list:
        raise RuntimeError("All initial evaluations failed; cannot proceed.")

    best_idx = int(np.argmin(y_list))
    best_x = tuple(X_evaluated[best_idx])
    best_y = float(y_list[best_idx])

    total_budget = min(max_evals, len(candidates))
    evals_done = len(y_list)

    # BO loop
    while evals_done < total_budget:
        # Fit GP (wrap in try/except)
        X_train = np.array(X_feat, dtype=float)
        y_train = np.array(y_list, dtype=float)
        try:
            gpr.fit(X_train, y_train)
            gp_ok = True
        except Exception as e:
            gp_ok = False
            print(f"[WARN] GP fit failed: {e}. Falling back to random selection.", file=sys.stderr)

        # remaining candidates mask
        mask_remaining = np.array([tuple(map(int, p)) not in tried for p in X_all], dtype=bool)
        if not np.any(mask_remaining):
            break
        X_remain_raw = X_all[mask_remaining].astype(int)  # shape [R,3]

        # choose next candidate
        x_next = None
        if gp_ok:
            X_remain_feat = X_remain_raw.astype(float)
            X_remain_feat[:, 0] /= M
            X_remain_feat[:, 1] /= K
            X_remain_feat[:, 2] /= N
            try:
                mu, sigma = gpr.predict(X_remain_feat, return_std=True)
                # ensure finite
                mu = np.asarray(mu, dtype=float)
                sigma = np.asarray(sigma, dtype=float)
                sigma = np.maximum(sigma, 1e-12)
                ei = expected_improvement(mu, sigma, best_y, xi=0.01)
                next_idx_local = int(np.argmax(ei))
                x_next = tuple(map(int, X_remain_raw[next_idx_local]))
            except Exception as e:
                gp_ok = False
                print(f"[WARN] GP prediction failed: {e}. Falling back to random.", file=sys.stderr)

        if not gp_ok:
            # fallback: pick the remaining candidate with best predicted mean by simple surrogate (mean of evaluated)
            # or random pick to encourage exploration
            rnd_i = int(np_rng.integers(0, len(X_remain_raw)))
            x_next = tuple(map(int, X_remain_raw[rnd_i]))

        # ensure not already tried (race-safe)
        if x_next in tried:
            # pick another random remaining
            choices = [tuple(map(int, p)) for p in X_remain_raw if tuple(map(int, p)) not in tried]
            if not choices:
                break
            x_next = random.choice(choices)

        # evaluate x_next
        try:
            y_next = eval_point(*x_next)
        except Exception as e:
            print(f"[WARN] evaluation failed for {x_next}: {e}", file=sys.stderr)
            tried.add(x_next)
            evals_done += 1
            # record a large penalty so GP learns to avoid (or skip recording)
            # we skip adding to training set to avoid poisoning; continue
            continue

        # record
        tried.add(x_next)
        X_evaluated.append(x_next)
        X_feat.append([x_next[0] / M, x_next[1] / K, x_next[2] / N])
        y_list.append(float(y_next))
        evals_done += 1

        # update best
        if y_next < best_y:
            best_y = float(y_next)
            best_x = x_next

        # optional progress print
        print(f"[INFO] eval {evals_done}/{total_budget}: {x_next} -> {y_next:.6f}. best={best_x} {best_y:.6f}")

    # prepare history
    history = [{"tiling_M": int(xx[0]), "tiling_K": int(xx[1]), "tiling_N": int(xx[2]), "latency": float(yy)}
               for xx, yy in zip(X_evaluated, y_list)]

    return {
        "best_tiling": {"tiling_M": int(best_x[0]), "tiling_K": int(best_x[1]), "tiling_N": int(best_x[2])},
        "best_latency": best_y,
        "evaluations": evals_done,
        "candidate_count": len(candidates),
        "history": history,
    }


def main():
    parser = argparse.ArgumentParser(description="Bayesian Optimization for tiling parameters over discrete candidates (divisors).")
    parser.add_argument("--binary", type=str, default="./matmul_bench", help="Path to C executable.")
    parser.add_argument("--M", type=int, required=True)
    parser.add_argument("--K", type=int, required=True)
    parser.add_argument("--N", type=int, required=True)
    parser.add_argument("--sparsity", type=float, required=True)
    parser.add_argument("--max_evals", type=int, default=60)
    parser.add_argument("--init_samples", type=int, default=12)
    parser.add_argument("--random_seed", type=int, default=0)

    parser.add_argument("--min_tile", type=int, default=1)
    parser.add_argument("--max_tile_M", type=int, default=None)
    parser.add_argument("--max_tile_K", type=int, default=None)
    parser.add_argument("--max_tile_N", type=int, default=None)
    parser.add_argument("--limit_candidates", type=int, default=5000)
    parser.add_argument("--no_require_divisible", action="store_true", help="If set, tiling does not need to divide dimensions.")
    parser.add_argument("--timeout_per_eval", type=float, default=60.0)

    args = parser.parse_args()

    result = bo_search(
        binary_path=args.binary,
        M=args.M, K=args.K, N=args.N, sparsity=args.sparsity,
        max_evals=args.max_evals,
        init_samples=args.init_samples,
        random_seed=args.random_seed,
        limit_candidates=args.limit_candidates,
        min_tile=args.min_tile,
        max_tile_M=args.max_tile_M,
        max_tile_K=args.max_tile_K,
        max_tile_N=args.max_tile_N,
        require_divisible=not args.no_require_divisible,
        timeout_per_eval=args.timeout_per_eval
    )

    best = result["best_tiling"]
    print("=== BO Result ===")
    print(f"Best tiling: (M={best['tiling_M']}, K={best['tiling_K']}, N={best['tiling_N']})")
    print(f"Best latency: {result['best_latency']:.6f} (evaluations={result['evaluations']}, candidates={result['candidate_count']})")


if __name__ == "__main__":
    main()

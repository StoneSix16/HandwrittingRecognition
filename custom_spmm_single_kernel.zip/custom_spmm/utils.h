#include <cstdio>
#include <sys/time.h>
#include <cmath>

double getTime(struct timeval start, struct timeval end);
int identical(float **A, float **B, int ma, int mb, int na, int nb);
int min(int a, int b);
void print(float **arr, int m, int n);

// 获取时间
double getTime(struct timeval start, struct timeval end) {
    long seconds = end.tv_sec - start.tv_sec;
    long microseconds = end.tv_usec - start.tv_usec;
    double time_taken = seconds + microseconds / 1e6;
    return time_taken;
}

// 判断矩阵相同，相同返回1，否则0
int identical(float **A, float **B, int ma, int mb, int na, int nb) {
    if (ma != mb || na != nb) return 0;
    for (int i = 0; i < ma; i++) {
        for (int j = 0; j < na; j++) {
            if (fabs(A[i][j] - B[i][j]) > 1e-6) return 0;
        }
    }
    return 1;
}

// 整数最小值
int min(int a, int b) {
    return (a >= b) ? b : a;
}

// 打印矩阵
void print(float **arr, int m, int n) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < n; j++) {
            printf("%f ", arr[i][j]);
        }
        printf("\n");
    }
    printf("\n");
} 


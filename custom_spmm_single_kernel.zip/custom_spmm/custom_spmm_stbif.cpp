#include "MKL_Sparse_Methods.h"
#include "stbif_spmm.h"
#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>
#include <mkl.h>
#include <mkl_spblas.h>
#define _CRT_SECURE_NO_WARNINGS


static double SparseDenseGustavsonDemoNewTernary(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseDemo(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double DenseDenseDemo(int M, int N, int K);

static double SparseDenseGustavsonDemoNewTernarySeparate(int M, int N, int K,
    int flag, float sparsity, float v_th, int T_max, int T_min);

static double SparseDenseGustavsonDemoNewTernaryFusion(int M, int N, int K,
    int flag, float sparsity, float v_th, int T_max, int T_min);    

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_fusion(
    /*SpMM*/
    int8_t* denseA, float* denseB, float* denseC, int rowsA, int colsA, int colsC,
    /*Neuron*/
    int8_t* output, float* V_t_1, float* T_t_1, float v_th, float T_max, float T_min
);

static inline void* portable_aligned_alloc(size_t alignment, size_t size) {
    if (size == 0) return nullptr;
    size_t extra = alignment - 1 + sizeof(void*);
    void* raw = malloc(size + extra);
    if (!raw) return nullptr;
    uintptr_t raw_addr = (uintptr_t)raw + sizeof(void*);
    uintptr_t aligned = (raw_addr + (alignment - 1)) & ~(alignment - 1);
    void** store = (void**)(aligned - sizeof(void*));
    *store = raw;
    return (void*)aligned;
}
static inline void portable_aligned_free(void* p) {
    if (!p) return;
    void** store = (void**)((uintptr_t)p - sizeof(void*));
    void* raw = *store;
    free(raw);
}

FILE* safe_fopen(const char* filename, const char* mode) {
#ifdef _WIN32
    FILE* fp = nullptr;
    if (fopen_s(&fp, filename, mode) != 0) {
        return nullptr;
    }
    return fp;
#else
    return fopen(filename, mode);
#endif
}

void write_csv_row(int M, int N, int K, double sparsity,
    double t1, double t2, double t3, int test_iter) {
    FILE* F = safe_fopen("output.csv", "ab");
    if (!F) {
        perror("Failed to open output.csv");
        exit(EXIT_FAILURE);
    }

    fprintf(F, "%d,%d,%d,%.6f,%.6f,%.6f,%.6f\n",
        M, N, K, sparsity,
        t1 / test_iter, t2 / test_iter, t3 / test_iter);

    fclose(F);
}


int main(int argc, char** argv)
{
    int warmup_iter = 10;
    int test_iter = 5;
    const int M = static_cast<int>(atof(argv[2])), N = static_cast<int>(atof(argv[3])), K = static_cast<int>(atof(argv[4]));
    const float v_th = static_cast<float>(atof(argv[5]));    
    int T_max = 4;
    int T_min = -4;
    float sparsity = 0.90f;
    if (argc > 1) sparsity = static_cast<float>(atof(argv[1]));
    printf("M=%d,N=%d,K=%d,sparsity=%.6f, T_max=%d, T_min=%d, v_th=%f\n", M, N, K, sparsity, T_max, T_min, v_th);

    for (int i = 0; i < warmup_iter; i++) {
        SparseDenseGustavsonDemoNewTernaryFusion(M, N, K, 0, sparsity, v_th, T_max, T_min);
    }
    double spend_time5 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time5 = spend_time5 + SparseDenseGustavsonDemoNewTernaryFusion(M, N, K, 0, sparsity, v_th, T_max, T_min);
    }
    printf("Sparse×Dense (Neuron Fusion): %.6f s\n", spend_time5 / test_iter);    

    for (int i = 0; i < warmup_iter; i++) {
        SparseDenseGustavsonDemoNewTernarySeparate(M, N, K, 0, sparsity, v_th, T_max, T_min);
    }
    double spend_time4 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time4 = spend_time4 + SparseDenseGustavsonDemoNewTernarySeparate(M, N, K, 0, sparsity, v_th, T_max, T_min);
    }
    printf("Sparse×Dense (SpMM Neuron Separate): %.6f s\n", spend_time4 / test_iter);

    for (int i = 0; i < warmup_iter; i++) {
        SparseDenseGustavsonDemoNewTernary(M, N, K, 0, sparsity);
    }
    double spend_time2 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time2 = spend_time2 + SparseDenseGustavsonDemoNewTernary(M, N, K, 0, sparsity);
    }
    printf("Sparse×Dense (Gustavson New): %.6f s\n", spend_time2 / test_iter);


    for (int i = 0; i < warmup_iter; i++) {
       SparseDenseDemo(M, N, K, 0, sparsity);
    }
    double spend_time1 = 0.0;
    for (int i = 0; i < test_iter; i++) {
       spend_time1 = spend_time1 + SparseDenseDemo(M, N, K, 0, sparsity);
    }
    printf("Sparse×Dense (fast): %.6f s\n", spend_time1 / test_iter);



    for (int i=0;i<warmup_iter;i++){
        DenseDenseDemo(M, N, K);
    }
    double spend_time3 = 0.0;
    for (int i=0;i<test_iter;i++){
       spend_time3 = spend_time3 + DenseDenseDemo(M, N, K);
    }
    printf("Dense×Dense (mkl gemm): %.6f s\n", spend_time3/test_iter);

    write_csv_row(M, N, K, sparsity, spend_time1, spend_time2, spend_time3, test_iter);
    return 0;
}

static void print_matrix(float** A, int M, int N) {
    printf("=======================%d x %d======================\n", M, N);
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            printf("%f ", A[i][j]);
        }
        printf("\n");
    }
}

bool verify_result(float** denseA, float** denseB, float** denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5) {
    // 分配存储正确结果的矩阵
    std::vector<float> correct_result_data(rowsA * colsC, 0.0f);
    float* correct_result = correct_result_data.data();

    // 传统三重循环计算正确结果
    auto start_verify = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                sum += denseA[0][i * colsA + k] * denseB[0][k * colsC + j];
            }
            correct_result[i * colsC + j] = sum;
        }
    }

    auto end_verify = std::chrono::high_resolution_clock::now();
    auto verify_time = std::chrono::duration_cast<std::chrono::microseconds>(end_verify - start_verify);

    printf("Verification computation time: %ld μs\n", verify_time.count());

    // 对比结果
    bool is_correct = true;
    int error_count = 0;
    const int max_errors_to_show = 10;

    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float diff = std::abs(correct_result[i * colsC + j] - denseC_gustavson[0][i * colsC + j]);
            if (diff > tolerance) {
                is_correct = false;
                if (error_count < max_errors_to_show) {
                    printf("ERROR at [%d][%d]: correct=%.6f, gustavson=%.6f, diff=%.6f\n",
                        i, j, correct_result[i * colsC + j], denseC_gustavson[0][i * colsC + j], diff);
                }
                error_count++;
            }
        }
    }

    // 输出结果
    if (is_correct) {
        // 输出绿色的"correct"
        printf("\033[1;32mcorrect\033[0m\n");
        printf("All %d elements matched! ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m\n");
        printf("Found %d errors out of %d elements\n", error_count, rowsA * colsC);
    }

    return is_correct;
}

/*------------------------------------------------------------
 *  稀疏 × 稠密 demo
 *-----------------------------------------------------------*/
static double SparseDenseDemo(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row‑Major）、稠密 B */
    float** A = alloc2float(N, M);           /* M×N */
    float** B = alloc2float(K, N);           /* N×K */
    float** C = alloc2float(K, M);           /* M×K */

    std::srand((unsigned)std::time(nullptr));
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A[i][j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else A[i][j] = 0.0f;
        }

    for (int i = 0; i < N; ++i)
        for (int j = 0; j < K; ++j)
            B[i][j] = static_cast<float>(std::rand() % 11 - 5);

    auto t_start = std::chrono::steady_clock::now();
    /* 2. 计时并调用优化版乘法 */
    //for (int i = 0; i < 2000; i++) {
    MKL_Sparse_CooXDense_Fast(A,
        B, C,
        M, N, K, flag);
    //}
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (fast): %.6f s\n",
    //        diff.count());
            // 进行对拍验证（只在矩阵不太大时进行，避免验证时间过长）
    // if (M * K <= 1000000) { // 100万元素以内
    //     printf("Starting verification...\n");
    //     verify_result(A, B, C, M, N, K);
    // } else {
    //     printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    // }


    /* 3. 清理 */
    // print_matrix(A, M, N);
    // print_matrix(B, N, K);
    // print_matrix(C, M, K);
    free2float(A); free2float(B); free2float(C);
    return diff.count();
}


bool verify_result_1d_intA(const int8_t* denseA, const float* denseB, const float* denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5f) {
    // 分配存储正确结果的扁平化矩阵
    std::vector<float> correct_result(rowsA * colsC, 0.0f);
    float* correct = correct_result.data();

    // 传统三重循环计算正确结果
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                // A[i][k] -> denseA[i*colsA + k]
                // B[k][j] -> denseB[k*colsC + j]
                sum += float(denseA[i * colsA + k]) * denseB[k * colsC + j];
            }
            correct[i * colsC + j] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    printf("Verification time: %ld μs\n", us.count());

    // 对比结果
    bool ok = true;
    int errors = 0;
    const int max_show = 10;
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float ref = correct[i * colsC + j];
            float got = denseC_gustavson[i * colsC + j];
            float diff = std::fabs(ref - got);
            if (diff > tolerance) {
                ok = false;
                if (errors < max_show) {
                    printf("ERROR [%d,%d]: ref=%.6f, gust=%.6f, diff=%.6f\n",
                        i, j, ref, got, diff);
                }
                ++errors;
            }
        }
    }

    if (ok) {
        printf("\033[1;32mcorrect\033[0m: all %d elements matched ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m: %d errors out of %d elements\n",
            errors, rowsA * colsC);
    }
    return ok;
}


bool verify_result_1d(const float* denseA, const float* denseB, const float* denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5f) {
    // 分配存储正确结果的扁平化矩阵
    std::vector<float> correct_result(rowsA * colsC, 0.0f);
    float* correct = correct_result.data();

    // 传统三重循环计算正确结果
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                // A[i][k] -> denseA[i*colsA + k]
                // B[k][j] -> denseB[k*colsC + j]
                sum += denseA[i * colsA + k] * denseB[k * colsC + j];
            }
            correct[i * colsC + j] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    printf("Verification time: %ld μs\n", us.count());

    // 对比结果
    bool ok = true;
    int errors = 0;
    const int max_show = 10;
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float ref = correct[i * colsC + j];
            float got = denseC_gustavson[i * colsC + j];
            float diff = std::fabs(ref - got);
            if (diff > tolerance) {
                ok = false;
                if (errors < max_show) {
                    printf("ERROR [%d,%d]: ref=%.6f, gust=%.6f, diff=%.6f\n",
                        i, j, ref, got, diff);
                }
                ++errors;
            }
        }
    }

    if (ok) {
        printf("\033[1;32mcorrect\033[0m: all %d elements matched ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m: %d errors out of %d elements\n",
            errors, rowsA * colsC);
    }
    return ok;
}


static double SparseDenseGustavsonDemoNewTernarySeparate(int M, int N, int K,
    int flag, float sparsity, float v_th, int T_max, int T_min)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    int8_t* output = (int8_t*)std::malloc(sizeof(int8_t) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }
    float*v = rand01_matrix_alloc(M,K,42);
    float*T_t = rand01_matrix_alloc(M,K,42);

    auto t_start = std::chrono::steady_clock::now();
    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary(
        A, B, C, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    // printf("SpMM time: %.6f s\n", diff.count());

    auto t_start1 = std::chrono::steady_clock::now();
    ST_BIF_forward_scale_int_AVX2(C, v, T_t, output, M * K, v_th, T_max, T_min);
    auto t_end1 = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff1 = t_end1 - t_start1;
    // printf("Neuron time: %.6f s\n", diff1.count());

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count() + diff1.count();
}

bool compare_int8_matrices(
    const int8_t* A,
    const int8_t* B,
    size_t rows,
    size_t cols,
    size_t lda = 0,    // leading dimension (stride) for A; if 0 treated as cols
    size_t ldb = 0,    // leading dimension (stride) for B; if 0 treated as cols
    const char* nameA = "A",
    const char* nameB = "B",
    size_t max_show = 10 // show up to this many mismatches
) {
    if (!A || !B) {
        std::fprintf(stderr, "compare_int8_matrices: null pointer input\n");
        return false;
    }
    if (lda == 0) lda = cols;
    if (ldb == 0) ldb = cols;

    const char* COLOR_GREEN = "\x1b[32m";
    const char* COLOR_RED   = "\x1b[31m";
    const char* COLOR_RESET = "\x1b[0m";

    struct Mismatch { size_t r, c; int a_val, b_val; };
    std::vector<Mismatch> mismatches;
    mismatches.reserve(std::min((size_t)max_show, rows * cols));

    size_t total_mismatches = 0;

    for (size_t r = 0; r < rows; ++r) {
        const int8_t* rowA = A + r * lda;
        const int8_t* rowB = B + r * ldb;
        for (size_t c = 0; c < cols; ++c) {
            int a = static_cast<int>(rowA[c]);
            int b = static_cast<int>(rowB[c]);
            if (a != b) {
                ++total_mismatches;
                if (mismatches.size() < max_show) {
                    mismatches.push_back({r, c, a, b});
                }
            }
        }
    }

    if (total_mismatches == 0) {
        std::printf("%s[OK]%s Matrices '%s' and '%s' are identical. (rows=%zu cols=%zu)\n",
                    COLOR_GREEN, COLOR_RESET, nameA, nameB, rows, cols);
        return true;
    } else {
        std::printf("%s[ERROR]%s Matrices '%s' and '%s' differ: %zu mismatches (showing up to %zu):\n",
                    COLOR_RED, COLOR_RESET, nameA, nameB, total_mismatches, (size_t)max_show);
        for (size_t i = 0; i < mismatches.size(); ++i) {
            auto &m = mismatches[i];
            std::printf("  #%zu: (row=%zu, col=%zu): %s=%d, %s=%d\n",
                        i+1, m.r, m.c, nameA, m.a_val, nameB, m.b_val);
        }
        if (total_mismatches > mismatches.size()) {
            std::printf("  ... (and %zu more mismatches)\n", total_mismatches - mismatches.size());
        }
        return false;
    }
}


static double SparseDenseGustavsonDemoNewTernaryFusion(int M, int N, int K,
    int flag, float sparsity, float v_th, int T_max, int T_min)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    int8_t* output = (int8_t*)std::malloc(sizeof(int8_t) * M * K);           /* M×K */
    int8_t* output_true = (int8_t*)std::malloc(sizeof(int8_t) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }
    float*v = rand01_matrix_alloc(M,K,42);
    float*T_t = rand01_matrix_alloc(M,K,42);

    float*v1 = rand01_matrix_alloc(M,K,42);
    float*T_t1 = rand01_matrix_alloc(M,K,42);

    auto t_start = std::chrono::steady_clock::now();
    MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_fusion(
        A, B, C, M, N, K,
        output, v, T_t, v_th, T_max, T_min
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    printf("SpMM time: %.6f s\n", diff.count());

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary(
        A, B, C, M, N, K, flag
    );
    ST_BIF_forward_scale_int_AVX2(C, v1, T_t1, output_true, M * K, v_th, T_max, T_min);


    // compare_int8_matrices(output, output_true, M, K, K, K, "output", "output_true", 20);


    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}



static double SparseDenseGustavsonDemoNewTernary(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary(
        A, B, C, M, N, K, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d_intA(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}


/*------------------------------------------------------------
 *  稠密 × 稠密 baseline
 *-----------------------------------------------------------*/
static double DenseDenseDemo(int M, int N, int K)
{
    float** A = alloc2float(N, M);       /* M×N */
    float** B = alloc2float(K, N);       /* N×K */
    float** C = alloc2float(K, M);       /* M×K */

    std::srand((unsigned)std::time(nullptr));
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j)
            A[i][j] = static_cast<float>(std::rand() % 11 - 5);
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < K; ++j)
            B[i][j] = static_cast<float>(std::rand() % 11 - 5);

    auto t_start = std::chrono::steady_clock::now();
    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
        M, K, N,
        1.0f, A[0], N, B[0], K,
        0.0f, C[0], K);
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    // printf("Dense×Dense (sgemm): %.6f s\n",
    //        diff.count());
    // print_matrix(A, M, N);
    // print_matrix(B, N, K);
    // print_matrix(C, M, K);
    free2float(A); free2float(B); free2float(C);
    return diff.count();

}



bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_fusion(
    /*SpMM*/
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    /*Neuron*/
    int8_t* output,
    float* V_t_1,
    float* T_t_1,
    float v_th,
    float T_max,
    float T_min
)
{
    const size_t simd_width = 8;
    // Broadcasted constants (256-bit)
    __m256 vth256 = _mm256_set1_ps(v_th);
    __m256 zero256 = _mm256_setzero_ps();

    __m256 Tmax_f32_256 = _mm256_set1_ps((float)T_max * v_th);
    __m256 Tmin_f32_256 = _mm256_set1_ps((float)T_min * v_th);

    // output = (int8_t*)malloc(rowsA * colsC * sizeof(int8_t));

    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { 
                int addr = base + off;
                col_idx[addr] = (MKL_INT)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);

        int8_t* row1 = output + (size_t)i * colsC;
        std::fill_n(row1, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }

    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;
            int8_t* output_p = output;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // printf("byte=%ld\n",sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            //在写回的时候进行neuron计算，这边直接跳过denseC的写回，直接写入output
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                // float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                int8_t* output_row = output_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* V_t_1_row = V_t_1 + (size_t)i * (size_t)colsC + (size_t)cb;
                float* T_t_1_row = T_t_1 + (size_t)i * (size_t)colsC + (size_t)cb;

                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    alignas(32) int32_t tmp_spike32[8];

                    __m256 x_vec = _mm256_load_ps(src_row + j);
                    __m256 Vprev = _mm256_loadu_ps(V_t_1_row + j);

                    __m256 H = _mm256_add_ps(Vprev, x_vec);
                    __m256 t32 = _mm256_loadu_ps(T_t_1_row + j);

                    // comparisons on floats -> __m256 masks (all-ones or zeros per-lane)
                    __m256 mask_ge_ps = _mm256_cmp_ps(H, vth256, _CMP_GE_OQ);    // H >= v_th
                    __m256 mask_lt0_ps = _mm256_cmp_ps(H, zero256, _CMP_LT_OQ); // H < 0
         
                    // comparisons on t32
                    __m256 mask_t_lt_tmax_ps = _mm256_cmp_ps(t32, Tmax_f32_256, _CMP_LT_OQ); // t < Tmax
                    __m256 mask_t_gt_tmin_ps = _mm256_cmp_ps(Tmin_f32_256, t32, _CMP_LT_OQ); // t > Tmin (Tmin < t)              

                    // combine masks (still as float-bit patterns)
                    __m256 pos_mask_ps = _mm256_and_ps(mask_ge_ps, mask_t_lt_tmax_ps);
                    __m256 neg_mask_ps = _mm256_and_ps(mask_lt0_ps, mask_t_gt_tmin_ps);                    

                    // Convert mask -> 0/1 int32 vector:
                    // cast mask bits to int then logical shift right by 31 to map 0xFFFFFFFF -> 1, 0x00000000 -> 0
                    __m256i pos_bits = _mm256_castps_si256(pos_mask_ps);
                    __m256i neg_bits = _mm256_castps_si256(neg_mask_ps);                    

                    __m256i pos01 = _mm256_srli_epi32(pos_bits, 31); // 0 or 1 per lane
                    __m256i neg01 = _mm256_srli_epi32(neg_bits, 31);

                    // spike_i32 = pos01 - neg01  -> values in {-1,0,1}
                    __m256i spike_i32 = _mm256_sub_epi32(pos01, neg01);

                    // convert spike to float
                    __m256 spike_f = _mm256_cvtepi32_ps(spike_i32);

                    // Vnew = H - v_th * spike
                    __m256 vth_mul_spike = _mm256_mul_ps(vth256, spike_f);
                    __m256 Vnew = _mm256_sub_ps(H, vth_mul_spike);

                    // store Vnew
                    _mm256_storeu_ps(V_t_1_row + j, Vnew);

                    _mm256_storeu_si256((__m256i*)tmp_spike32, spike_i32);
                    for (int k = 0; k < 8; ++k) {
                        int32_t tspike = tmp_spike32[k];
                        output_row[j + k] = (int8_t)tspike; // keep same truncation semantics
                    }

                    // compute tnew32 = t32 + vth_mul_spike
                    __m256 tnew32 = _mm256_add_ps(t32, vth_mul_spike);

                    // store tnew32
                    _mm256_storeu_ps(T_t_1_row + j, tnew32);
                }
                // 处理尾部
                for (; j < nb_eff; ++j){
                    float x = src_row[j];
                    float Vp = V_t_1_row[j];
                    float Tp = T_t_1_row[j];
                    float Hs = Vp + x;
                    int8_t spike_i = 0;
                    if (Hs >= v_th && (Tp < (float)T_max * v_th)) spike_i = 1;
                    else if (Hs < 0.0f && (Tp > (float)T_min * v_th)) spike_i = -1;
                    float spike_out = ((float)spike_i) * v_th;
                    float Vnew = Hs - spike_out;
                    float tnew = Tp + spike_out;
                    V_t_1_row[j] = Vnew;
                    T_t_1_row[j] = tnew;
                    output_row[j] = spike_i;
                } 
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }
    return true;
}

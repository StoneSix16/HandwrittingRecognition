#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define LWIDTH 4
#define LWIDTH_POW2 16

float* make_weight_LUT(float* W, int M, int N) {
    // 计算需要的组数（向上取整）
    int M_groups = (M + LWIDTH - 1) / LWIDTH;  // 等价于 ceil(M/LWIDTH)

    // 定义16个4维的0-1向量（0-15的二进制表示）
    int binary_vectors[LWIDTH_POW2][LWIDTH] = {
        {0, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}, {0, 0, 1, 1},
        {0, 1, 0, 0}, {0, 1, 0, 1}, {0, 1, 1, 0}, {0, 1, 1, 1},
        {1, 0, 0, 0}, {1, 0, 0, 1}, {1, 0, 1, 0}, {1, 0, 1, 1},
        {1, 1, 0, 0}, {1, 1, 0, 1}, {1, 1, 1, 0}, {1, 1, 1, 1}
    };

    float* weightLUT = (float*)malloc(LWIDTH_POW2 * M_groups * N * sizeof(float));
    if (weightLUT == NULL) {
        fprintf(stderr, "Error: Failed to allocate memory for weightLUT\n");
        return NULL;
    }
    // 执行映射操作 - lut_idx的遍历放在最外层
    for (int lut_idx = 0; lut_idx < LWIDTH_POW2; lut_idx++){
        for (int m = 0; m < M_groups; m++) {
            for (int n = 0; n < N; n++) {
                weightLUT[lut_idx * M_groups * N + m*N + n] = 0.0f;

                for (int k = 0; k < LWIDTH; k++) {
                    int row_in_W = m * LWIDTH + k; // 在原矩阵W中的行号
                    
                    if (row_in_W < M) {
                        weightLUT[lut_idx * M_groups * N + m*N + n] += W[row_in_W*N+n] * binary_vectors[lut_idx][k];
                    }                        
                }
            }
        }
    }
    return weightLUT;
}


static void print_matrix(const char* name, const float* A, int rows, int cols) {
    printf("%s (shape %d x %d):\n", name, rows, cols);
    for (int i = 0; i < rows; ++i) {
        printf("  [");
        for (int j = 0; j < cols; ++j) {
            printf("%8.3f", A[i*cols + j]);
            if (j+1 < cols) printf(", ");
        }
        printf(" ]\n");
    }
    printf("\n");
}

int main(void) {
    // 示例尺寸，可以修改测试其他情况
    const int M = 5;
    const int N = 6;

    // allocate and fill W with simple values for easy checking
    float* W = (float*)malloc(M * N * sizeof(float));
    if (!W) {
        fprintf(stderr, "malloc W failed\n");
        return 1;
    }
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            // 填充：行主索引的简单序列，便于人工验证
            W[i*N + j] = (float)(i * N + j); // 从1开始
        }
    }

    print_matrix("W", W, M, N);

    // 调用 make_weight_LUT
    float* lut = make_weight_LUT(W, M, N);
    if (!lut) {
        free(W);
        return 2;
    }

    int M_groups = (M + LWIDTH - 1) / LWIDTH;
    printf("LUT shape: (%d, %d, %d)  => (LWIDTH_POW2=%d, M_groups=%d, N=%d)\n\n",
           LWIDTH_POW2, M_groups, N, LWIDTH_POW2, M_groups, N);

    // 打印全部 LUT（可根据需要限制输出）
    for (int lut_idx = 0; lut_idx < LWIDTH_POW2; ++lut_idx) {
        printf("=== LUT index %2d (binary): ", lut_idx);
        // 打印二进制表示（高位至低位）
        for (int k = 0; k < LWIDTH; ++k) {
            int bit = (lut_idx >> (LWIDTH - 1 - k)) & 1;
            printf("%d", bit);
        }
        printf(" ===\n");

        for (int m = 0; m < M_groups; ++m) {
            printf("  group %d: [", m);
            for (int n = 0; n < N; ++n) {
                float v = lut[lut_idx * M_groups * N + m*N + n];
                printf("%8.3f", v);
                if (n+1 < N) printf(", ");
            }
            printf(" ]\n");
        }
        printf("\n");
    }

    // 简单验证：
    // lut_idx == 0 应全 0
    int allzero = 1;
    for (int m = 0; m < M_groups * N; ++m) {
        if (fabs(lut[0 * M_groups * N + m]) > 1e-6f) { allzero = 0; break; }
    }
    printf("Check: lut_idx 0 all zero? %s\n", allzero ? "YES" : "NO");

    // lut_idx == 15 (1111) 应该等于该 group 行的逐列求和（仅当 LWIDTH==4 时）
    int allok15 = 1;
    for (int m = 0; m < M_groups; ++m) {
        for (int n = 0; n < N; ++n) {
            float expected = 0.0f;
            for (int k = 0; k < LWIDTH; ++k) {
                int row = m * LWIDTH + k;
                if (row < M) expected += W[row * N + n];
            }
            float got = lut[(LWIDTH_POW2-1) * M_groups * N + m*N + n];
            if (fabs(expected - got) > 1e-5f) {
                allok15 = 0;
                // 打印第一个不匹配的位置以便调试
                printf("Mismatch at lut=15 group=%d col=%d: expected=%f got=%f\n", m, n, expected, got);
                goto done_check15;
            }
        }
    }
done_check15:
    printf("Check: lut_idx %d equals group sums? %s\n", LWIDTH_POW2-1, allok15 ? "YES" : "NO");

    // cleanup
    free(W);
    free(lut);

    return 0;
}


﻿/*  Demo：验证优化后的 Sparse × Dense
 *  说明：
 *    • 默认矩阵规模 2048 × 2048，sparsity=0.90 表示 90 % 元素为 0
 *    • 可通过命令行参数修改稀疏度：  ./demo 0.85
 *    • 代码同时给出等尺寸 Dense×Dense 基准
 */

#include "MKL_Sparse_Methods.h"
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <chrono>
#include <cmath>
#define _CRT_SECURE_NO_WARNINGS

static double SparseDenseGustavsonDemo(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNew(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNewHighSparsity(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNewTernary(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNewTernaryBPack(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNewTernaryLUT(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNewTernaryINT(int M, int N, int K,
    int flag, float sparsity);

static double SparseDenseDemo(int M, int N, int K,
    int flag,      /* 0:A·B  1:Aᵀ·B  2:Aᴴ·B */
    float sparsity);       /* 0.0‑1.0 */

static double SparseDenseGustavsonDemoNewBStation(int M, int N, int K,
    int flag, float sparsity);

static double SparseDenseGustavsonDemoNewTernaryBRearrange(int M, int N, int K,
    int flag, float sparsity);

static double DenseDenseDemo(int M, int N, int K);

static double SparseDenseGustavsonDemoNewTernarySearch(int M, int N, int K,
    int flag, float sparsity, int Rb, int Kc, int Nb);

FILE* safe_fopen(const char* filename, const char* mode) {
#ifdef _WIN32
    FILE* fp = nullptr;
    if (fopen_s(&fp, filename, mode) != 0) {
        return nullptr;
    }
    return fp;
#else
    return fopen(filename, mode);
#endif
}

void write_csv_row(int M, int N, int K, double sparsity,
    double t1, double t2, double t3, int test_iter) {
    FILE* F = safe_fopen("output.csv", "ab");
    if (!F) {
        perror("Failed to open output.csv");
        exit(EXIT_FAILURE);
    }

    fprintf(F, "%d,%d,%d,%.6f,%.6f,%.6f,%.6f\n",
        M, N, K, sparsity,
        t1 / test_iter, t2 / test_iter, t3 / test_iter);

    fclose(F);
}


int main(int argc, char** argv)
{
    int warmup_iter = 10;
    int test_iter = 10;
    const int M = static_cast<int>(atof(argv[2])), N = static_cast<int>(atof(argv[3])), K = static_cast<int>(atof(argv[4]));
    const int Rb = static_cast<int>(atof(argv[5])), Kc = static_cast<int>(atof(argv[6])), Nb = static_cast<int>(atof(argv[7]));
    float sparsity = 0.90f;
    if (argc > 1) sparsity = static_cast<float>(atof(argv[1]));
    // printf("M=%d,N=%d,K=%d,sparsity=%.6f\n", M, N, K, sparsity);

    for (int i = 0; i < warmup_iter; i++) {
        SparseDenseGustavsonDemoNewTernarySearch(M, N, K, 0, sparsity, Rb, Kc, Nb);
    }
    double spend_time2 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time2 = spend_time2 + SparseDenseGustavsonDemoNewTernarySearch(M, N, K, 0, sparsity, Rb, Kc, Nb);
    }
    printf("%.6f\n", spend_time2 / test_iter);

    // for (int i = 0; i < warmup_iter; i++) {
    //     SparseDenseGustavsonDemoNew(M, N, K, 0, sparsity);
    // }
    // double spend_time2 = 0.0;
    // for (int i = 0; i < test_iter; i++) {
    //     spend_time2 = spend_time2 + SparseDenseGustavsonDemoNew(M, N, K, 0, sparsity);
    // }
    // printf("Sparse×Dense (Gustavson New): %.6f s\n", spend_time2 / test_iter);


    // for (int i = 0; i < warmup_iter; i++) {
    //    SparseDenseDemo(M, N, K, 0, sparsity);
    // }
    // double spend_time1 = 0.0;
    // for (int i = 0; i < test_iter; i++) {
    //    spend_time1 = spend_time1 + SparseDenseDemo(M, N, K, 0, sparsity);
    // }
    // printf("Sparse×Dense (fast): %.6f s\n", spend_time1 / test_iter);



    // for (int i=0;i<warmup_iter;i++){
    //     DenseDenseDemo(M, N, K);
    // }
    // double spend_time3 = 0.0;
    // for (int i=0;i<test_iter;i++){
    //    spend_time3 = spend_time3 + DenseDenseDemo(M, N, K);
    // }
    // printf("Dense×Dense (mkl gemm): %.6f s\n", spend_time3/test_iter);

    // write_csv_row(M, N, K, sparsity, spend_time1, spend_time2, spend_time3, test_iter);
    return 0;
}

static void print_matrix(float** A, int M, int N) {
    printf("=======================%d x %d======================\n", M, N);
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            printf("%f ", A[i][j]);
        }
        printf("\n");
    }
}

bool verify_result(float** denseA, float** denseB, float** denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5) {
    // 分配存储正确结果的矩阵
    std::vector<float> correct_result_data(rowsA * colsC, 0.0f);
    float* correct_result = correct_result_data.data();

    // 传统三重循环计算正确结果
    auto start_verify = std::chrono::high_resolution_clock::now();

    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                sum += denseA[0][i * colsA + k] * denseB[0][k * colsC + j];
            }
            correct_result[i * colsC + j] = sum;
        }
    }

    auto end_verify = std::chrono::high_resolution_clock::now();
    auto verify_time = std::chrono::duration_cast<std::chrono::microseconds>(end_verify - start_verify);

    printf("Verification computation time: %ld μs\n", verify_time.count());

    // 对比结果
    bool is_correct = true;
    int error_count = 0;
    const int max_errors_to_show = 10;

    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float diff = std::abs(correct_result[i * colsC + j] - denseC_gustavson[0][i * colsC + j]);
            if (diff > tolerance) {
                is_correct = false;
                if (error_count < max_errors_to_show) {
                    printf("ERROR at [%d][%d]: correct=%.6f, gustavson=%.6f, diff=%.6f\n",
                        i, j, correct_result[i * colsC + j], denseC_gustavson[0][i * colsC + j], diff);
                }
                error_count++;
            }
        }
    }

    // 输出结果
    if (is_correct) {
        // 输出绿色的"correct"
        printf("\033[1;32mcorrect\033[0m\n");
        printf("All %d elements matched! ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m\n");
        printf("Found %d errors out of %d elements\n", error_count, rowsA * colsC);
    }

    return is_correct;
}

/*------------------------------------------------------------
 *  稀疏 × 稠密 demo
 *-----------------------------------------------------------*/
static double SparseDenseDemo(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row‑Major）、稠密 B */
    float** A = alloc2float(N, M);           /* M×N */
    float** B = alloc2float(K, N);           /* N×K */
    float** C = alloc2float(K, M);           /* M×K */

    std::srand((unsigned)std::time(nullptr));
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A[i][j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else A[i][j] = 0.0f;
        }

    for (int i = 0; i < N; ++i)
        for (int j = 0; j < K; ++j)
            B[i][j] = static_cast<float>(std::rand() % 11 - 5);

    auto t_start = std::chrono::steady_clock::now();
    /* 2. 计时并调用优化版乘法 */
    //for (int i = 0; i < 2000; i++) {
    MKL_Sparse_CooXDense_Fast(A,
        B, C,
        M, N, K, flag);
    //}
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (fast): %.6f s\n",
    //        diff.count());
            // 进行对拍验证（只在矩阵不太大时进行，避免验证时间过长）
    // if (M * K <= 1000000) { // 100万元素以内
    //     printf("Starting verification...\n");
    //     verify_result(A, B, C, M, N, K);
    // } else {
    //     printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    // }


    /* 3. 清理 */
    // print_matrix(A, M, N);
    // print_matrix(B, N, K);
    // print_matrix(C, M, K);
    free2float(A); free2float(B); free2float(C);
    return diff.count();
}


bool verify_result_1d_intA(const int8_t* denseA, const float* denseB, const float* denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5f) {
    // 分配存储正确结果的扁平化矩阵
    std::vector<float> correct_result(rowsA * colsC, 0.0f);
    float* correct = correct_result.data();

    // 传统三重循环计算正确结果
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                // A[i][k] -> denseA[i*colsA + k]
                // B[k][j] -> denseB[k*colsC + j]
                sum += float(denseA[i * colsA + k]) * denseB[k * colsC + j];
            }
            correct[i * colsC + j] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    printf("Verification time: %ld μs\n", us.count());

    // 对比结果
    bool ok = true;
    int errors = 0;
    const int max_show = 10;
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float ref = correct[i * colsC + j];
            float got = denseC_gustavson[i * colsC + j];
            float diff = std::fabs(ref - got);
            if (diff > tolerance) {
                ok = false;
                if (errors < max_show) {
                    printf("ERROR [%d,%d]: ref=%.6f, gust=%.6f, diff=%.6f\n",
                        i, j, ref, got, diff);
                }
                ++errors;
            }
        }
    }

    if (ok) {
        printf("\033[1;32mcorrect\033[0m: all %d elements matched ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m: %d errors out of %d elements\n",
            errors, rowsA * colsC);
    }
    return ok;
}


bool verify_result_1d(const float* denseA, const float* denseB, const float* denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5f) {
    // 分配存储正确结果的扁平化矩阵
    std::vector<float> correct_result(rowsA * colsC, 0.0f);
    float* correct = correct_result.data();

    // 传统三重循环计算正确结果
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                // A[i][k] -> denseA[i*colsA + k]
                // B[k][j] -> denseB[k*colsC + j]
                sum += denseA[i * colsA + k] * denseB[k * colsC + j];
            }
            correct[i * colsC + j] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    printf("Verification time: %ld μs\n", us.count());

    // 对比结果
    bool ok = true;
    int errors = 0;
    const int max_show = 10;
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float ref = correct[i * colsC + j];
            float got = denseC_gustavson[i * colsC + j];
            float diff = std::fabs(ref - got);
            if (diff > tolerance) {
                ok = false;
                if (errors < max_show) {
                    printf("ERROR [%d,%d]: ref=%.6f, gust=%.6f, diff=%.6f\n",
                        i, j, ref, got, diff);
                }
                ++errors;
            }
        }
    }

    if (ok) {
        printf("\033[1;32mcorrect\033[0m: all %d elements matched ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m: %d errors out of %d elements\n",
            errors, rowsA * colsC);
    }
    return ok;
}

/*------------------------------------------------------------
 *  稀疏 × 稠密 demo
 *-----------------------------------------------------------*/
static double SparseDenseGustavsonDemo(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row‑Major）、稠密 B */
    float** A = alloc2float(N, M);           /* M×N */
    float** B = alloc2float(K, N);           /* N×K */
    float** C = alloc2float(K, M);           /* M×K */

    std::srand(1024);
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A[i][j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else A[i][j] = 0.0f;
        }

    for (int i = 0; i < N; ++i)
        for (int j = 0; j < K; ++j)
            B[i][j] = static_cast<float>(std::rand() % 11 - 5);

    auto t_start = std::chrono::steady_clock::now();

    /* 3. 计时并调用优化版乘法 */
    bool success = MKL_Sparse_CooXDense_Fast_Gustavson(A,
        B, C,
        M, N, K, flag);
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {            
    //         // 进行对拍验证（只在矩阵不太大时进行，避免验证时间过长）
    //         if (M * K <= 1000000) { // 100万元素以内
    //             printf("Starting verification...\n");
    //             verify_result(A, B, C, M, N, K);
    //         } else {
    //             printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //         }
    //     } else {
    //         printf("Gustavson SpMM failed!\n");
    //     }

    // printf("Sparse×Dense (fast): %.6f s\n",
    //        diff.count());

    /* 4. 清理 */
    // print_matrix(A, M, N);
    // print_matrix(B, N, K);
    // print_matrix(C, M, K);
    free2float(A); free2float(B); free2float(C);
    return diff.count();
}

#include <random>

static double SparseDenseGustavsonDemoNew(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk(
        A, B, C, M, N, K, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}


static double SparseDenseGustavsonDemoNewBStation(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_B_stationary(
        A, B, C, M, N, K, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonDemoNewHighSparsity(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_high_sparsity(
        A, B, C, M, N, K, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonDemoNewTernarySearch(int M, int N, int K,
    int flag, float sparsity, int Rb, int Kc, int Nb)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_search(
        A, B, C, M, N, K, Rb, Kc, Nb
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d_intA(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonDemoNewTernaryBRearrange(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }


    // 3) tiling params
    int rowsA = M, colsA = N, colsC = K;
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }

    int num_k_tiles = (colsA + Kc - 1) / Kc;
    int num_c_tiles = (colsC + Nb - 1) / Nb;
    size_t tile_size = (size_t)Kc * (size_t)Nb;
    std::vector<float> PrepackedB((size_t)num_k_tiles * (size_t)num_c_tiles * tile_size);
    for (int tk = 0; tk < num_k_tiles; ++tk) {
        int kb = tk * Kc;
        int kc_eff = std::min(Kc, colsA - kb);
        for (int tc = 0; tc < num_c_tiles; ++tc) {
            int cb = tc * Nb;
            int nb_eff = std::min(Nb, colsC - cb);
            float* tile_ptr = PrepackedB.data() + ((size_t)tk * num_c_tiles + tc) * tile_size;
            for (int kk = 0; kk < kc_eff; ++kk) {
                const float* Brow = B + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                float* dest = tile_ptr + (size_t)kk * (size_t)Nb;
                memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                if (nb_eff < Nb) memset(dest + nb_eff, 0, sizeof(float) * (size_t)(Nb - nb_eff));
            }
            for (int kk = kc_eff; kk < Kc; ++kk) {
                float* dest = tile_ptr + (size_t)kk * (size_t)Nb;
                memset(dest, 0, sizeof(float) * (size_t)Nb);
            }
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_B_rearrange(
        A, (float *)PrepackedB.data(), C, M, N, K, Rb, Kc, Nb, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d_intA(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

void pack_matrix_B(const float* denseB,
                   int rowsB,
                   int colsC,
                   int Kc,
                   int Nc,
                   std::vector<float>& packedB)
{
    int Kblocks = (rowsB + Kc - 1) / Kc;
    int Nblocks = (colsC + Nc - 1) / Nc;
    // allocate and zero (pad with zeros)
    packedB.assign((size_t)Kblocks * Kc * (size_t)Nblocks * Nc, 0.0f);

    for (int kb = 0; kb < rowsB; kb += Kc) {
        int kb_block = kb / Kc;
        int kc_eff = std::min(Kc, rowsB - kb);
        for (int cb = 0; cb < colsC; cb += Nc) {
            int cb_block = cb / Nc;
            int nc_eff = std::min(Nc, colsC - cb);

            size_t block_id = (size_t)kb_block * (size_t)Nblocks + (size_t)cb_block;
            float* dest_block = packedB.data() + block_id * (size_t)Kc * (size_t)Nc;

            for (int kk = 0; kk < kc_eff; ++kk) {
                const float* src_row = denseB + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                float* dst_row = dest_block + (size_t)kk * (size_t)Nc;
                // copy nc_eff floats
                if (nc_eff > 0) memcpy(dst_row, src_row, sizeof(float) * (size_t)nc_eff);
            }
        }
    }
}

static double SparseDenseGustavsonDemoNewTernaryBPack(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    std::vector<float> packedB;
    pack_matrix_B(B, N, K, 512, 64, packedB);

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_packB(
        A, packedB.data(), C, M, N, K, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d_intA(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonDemoNewTernaryINT(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    int8_t* B = (int8_t*)std::malloc(sizeof(int8_t) * N * K);           /* N×K */
    int32_t* C = (int32_t*)std::malloc(sizeof(int32_t) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<int8_t>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_int(
        A, B, C, M, N, K, flag
    );

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}



static double SparseDenseGustavsonDemoNewTernaryLUT(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A = (int8_t*)std::malloc(sizeof(int8_t) * M * N);           /* M×N */
    float* B = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A || !B || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > 0.5){
                    A[i * N + j] = 1;
                }
                else{
                    A[i * N + j] = -1;
                }
            }
            else {
                A[i * N + j] = 0;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    float* B_LUT = make_weight_LUT(B, N, K);

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    // for (int i = 0; i < 2000; i++){
    success = MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_LUT(
        A, B_LUT, C, M, N, K, flag
    );
    // }

    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d_intA(A, B, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A) { std::free(A); A = nullptr; }
    if (B) { std::free(B); B = nullptr; }
    if (B_LUT) { std::free(B_LUT); B_LUT = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}


/*------------------------------------------------------------
 *  稠密 × 稠密 baseline
 *-----------------------------------------------------------*/
static double DenseDenseDemo(int M, int N, int K)
{
    float** A = alloc2float(N, M);       /* M×N */
    float** B = alloc2float(K, N);       /* N×K */
    float** C = alloc2float(K, M);       /* M×K */

    std::srand((unsigned)std::time(nullptr));
    for (int i = 0; i < M; ++i)
        for (int j = 0; j < N; ++j)
            A[i][j] = static_cast<float>(std::rand() % 11 - 5);
    for (int i = 0; i < N; ++i)
        for (int j = 0; j < K; ++j)
            B[i][j] = static_cast<float>(std::rand() % 11 - 5);

    auto t_start = std::chrono::steady_clock::now();
    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
        M, K, N,
        1.0f, A[0], N, B[0], K,
        0.0f, C[0], K);
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    // printf("Dense×Dense (sgemm): %.6f s\n",
    //        diff.count());
    // print_matrix(A, M, N);
    // print_matrix(B, N, K);
    // print_matrix(C, M, K);
    free2float(A); free2float(B); free2float(C);
    return diff.count();

}
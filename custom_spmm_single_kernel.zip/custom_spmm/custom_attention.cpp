#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <chrono>
#include <cmath>
#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>
#include <mkl.h>
#include <mkl_spblas.h>
#include <cstddef>

#define MAX_THREAD 16
#define LWIDTH 4
#define LWIDTH_POW2 16
constexpr int L1_BYTES = 32 * 1024;
constexpr int L2_BYTES = 1024 * 1024;
constexpr int VEC_WIDTH = 8;         // AVX2: 8 floats
constexpr int VEC_WIDTH3 = 24;         // AVX2: 8 floats
constexpr int VEC_WIDTH4 = 32;         // AVX2: 8 floats
constexpr size_t ACC_ALIGN = 64;
constexpr int PREFETCH_P = 4;

bool Sparse_CSRXDense_Fast_Gustavson_Attention_yk(
    float* denseA1,
    float* denseB1,
    float* denseA2,
    float* denseB2,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk(
    float* denseA1,
    float* denseB1,
    float* denseA2,
    float* denseB2,
    float* denseC,
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_ternary(
    float* denseA1,   // [batch][rowsA][colsA]
    int8_t* denseB1,  // [batch][colsA][colsC]
    int8_t* denseA2,  // [batch][rowsA][colsA]
    float* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool Sparse_CSRXDense_Fast_Gustavson_Attention_row_major(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool Sparse_CSRXDense_Fast_Gustavson_Attention_column_major(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);


bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool GEMM_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

static double SparseDenseGustavsonBatchAttention(int M, int N, int K, int B,
    int flag, float sparsity1, float sparsity2);

static double SparseDenseGustavsonAttention(int M, int N, int K,
    int flag, float sparsity);

static double SparseDenseGustavsonAttentionColumnMajor(int M, int N, int K,
    int flag, float sparsity);

static double SparseDenseGustavsonAttentioRowMajor(int M, int N, int K,
int flag, float sparsity);

static double SparseDenseGustavsonBatchAttentionTernary(int M, int N, int K, int B,
    int flag, float sparsity);

static double SparseDenseGustavsonBatchAttentionINT(int M, int N, int K, int B,
    int flag, float sparsity1, float sparsity2);

static inline void* portable_aligned_alloc(size_t alignment, size_t size) {
    if (size == 0) return nullptr;
    size_t extra = alignment - 1 + sizeof(void*);
    void* raw = malloc(size + extra);
    if (!raw) return nullptr;
    uintptr_t raw_addr = (uintptr_t)raw + sizeof(void*);
    uintptr_t aligned = (raw_addr + (alignment - 1)) & ~(alignment - 1);
    void** store = (void**)(aligned - sizeof(void*));
    *store = raw;
    return (void*)aligned;
}
static inline void portable_aligned_free(void* p) {
    if (!p) return;
    void** store = (void**)((uintptr_t)p - sizeof(void*));
    void* raw = *store;
    free(raw);
}

bool verify_batch_bmm_int8_to_float_ref(
    const int8_t* denseA,         // [batch, rowsA, colsA]
    const int8_t* denseB,         // [batch, colsA, colsC]
    const float* denseC_gustavson,// [batch, rowsA, colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    float tolerance = 1e-5f)
{
    if (!denseA || !denseB || !denseC_gustavson) {
        std::fprintf(stderr, "verify: null pointer input\n");
        return false;
    }
    if (batch <= 0 || rowsA <= 0 || colsA <= 0 || colsC <= 0) {
        std::fprintf(stderr, "verify: invalid dims\n");
        return false;
    }

    // allocate reference result: row-major [batch, rowsA, colsC]
    size_t total_elems = (size_t)batch * (size_t)rowsA * (size_t)colsC;
    std::vector<float> correct_result(total_elems, 0.0f);
    float* correct = correct_result.data();

    // compute reference by brute-force bmm (int8 * int8 -> float accumulation)
    auto t0 = std::chrono::high_resolution_clock::now();
    for (int b = 0; b < batch; ++b) {
        size_t baseA_b = (size_t)b * (size_t)rowsA * (size_t)colsA;
        size_t baseB_b = (size_t)b * (size_t)colsA * (size_t)colsC;
        size_t baseC_b = (size_t)b * (size_t)rowsA * (size_t)colsC;
        for (int i = 0; i < rowsA; ++i) {
            size_t baseA = baseA_b + (size_t)i * (size_t)colsA;   // A[b,i,0]
            size_t baseC = baseC_b + (size_t)i * (size_t)colsC;   // C[b,i,0]
            for (int j = 0; j < colsC; ++j) {
                // accumulate in float
                float sum = 0.0f;
                // inner product A[b,i,:] (colsA) with B[b,:,j]
                for (int k = 0; k < colsA; ++k) {
                    int8_t a_ik = denseA[baseA + (size_t)k];                   // A[b,i,k]
                    int8_t b_kj = denseB[baseB_b + (size_t)k * (size_t)colsC + (size_t)j]; // B[b,k,j]
                    sum += float(a_ik) * float(b_kj);
                }
                correct[baseC + (size_t)j] = sum;
            }
        }
    }
    auto t1 = std::chrono::high_resolution_clock::now();
    long long us = std::chrono::duration_cast<std::chrono::microseconds>(t1 - t0).count();
    std::printf("Reference bmm (C++) time: %lld μs\n", (long long)us);

    // compare with provided denseC_gustavson
    bool ok = true;
    int errors = 0;
    const int max_show = 10;
    for (size_t idx = 0; idx < total_elems; ++idx) {
        float ref = correct[idx];
        float got = denseC_gustavson[idx];
        float diff = std::fabs(ref - got);
        if (!(diff <= tolerance)) {
            ok = false;
            if (errors < max_show) {
                // convert linear idx -> (b,i,j)
                size_t tmp = idx;
                int j = (int)(tmp % (size_t)colsC); tmp /= (size_t)colsC;
                int i = (int)(tmp % (size_t)rowsA); tmp /= (size_t)rowsA;
                int b = (int)tmp;
                std::printf("ERROR [b=%d,i=%d,j=%d]: ref=%.6f, got=%.6f, diff=%.6f\n",
                    b, i, j, ref, got, diff);
            }
            ++errors;
        }
    }

    if (ok) {
        std::printf("\033[1;32mcorrect\033[0m: all %zu elements matched ✓\n", total_elems);
    } else {
        std::printf("\033[1;31mINCORRECT\033[0m: %d errors out of %zu elements\n", errors, total_elems);
    }
    return ok;
}

bool verify_result_1d(const float* denseA, const float* denseB, const float* denseC_gustavson,
    int rowsA, int colsA, int colsC, float tolerance = 1e-5f) {
    // 分配存储正确结果的扁平化矩阵
    std::vector<float> correct_result(rowsA * colsC, 0.0f);
    float* correct = correct_result.data();

    // 传统三重循环计算正确结果
    auto start = std::chrono::high_resolution_clock::now();
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float sum = 0.0f;
            for (int k = 0; k < colsA; ++k) {
                // A[i][k] -> denseA[i*colsA + k]
                // B[k][j] -> denseB[k*colsC + j]
                sum += denseA[i * colsA + k] * denseB[k * colsC + j];
            }
            correct[i * colsC + j] = sum;
        }
    }
    auto end = std::chrono::high_resolution_clock::now();
    auto us = std::chrono::duration_cast<std::chrono::microseconds>(end - start);
    printf("Verification time: %ld μs\n", us.count());

    // 对比结果
    bool ok = true;
    int errors = 0;
    const int max_show = 10;
    for (int i = 0; i < rowsA; ++i) {
        for (int j = 0; j < colsC; ++j) {
            float ref = correct[i * colsC + j];
            float got = denseC_gustavson[i * colsC + j];
            float diff = std::fabs(ref - got);
            if (diff > tolerance) {
                ok = false;
                if (errors < max_show) {
                    printf("ERROR [%d,%d]: ref=%.6f, gust=%.6f, diff=%.6f\n",
                        i, j, ref, got, diff);
                }
                ++errors;
            }
        }
    }

    if (ok) {
        printf("\033[1;32mcorrect\033[0m: all %d elements matched ✓\n", rowsA * colsC);
    }
    else {
        printf("\033[1;31mINCORRECT\033[0m: %d errors out of %d elements\n",
            errors, rowsA * colsC);
    }
    return ok;
}


int main(int argc, char** argv)
{
    int warmup_iter = 10;
    int test_iter = 100;
    const int M = static_cast<int>(atof(argv[3])), N = static_cast<int>(atof(argv[4])), K = static_cast<int>(atof(argv[5])), B = static_cast<int>(atof(argv[6]));
    float sparsity1 = static_cast<float>(atof(argv[1]));
    float sparsity2 = static_cast<float>(atof(argv[2]));
    printf("M=%d,N=%d,K=%d,sparsity1=%.6f,sparsity2=%.6f\n", M, N, K, sparsity1, sparsity2);


    for (int i = 0; i < warmup_iter; i++) {
        // printf("entering SparseDenseGustavsonAttentionColumnMajor\n");
        SparseDenseGustavsonBatchAttentionINT(M, N, K, B, 0, sparsity1, sparsity2);
    }
    double spend_time1 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time1 = spend_time1 + SparseDenseGustavsonBatchAttentionINT(M, N, K, B, 0, sparsity1, sparsity2);
    }
    printf("Sparse×Dense (Gustavson All): %.6f s\n", spend_time1 / test_iter);

    for (int i = 0; i < warmup_iter; i++) {
        // printf("entering SparseDenseGustavsonAttentionColumnMajor\n");
        SparseDenseGustavsonAttentionColumnMajor(M, N, K, 0, sparsity1);
    }
    double spend_time2 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time2 = spend_time2 + SparseDenseGustavsonAttentionColumnMajor(M, N, K, 0, sparsity1);
    }
    printf("Sparse×Dense (Gustavson ColumnMajor): %.6f s\n", spend_time2 / test_iter);

    for (int i = 0; i < warmup_iter; i++) {
        SparseDenseGustavsonAttentioRowMajor(M, N, K, 0, sparsity1);
    }
    double spend_time3 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        spend_time3 = spend_time3 + SparseDenseGustavsonAttentioRowMajor(M, N, K, 0, sparsity1);
    }
    printf("Sparse×Dense (Gustavson RowMajor): %.6f s\n", spend_time3 / test_iter);

    return 0;
}

void ref_gemm_add(const float* A1, const float* B1,
                  const float* A2, const float* B2,
                  float* C_out, int M, int N, int K)
{
    // if C_out==nullptr, allocate temporary inside caller
    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            double s = 0.0;
            // sum1
            const float* a1row = A1 + (size_t)i * K;
            const float* a2row = A2 + (size_t)i * K;
            const float* b1col = B1 + j; // stepping by N
            const float* b2col = B2 + j;
            for (int k = 0; k < K; ++k) {
                s += (double)a1row[k] * (double)B1[(size_t)k * N + j];
                s += (double)a2row[k] * (double)B2[(size_t)k * N + j];
            }
            C_out[(size_t)i * N + j] = (float)s;
        }
    }
}

// blocked variant (cache friendly). Flagged as 'fast' implementation (not reference-accurate)
// block sizes can be tuned; here simple blocking on k and n
void blocked_gemm_add(const float* A1, const float* B1,
                      const float* A2, const float* B2,
                      float* C_out, int M, int N, int K,
                      int Kc = 64, int Nb = 64)
{
    // init C_out to zero
    size_t MN = (size_t)M * N;
    for (size_t t = 0; t < MN; ++t) C_out[t] = 0.0f;

    for (int kb = 0; kb < K; kb += Kc) {
        int kc = std::min(Kc, K - kb);
        for (int nb = 0; nb < N; nb += Nb) {
            int nc = std::min(Nb, N - nb);
            // compute partial: A[:, kb:kb+kc] * B[kb:kb+kc, nb:nb+nc]
            for (int i = 0; i < M; ++i) {
                for (int k = 0; k < kc; ++k) {
                    float a1 = A1[(size_t)i * K + kb + k];
                    float a2 = A2[(size_t)i * K + kb + k];
                    const float* b1row = B1 + (size_t)(kb + k) * N + nb;
                    const float* b2row = B2 + (size_t)(kb + k) * N + nb;
                    float* crow = C_out + (size_t)i * N + nb;
                    // accumulate nc elements
                    for (int j = 0; j < nc; ++j) {
                        crow[j] += a1 * b1row[j] + a2 * b2row[j];
                    }
                }
            }
        }
    }
}

// compare function: compute reference (or fast) and compare with provided C_test
// C_test may be nullptr (skip compare)
// return true if all elements within tolerance
bool diff_check_A1B1_plus_A2B2(const float* A1, const float* B1,
                               const float* A2, const float* B2,
                               const float* C_test, // expected from tested implementation; if nullptr, we'll just compute and return true
                               int M, int N, int K,
                               int flag = 0, // 0 -> reference (double accum), 1 -> blocked fast
                               double rtol = 1e-5, double atol = 1e-6)
{
    // allocate reference
    std::vector<float> C_ref((size_t)M * N);

    if (flag == 0) {
        ref_gemm_add(A1,B1,A2,B2, C_ref.data(), M,N,K);
    } else {
        blocked_gemm_add(A1,B1,A2,B2, C_ref.data(), M,N,K);
    }

    if (C_test == nullptr) {
        // nothing to compare; user asked to compute only
        return true;
    }

    // Compare C_ref vs C_test
    double max_abs = 0.0;
    double max_rel = 0.0;
    double l2 = 0.0;
    size_t cnt = (size_t)M * N;
    size_t mismatches = 0;
    size_t max_report = 10;

    for (size_t idx = 0; idx < cnt; ++idx) {
        double ref = (double)C_ref[idx];
        double got = (double)C_test[idx];
        double abs_err = std::abs(ref - got);
        double rel_err = (std::abs(ref) > 0) ? abs_err / std::abs(ref) : abs_err;
        if (abs_err > max_abs) max_abs = abs_err;
        if (rel_err > max_rel) max_rel = rel_err;
        l2 += (ref - got) * (ref - got);

        if (!(abs_err <= atol + rtol * std::abs(ref))) {
            if (mismatches < max_report) {
                size_t i = idx / N;
                size_t j = idx % N;
                printf("Mismatch at (%zu,%zu): ref=%g got=%g abs_err=%g rel_err=%g\n",
                       i, j, ref, got, abs_err, rel_err);
            }
            ++mismatches;
        }
    }
    l2 = std::sqrt(l2);

    printf("Compare finished. M=%d N=%d K=%d flag=%d\n", M, N, K, flag);
    printf("Elements compared: %zu, mismatches: %zu\n", cnt, mismatches);
    printf("max_abs_err=%g max_rel_err=%g L2_err=%g\n", max_abs, max_rel, l2);

    return mismatches == 0;
}


void ref_gemm_add_batch(const float* A1, const float* B1,
                        const float* A2, const float* B2,
                        float* C_out, int batch, int M, int N, int K)
{
    if (batch <= 0) return;
    const size_t batchA_stride = (size_t)M * (size_t)K; // elems per A in a batch
    const size_t batchB_stride = (size_t)K * (size_t)N;
    const size_t batchC_stride = (size_t)M * (size_t)N;

    for (int b = 0; b < batch; ++b) {
        const float* A1_b = A1 + (size_t)b * batchA_stride;
        const float* B1_b = B1 + (size_t)b * batchB_stride;
        const float* A2_b = A2 + (size_t)b * batchA_stride;
        const float* B2_b = B2 + (size_t)b * batchB_stride;
        float* Cb = C_out + (size_t)b * batchC_stride;
        ref_gemm_add(A1_b, B1_b, A2_b, B2_b, Cb, M, N, K);
    }
}

void blocked_gemm_add_batch(const float* A1, const float* B1,
                            const float* A2, const float* B2,
                            float* C_out, int batch, int M, int N, int K,
                            int Kc = 64, int Nb = 64)
{
    if (batch <= 0) return;
    const size_t batchA_stride = (size_t)M * (size_t)K;
    const size_t batchB_stride = (size_t)K * (size_t)N;
    const size_t batchC_stride = (size_t)M * (size_t)N;

    for (int b = 0; b < batch; ++b) {
        const float* A1_b = A1 + (size_t)b * batchA_stride;
        const float* B1_b = B1 + (size_t)b * batchB_stride;
        const float* A2_b = A2 + (size_t)b * batchA_stride;
        const float* B2_b = B2 + (size_t)b * batchB_stride;
        float* Cb = C_out + (size_t)b * batchC_stride;
        blocked_gemm_add(A1_b, B1_b, A2_b, B2_b, Cb, M, N, K, Kc, Nb);
    }
}

// ---------- batched diff-check function ----------

bool diff_check_A1B1_plus_A2B2_batch(const float* A1, const float* B1,
                                     const float* A2, const float* B2,
                                     const float* C_test, // may be nullptr
                                     int batch, int M, int N, int K,
                                     int flag = 0, // 0 -> reference (double accum), 1 -> blocked fast
                                     double rtol = 1e-5, double atol = 1e-6)
{
    if (batch <= 0) return true;

    const size_t total_elems = (size_t)batch * (size_t)M * (size_t)N;
    std::vector<float> C_ref(total_elems);

    // produce reference per-batch
    if (flag == 0) {
        ref_gemm_add_batch(A1, B1, A2, B2, C_ref.data(), batch, M, N, K);
    } else {
        // choose reasonable blocking parameters (could be tuned)
        blocked_gemm_add_batch(A1, B1, A2, B2, C_ref.data(), batch, M, N, K, 64, 64);
    }

    if (C_test == nullptr) {
        // nothing to compare, just computed reference
        return true;
    }

    double max_abs = 0.0;
    double max_rel = 0.0;
    long double l2_acc = 0.0L;
    size_t mismatches = 0;
    const size_t max_report = 20;
    size_t reports_printed = 0;

    // compare elementwise across batches
    for (int b = 0; b < batch; ++b) {
        const float* cref_b = C_ref.data() + (size_t)b * (size_t)M * (size_t)N;
        const float* ctest_b = C_test + (size_t)b * (size_t)M * (size_t)N;
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                size_t idx = (size_t)i * (size_t)N + (size_t)j;
                double refv = (double)cref_b[idx];
                double gotv = (double)ctest_b[idx];
                double abs_err = std::abs(refv - gotv);
                double rel_err = (std::abs(refv) > 0.0) ? abs_err / std::abs(refv) : abs_err;
                if (abs_err > max_abs) max_abs = abs_err;
                if (rel_err > max_rel) max_rel = rel_err;
                l2_acc += (long double)(refv - gotv) * (long double)(refv - gotv);

                if (!(abs_err <= atol + rtol * std::abs(refv))) {
                    ++mismatches;
                    if (reports_printed < max_report) {
                        printf("Mismatch batch %d at (%d,%d): ref=%g got=%g abs=%g rel=%g\n",
                               b, i, j, refv, gotv, abs_err, rel_err);
                        ++reports_printed;
                    }
                }
            }
        }
    }

    double l2 = std::sqrt((double)l2_acc);
    printf("Batched compare finished. batch=%d M=%d N=%d K=%d flag=%d\n", batch, M, N, K, flag);
    printf("Elements compared: %zu, mismatches: %zu\n", total_elems, mismatches);
    printf("max_abs_err=%g max_rel_err=%g L2_err=%g\n", max_abs, max_rel, l2);

    return mismatches == 0;
}

void int8_to_float_basic(const int8_t* src, float* dst, size_t rows, size_t cols,
                         float scale = 1.0f, int32_t zero_point = 0) {
    size_t N = rows * cols;
    for (size_t i = 0; i < N; ++i) {
        dst[i] = (static_cast<int32_t>(src[i]) - zero_point) * scale;
    }
}

bool diff_check_A1B1_plus_A2B2_batch_int(const float* A1, const int8_t* B1,
                                     const int8_t* A2, const float* B2,
                                     const float* C_test, // may be nullptr
                                     int batch, int M, int N, int K,
                                     int flag = 0, // 0 -> reference (double accum), 1 -> blocked fast
                                     double rtol = 1e-5, double atol = 1e-6)
{
    if (batch <= 0) return true;

    const size_t total_elems = (size_t)batch * (size_t)M * (size_t)N;
    std::vector<float> C_ref(total_elems);

    float* B1_float = (float*)std::malloc(sizeof(float) * batch * N * K);
    int8_to_float_basic(B1, B1_float, batch * N, K);

    float* A2_float = (float*)std::malloc(sizeof(float) * batch * M * N);
    int8_to_float_basic(A2, A2_float, batch * M, N);

    // printf("======================1=======================\n");
    // produce reference per-batch
    if (flag == 0) {
        ref_gemm_add_batch(A1, B1_float, A2_float, B2, C_ref.data(), batch, M, N, K);
    } else {
        // choose reasonable blocking parameters (could be tuned)
        blocked_gemm_add_batch(A1, B1_float, A2_float, B2, C_ref.data(), batch, M, N, K, 64, 64);
    }

    // printf("======================2======================\n");
    if (C_test == nullptr) {
        // nothing to compare, just computed reference
        return true;
    }

    double max_abs = 0.0;
    double max_rel = 0.0;
    long double l2_acc = 0.0L;
    size_t mismatches = 0;
    const size_t max_report = 20;
    size_t reports_printed = 0;

    // compare elementwise across batches
    for (int b = 0; b < batch; ++b) {
        const float* cref_b = C_ref.data() + (size_t)b * (size_t)M * (size_t)N;
        const float* ctest_b = C_test + (size_t)b * (size_t)M * (size_t)N;
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                size_t idx = (size_t)i * (size_t)N + (size_t)j;
                double refv = (double)cref_b[idx];
                double gotv = (double)ctest_b[idx];
                double abs_err = std::abs(refv - gotv);
                double rel_err = (std::abs(refv) > 0.0) ? abs_err / std::abs(refv) : abs_err;
                if (abs_err > max_abs) max_abs = abs_err;
                if (rel_err > max_rel) max_rel = rel_err;
                l2_acc += (long double)(refv - gotv) * (long double)(refv - gotv);

                if (!(abs_err <= atol + rtol * std::abs(refv))) {
                    ++mismatches;
                    if (reports_printed < max_report) {
                        printf("Mismatch batch %d at (%d,%d): ref=%g got=%g abs=%g rel=%g\n",
                               b, i, j, refv, gotv, abs_err, rel_err);
                        ++reports_printed;
                    }
                }
            }
        }
    }

    double l2 = std::sqrt((double)l2_acc);
    printf("Batched compare finished. batch=%d M=%d N=%d K=%d flag=%d\n", batch, M, N, K, flag);
    printf("Elements compared: %zu, mismatches: %zu\n", total_elems, mismatches);
    printf("max_abs_err=%g max_rel_err=%g L2_err=%g\n", max_abs, max_rel, l2);

    return mismatches == 0;
}

static double SparseDenseGustavsonAttention(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A1 = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B1 = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* A2 = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B2 = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A1 || !B1 || !A2 || !B2 || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            A1[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                B1[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                B1[i * K + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A2[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A2[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B2[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }


    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = Sparse_CSRXDense_Fast_Gustavson_Attention_yk(
        A1, B1, A2, B2, C, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    t_start = std::chrono::steady_clock::now();

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        diff_check_A1B1_plus_A2B2(A1, B1, A2, B2, C, M, K, N);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A1) { std::free(A1); A1 = nullptr; }
    if (B1) { std::free(B1); B1 = nullptr; }
    if (A2) { std::free(A2); A2 = nullptr; }
    if (B2) { std::free(B2); B2 = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonBatchAttentionTernary(int M, int N, int K, int B,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A1 = (float*)std::malloc(sizeof(float) * B * M * N);           /* BxM×N */
    int8_t* B1 = (int8_t*)std::malloc(sizeof(int8_t) * B * N * K);           /* BxN×K */
    int8_t* A2 = (int8_t*)std::malloc(sizeof(int8_t) * B * M * N);           /* BxM×N */
    float* B2 = (float*)std::malloc(sizeof(float) * B * N * K);           /* BxN×K */
    float* C = (float*)std::malloc(sizeof(float) * B * M * K);           /* BxM×K */
    if (!A1 || !B1 || !A2 || !B2 || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                A1[b * M * N + i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < K; ++j) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > sparsity) {
                    float r = static_cast<float>(std::rand()) / RAND_MAX;
                    if (r > 0.5){
                        B1[b * N * K + i * K + j] = 1;
                    }
                    else{
                        B1[b * N * K + i * K + j] = -1;
                    }
                }
                else {
                    B1[b * N * K + i * K + j] = 0.0f;
                }
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > sparsity) {
                    float r = static_cast<float>(std::rand()) / RAND_MAX;
                    if (r > 0.5){
                        A2[b * M * N + i * N + j] = 1;
                    }
                    else{
                        A2[b * M * N + i * N + j] = -1;
                    }
                }
                else {
                    A2[b * M * N + i * N + j] = 0.0f;
                }
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < K; ++j) {
                B2[b * N * K + i * K + j] = static_cast<float>(std::rand() % 11 - 5);
            }
        }
    }


    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_ternary(
        A1, B1, A2, B2, C, B, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    t_start = std::chrono::steady_clock::now();

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        diff_check_A1B1_plus_A2B2_batch_int(A1, B1, A2, B2, C, B, M, K, N);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A1) { std::free(A1); A1 = nullptr; }
    if (B1) { std::free(B1); B1 = nullptr; }
    if (A2) { std::free(A2); A2 = nullptr; }
    if (B2) { std::free(B2); B2 = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}


static double SparseDenseGustavsonBatchAttention(int M, int N, int K, int B,
    int flag, float sparsity1, float sparsity2)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A1 = (float*)std::malloc(sizeof(float) * B * M * N);           /* BxM×N */
    float* B1 = (float*)std::malloc(sizeof(float) * B * N * K);           /* BxN×K */
    float* A2 = (float*)std::malloc(sizeof(float) * B * M * N);           /* BxM×N */
    float* B2 = (float*)std::malloc(sizeof(float) * B * N * K);           /* BxN×K */
    float* C = (float*)std::malloc(sizeof(float) * B * M * K);           /* BxM×K */
    if (!A1 || !B1 || !A2 || !B2 || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                A1[b * M * N + i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < K; ++j) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > sparsity1) {
                    B1[b * N * K + i * K + j] = static_cast<float>(std::rand() % 11 - 5);
                }
                else {
                    B1[b * N * K + i * K + j] = 0.0f;
                }
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > sparsity2) {
                    A2[b * M * N + i * N + j] = static_cast<float>(std::rand() % 11 - 5);
                }
                else {
                    A2[b * M * N + i * N + j] = 0.0f;
                }
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < K; ++j) {
                B2[b * N * K + i * K + j] = static_cast<float>(std::rand() % 11 - 5);
            }
        }
    }


    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk(
        A1, B1, A2, B2, C, B, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    t_start = std::chrono::steady_clock::now();

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        diff_check_A1B1_plus_A2B2_batch(A1, B1, A2, B2, C, B, M, K, N);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A1) { std::free(A1); A1 = nullptr; }
    if (B1) { std::free(B1); B1 = nullptr; }
    if (A2) { std::free(A2); A2 = nullptr; }
    if (B2) { std::free(B2); B2 = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonBatchAttentionINT(int M, int N, int K, int B,
    int flag, float sparsity1, float sparsity2)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    int8_t* A2 = (int8_t*)std::malloc(sizeof(int8_t) * B * M * N);           /* BxM×N */
    int8_t* B2 = (int8_t*)std::malloc(sizeof(int8_t) * B * N * K);           /* BxN×K */
    float* C = (float*)std::malloc(sizeof(float) * B * M * K);           /* BxM×K */
    if ( !A2 || !B2 || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                float r = static_cast<float>(std::rand()) / RAND_MAX;
                if (r > sparsity2) {
                    A2[b * M * N + i * N + j] = static_cast<int8_t>(std::rand() % 11 - 5);
                }
                else {
                    A2[b * M * N + i * N + j] = 0.0f;
                }
            }
        }
    }

    for (int b = 0; b < B; ++b) {
        for (int i = 0; i < N; ++i) {
            for (int j = 0; j < K; ++j) {
                B2[b * N * K + i * K + j] = static_cast<int8_t>(std::rand() % 11 - 5);
            }
        }
    }


    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = GEMM_Batch_Attention_yk_int(
        A2, B2, C, B, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;

    t_start = std::chrono::steady_clock::now();

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_batch_bmm_int8_to_float_ref(A2, B2, C, B, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A2) { std::free(A2); A2 = nullptr; }
    if (B2) { std::free(B2); B2 = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonAttentioRowMajor(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A1 = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B1 = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* A2 = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B2 = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A1 || !B1 || !A2 || !B2 || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A1[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A1[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B1[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A2[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A2[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B2[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = Sparse_CSRXDense_Fast_Gustavson_Attention_row_major(
        A2, B2, C, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;


    t_start = std::chrono::steady_clock::now();

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d(A2, B2, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A1) { std::free(A1); A1 = nullptr; }
    if (B1) { std::free(B1); B1 = nullptr; }
    if (A2) { std::free(A2); A2 = nullptr; }
    if (B2) { std::free(B2); B2 = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}

static double SparseDenseGustavsonAttentionColumnMajor(int M, int N, int K,
    int flag, float sparsity)
{
    /* 1. 生成稀疏 A（Row-Major）、稠密 B */
    float* A1 = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B1 = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* A2 = (float*)std::malloc(sizeof(float) * M * N);           /* M×N */
    float* B2 = (float*)std::malloc(sizeof(float) * N * K);           /* N×K */
    float* C = (float*)std::malloc(sizeof(float) * M * K);           /* M×K */
    if (!A1 || !B1 || !A2 || !B2 || !C) {
        printf("Memory allocation failed\n");
        std::exit(1);
    }

    // 固定随机数生成器（Mersenne Twister）
    std::srand(1024);

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            A1[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                B1[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                B1[i * K + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < M; ++i) {
        for (int j = 0; j < N; ++j) {
            float r = static_cast<float>(std::rand()) / RAND_MAX;
            if (r > sparsity) {
                A2[i * N + j] = static_cast<float>(std::rand() % 11 - 5);
            }
            else {
                A2[i * N + j] = 0.0f;
            }
        }
    }

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < K; ++j) {
            B2[i * K + j] = static_cast<float>(std::rand() % 11 - 5);
        }
    }

    auto t_start = std::chrono::steady_clock::now();

    bool success = false;
    success = Sparse_CSRXDense_Fast_Gustavson_Attention_column_major(
        A1, B1, C, M, N, K, flag
    );
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;


    t_start = std::chrono::steady_clock::now();

    // if (success) {
    //    if (M * K <= 1000000) { // 验证
    //        printf("Starting verification...\n");
    //        verify_result_1d(A1, B1, C, M, N, K);
    //    }
    //    else {
    //        printf("Matrix too large for verification (%d elements), skipping...\n", M * K);
    //    }
    // }
    // else {
    //    printf("Gustavson SpMM failed!\n");
    // }

    if (A1) { std::free(A1); A1 = nullptr; }
    if (B1) { std::free(B1); B1 = nullptr; }
    if (A2) { std::free(A2); A2 = nullptr; }
    if (B2) { std::free(B2); B2 = nullptr; }
    if (C) { std::free(C); C = nullptr; }
    return diff.count();
}


// code in pytorch
// def multi1(x1_t,x2_t,x1_sum_t,x2_sum_t):
//     if (not torch.is_tensor(x2_sum_t)) or len(x2_sum_t.shape) == 0:
//         return x1_sum_t @ x2_t
//     else:
//         return x1_sum_t @ x2_t + x1_t @ x2_sum_t
bool Sparse_CSRXDense_Fast_Gustavson_Attention_yk(
    float* denseA1,
    float* denseB1,
    float* denseA2,
    float* denseB2,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // printf("=============1===================\n");
    std::vector<int> rowCounts1(colsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < colsA; ++i) {
        int c1 = 0;
        float* Bi_1 = denseB1 + (size_t)i * colsC;
        for (int j = 0; j < colsC; ++j) c1 += (Bi_1[j] != 0.0f);
        rowCounts1[i] = c1;
    }

    std::vector<MKL_INT> row_ptr1(colsA + 1, 0);
    for (int i = 0; i < colsA; ++i) row_ptr1[i + 1] = row_ptr1[i] + rowCounts1[i];
    MKL_INT nnz1 = row_ptr1[colsA];
    std::vector<MKL_INT> col_idx1((size_t)nnz1);
    std::vector<float> val1((size_t)nnz1);

    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < colsA; ++i) {
        int base = row_ptr1[i], off1 = 0;
        float* Bi_1 = denseB1 + (size_t)i * colsC;
        for (int j = 0; j < colsC; ++j) {
            float x1 = Bi_1[j];
            if (x1 != 0.0f) {
                int addr1 = base + off1;
                col_idx1[addr1] = (MKL_INT)j;
                val1[addr1] = x1;
                ++off1;
            }
        }
    }

    std::vector<int> rowCounts2(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c2 = 0;
        float* Ai_2 = denseA2 + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            c2 += (Ai_2[j] != 0.0f);
        }
        rowCounts2[i] = c2;
    }

    std::vector<MKL_INT> row_ptr2(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr2[i + 1] = row_ptr2[i] + rowCounts2[i];
    MKL_INT nnz2 = row_ptr2[rowsA];
    float density2 = (float)nnz2/(float)(rowsA*colsA);
    std::vector<MKL_INT> col_idx2((size_t)nnz2);
    std::vector<float> val2((size_t)nnz2);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr2[i], off2 = 0;
        float* Ai_2 = denseA2 + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x_2 = Ai_2[j];
            if (x_2 != 0.0f) {
                int addr2 = base + off2; 
                col_idx2[addr2] = (MKL_INT)j; 
                val2[addr2] = x_2; 
                ++off2; 
            }
        }
    }    
    // printf("=============2===================\n");

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // printf("=============3===================\n");
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 32, Nb = std::min(colsC, 32);
    int Rb = 32;

    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    // 修正：保证 Nb 不会超过 colsC，同时尽量偏好 16 这一粒度
    Nb = std::min(colsC, std::max(16, Nb));
    Rb = std::max(1, std::min(Rb, rowsA));

    // printf("=============4===================\n");
    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p1 = row_ptr1.data();
            const MKL_INT* col_idx_p1 = col_idx1.data();
            const float* val_p1 = val1.data();
            float* denseA_p1 = denseA1;

            const MKL_INT* row_ptr_p2 = row_ptr2.data();
            const MKL_INT* col_idx_p2 = col_idx2.data();
            const float* val_p2 = val2.data();
            float* denseB_p2 = denseB2;

            float* denseC_p = denseC;

            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems1 = (size_t)Kc * (size_t)Rb;
            void* packed_tmp1 = portable_aligned_alloc(ACC_ALIGN, pack_elems1 * sizeof(float));
            bool packed_portable1 = true;
            if (!packed_tmp1) {
                packed_tmp1 = malloc(pack_elems1 * sizeof(float));
                packed_portable1 = false;
            }

            size_t pack_elems2 = (size_t)Kc * (size_t)Nb;
            void* packed_tmp2 = portable_aligned_alloc(ACC_ALIGN, pack_elems2 * sizeof(float));
            bool packed_portable2 = true;
            if (!packed_tmp2) {
                packed_tmp2 = malloc(pack_elems2 * sizeof(float));
                packed_portable2 = false;
            }
            // printf("=============5===================\n");

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            // printf("=============6===================\n");

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;
                
                // printf("=============7===================\n");
                float* packedB = (float*)packed_tmp2;
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p2 + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                }

                // pack A rows for this tile: rb_eff x kc_eff
                float* packedA = (float*)packed_tmp1;
                for (int mm = 0; mm < rb_eff; ++mm) {
                    const float* Arow = denseA_p1 + (size_t)(rb + mm) * (size_t)colsA + (size_t)kb;
                    float* dest = packedA + (size_t)mm * (size_t)kc_eff;
                    if (kc_eff > 0) memcpy(dest, Arow, sizeof(float) * (size_t)kc_eff);
                }


                // printf("=============8===================\n");
                // row major calculation 2
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr2[i], end = row_ptr2[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx2.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p2[p];
                        float v = val_p2[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
                
                // printf("=============9===================\n");
                // col major calculation 1
                for (int local_k = 0; local_k < kc_eff; ++local_k) {
                    int global_k = kb + local_k;
                    MKL_INT p_start = row_ptr_p1[global_k];
                    MKL_INT p_end = row_ptr_p1[global_k + 1];
                    MKL_INT row_nnz = p_end - p_start;
                    if (row_nnz <= 0) continue;

                    // base 指向该行在 col_idx 数组的起点（已排好序）
                    const MKL_INT* base = col_idx_p1 + p_start;

                    // 在该行的 col_idx 子数组上做二分：找到第一个 >= cb 和第一个 >= cb+nb_eff
                    const MKL_INT* p0 = std::lower_bound(base, base + row_nnz, (MKL_INT)cb);
                    const MKL_INT* p1 = std::lower_bound(base, base + row_nnz, (MKL_INT)(cb + nb_eff));

                    if (p0 == p1) continue; // 这一行在本列块没有非零

                    // 转回全局索引位置（注意：p0-base + p_start == p0 - col_idx_p）
                    MKL_INT it0 = (MKL_INT)(p0 - col_idx_p1);
                    MKL_INT it1 = (MKL_INT)(p1 - col_idx_p1);

                    // 遍历局部区间，避免每个元素再做范围判断
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        float A_value = packedA[(size_t)local_i * (size_t)kc_eff + (size_t)local_k];
                        float* acc_row = acc_tile_buf + (size_t)local_i * (size_t)acc_elems_per_row;
                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT j = col_idx_p1[p];
                            int dst = (int)(j - cb);        // 0..nb_eff-1
                            float vb = val_p1[p];
                            acc_row[dst] += A_value * vb;
                        }
                    }
                }
                // printf("=============10===================\n");
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            // printf("=============11===================\n");
            if (packed_tmp1) { if (packed_portable1) portable_aligned_free(packed_tmp1); else free(packed_tmp1); }
            if (packed_tmp2) { if (packed_portable2) portable_aligned_free(packed_tmp2); else free(packed_tmp2); }
            if (acc_tile_buf_tmp) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp); }
        }
    }

    return true;
}





// Main function: batch-parallel Gustavson-like fused A1@B1 + A2@B2
bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk(
    float* denseA1,   // [batch][rowsA][colsA]
    float* denseB1,   // [batch][colsA][colsC]
    float* denseA2,   // [batch][rowsA][colsA]
    float* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;
    
    // Precompute tiling parameters (global)
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 8;
    // auto t_start = std::chrono::steady_clock::now();
    // -------- Allocate per-batch containers (vectors) ----------
    // B1 CSR: rows = colsA, cols = colsC  (one CSR per batch)
    // std::vector<std::vector<int>> rowCounts1_batch(batch, std::vector<int>(colsA));
    int16_t* rowCounts1_batch = (int16_t*)malloc(sizeof(int16_t) * batch * colsA);
    MKL_INT* row_ptr1_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (colsA + 1));
    // std::vector<std::vector<MKL_INT>> row_ptr1_batch(batch);
    std::vector<std::vector<int16_t>> col_idx1_batch(batch);
    std::vector<std::vector<float>>   val1_batch(batch);

    // A2 CSR: rows = rowsA, cols = colsA (one CSR per batch)
    // std::vector<std::vector<int>> rowCounts2_batch(batch, std::vector<int>(rowsA));
    int16_t* rowCounts2_batch = (int16_t*)malloc(sizeof(int16_t) * batch * rowsA);
    MKL_INT* row_ptr2_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (rowsA + 1));
    // std::vector<std::vector<MKL_INT>> row_ptr2_batch(batch);
    std::vector<std::vector<int16_t>> col_idx2_batch(batch);
    std::vector<std::vector<float>>   val2_batch(batch);
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (define variables): %.6f s\n",
    //    diff.count());

    // --- Step 1: compute rowCounts for B1 and A2 in parallel (collapse over batch & row) ---
    // B1 rowCounts: iterate over (b, i) where i in [0, colsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < colsA; ++i) {
            int cnt = 0;
            float* Bi = denseB1 + (size_t)b * (size_t)colsA * (size_t)colsC + (size_t)i * (size_t)colsC;
            for (int j = 0; j < colsC; ++j) if (Bi[j] != 0.0f) ++cnt;
            rowCounts1_batch[b*colsA+i] = cnt;
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (compute rowCounts for B1): %.6f s\n",
    //    diff.count());


    // A2 rowCounts: iterate over (b, i) where i in [0, rowsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            int cnt = 0;
            float* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) if (Ai[j] != 0.0f) ++cnt;
            rowCounts2_batch[b*rowsA + i] = cnt;
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (compute rowCounts for A2): %.6f s\n",
    //    diff.count());

    // --- Step 2: build row_ptr arrays and allocate col_idx/val per batch (parallel over b) ---
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        // B1
        // row_ptr1_batch[b].resize(colsA + 1);
        row_ptr1_batch[b*(colsA + 1)] = 0;
        for (int i = 0; i < colsA; ++i) row_ptr1_batch[b*(colsA + 1) + i+1] = row_ptr1_batch[b*(colsA + 1) + i] + rowCounts1_batch[b*colsA+i];
        MKL_INT nnz1 = row_ptr1_batch[b*(colsA + 1) + colsA];
        col_idx1_batch[b].assign((size_t)nnz1, 0);
        val1_batch[b].assign((size_t)nnz1, 0.0f);

        // A2
        // row_ptr2_batch[b].resize(rowsA + 1);
        row_ptr2_batch[b * (rowsA + 1)] = 0;
        for (int i = 0; i < rowsA; ++i) row_ptr2_batch[b * (rowsA + 1) + i+1] = row_ptr2_batch[b * (rowsA + 1) + i] + rowCounts2_batch[b*rowsA + i];
        MKL_INT nnz2 = row_ptr2_batch[b * (rowsA + 1) + rowsA];
        col_idx2_batch[b].assign((size_t)nnz2, 0);
        val2_batch[b].assign((size_t)nnz2, 0.0f);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (count nnz): %.6f s\n",
    //    diff.count());

    // --- Step 3: fill col_idx/val for B1 and A2 in parallel (collapse to distribute work) ---
    // fill B1 CSR: iterate (b, i in colsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < colsA; ++i) {
            MKL_INT base = row_ptr1_batch[b*(colsA + 1) + i];
            int off = 0;
            float* Bi = denseB1 + (size_t)b * (size_t)colsA * (size_t)colsC + (size_t)i * (size_t)colsC;
            for (int j = 0; j < colsC; ++j) {
                float x = Bi[j];
                if (x != 0.0f) {
                    MKL_INT idx = base + off++;
                    col_idx1_batch[b][idx] = (MKL_INT)j;
                    val1_batch[b][idx] = x;
                }
            }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (fill col_idx/val for B1): %.6f s\n",
    //    diff.count());

    // fill A2 CSR: iterate (b, i in rowsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            MKL_INT base = row_ptr2_batch[b * (rowsA + 1) + i];
            int off = 0;
            float* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) {
                float x = Ai[j];
                if (x != 0.0f) {
                    MKL_INT idx = base + off++;
                    col_idx2_batch[b][idx] = (MKL_INT)j;
                    val2_batch[b][idx] = x;
                }
            }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (fill col_idx/val for A2): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
    // --- zero out denseC (per-batch, per-row) ---
    #pragma omp parallel num_threads(64)
    {
        int nt = omp_get_num_threads();
        // 可选：根据情况只用 min(nt, batch)
        #pragma omp for schedule(static)
        for (int b = 0; b < batch; ++b) {
            float* Cb = denseC + (size_t)b * (size_t)rowsA * (size_t)colsC;
            for (int i = 0; i < rowsA; ++i) {
                float* Crow = Cb + (size_t)i * (size_t)colsC;
                memset(Crow, 0, (size_t)colsC * sizeof(float));
            }
        }
    }

    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (zero denseC): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
    // --- Preallocate per-thread temporary buffers to avoid repeated malloc/free ---
    int num_threads = 64;
    // std::vector<void*> thread_packedA(num_threads, nullptr);
    // std::vector<void*> thread_packedB(num_threads, nullptr);
    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    // std::vector<size_t> thread_packedA_size(num_threads, 0);
    // std::vector<size_t> thread_packedB_size(num_threads, 0);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    size_t max_packA_elems = (size_t)Kc * (size_t)Rb; // packedA capacity per thread (rows x Kc)
    size_t max_packB_elems = (size_t)Kc * (size_t)Nb; // packedB capacity per thread (Kc x Nb)
    int max_acc_elems_per_row = ((Nb + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;
    
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        // size_t bytesA = max_packA_elems * sizeof(float);
        // void* pA = portable_aligned_alloc(ACC_ALIGN, bytesA);
        // if (!pA) pA = malloc(bytesA);
        // thread_packedA[t] = pA; thread_packedA_size[t] = bytesA;

        // size_t bytesB = max_packB_elems * sizeof(float);
        // void* pB = portable_aligned_alloc(ACC_ALIGN, bytesB);
        // if (!pB) pB = malloc(bytesB);
        // thread_packedB[t] = pB; thread_packedB_size[t] = bytesB;

        size_t bytesAcc = max_acc_tile_elems * sizeof(float);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc; thread_acc_tile_size[t] = bytesAcc;
    }

    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (C packing): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
       // -------- Main compute: parallelize over (b, rb) to cover batch and row-blocks ----------
    #pragma omp parallel for collapse(2) num_threads(64) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                // pointer bases for this batch
                float* denseA_p1 = denseA1 + (size_t)b * (size_t)rowsA * (size_t)colsA;
                float* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                const MKL_INT* row_ptr_p1 = row_ptr1_batch + b*(colsA + 1);
                const int16_t* col_idx_p1 = col_idx1_batch[b].data();
                const float*   val_p1     = val1_batch[b].data();

                const MKL_INT* row_ptr_p2 = row_ptr2_batch + b * (rowsA + 1);
                const int16_t* col_idx_p2 = col_idx2_batch[b].data();
                const float*   val_p2     = val2_batch[b].data();

                int rb_eff = std::min(Rb, rowsA - rb);

                // local per-thread buffers (preallocated)
                // float* packedA = (float*)thread_packedA[tid];
                // float* packedB = (float*)thread_packedB[tid];
                float* acc_tile = (float*)thread_acc_tile[tid];


                int nb_eff = std::min(Nb, colsC - cb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;

                // init acc_tile from C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // loop over k-blocks
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0 || nb_eff == 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    // pack B2 block: kc_eff x nb_eff into packedB
                    // for (int kk = 0; kk < kc_eff; ++kk) {
                    //     const float* Brow = denseB_p2 + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    //     float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    //     if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // }

                    // pack A1 rows for this tile: rb_eff x kc_eff (stride = kc_eff)
                    // for (int mm = 0; mm < rb_eff; ++mm) {
                    //     const float* Arow = denseA_p1 + (size_t)(rb + mm) * (size_t)colsA + (size_t)kb;
                    //     float* dest = packedA + (size_t)mm * (size_t)kc_eff;
                    //     if (kc_eff > 0) memcpy(dest, Arow, sizeof(float) * (size_t)kc_eff);
                    // }

                    // --- Row-major calculation using A2 CSR and packedB ---
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr_p2[i], end = row_ptr_p2[i + 1];
                        if (start >= end) continue;
                        const int16_t* base = col_idx_p2;
                        const int16_t* s = base + start;
                        const int16_t* e = base + end;

                        const int16_t* p0ptr = std::lower_bound(s, e, (MKL_INT)kb);
                        const int16_t* p1ptr = std::lower_bound(p0ptr, e, (MKL_INT)(kb + kc_eff));
                        if (p0ptr == p1ptr) continue;
                        MKL_INT it0 = (MKL_INT)(p0ptr - base);
                        MKL_INT it1 = (MKL_INT)(p1ptr - base);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p2[p];
                            float v = val_p2[p];
                            int k_rel = (int)(k_col - kb);
                            if (k_rel < 0 || k_rel >= kc_eff) continue;
                            // const float* Brow = packedB + (size_t)k_rel * (size_t)nb_eff;
                            const float* Brow_global = denseB_p2 + (size_t)k_col * (size_t)colsC + (size_t)cb;
                            __m256 vv = _mm256_set1_ps(v);
                            int j = 0;
                            for (; j < vec_end; j += VEC_WIDTH) {
                                __m256 accv = _mm256_loadu_ps(acc_row + j);
                                __m256 bvec = _mm256_loadu_ps(Brow_global + j);
                                accv = _mm256_fmadd_ps(vv, bvec, accv);
                                _mm256_storeu_ps(acc_row + j, accv);
                            }
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow_global[jj];
                            }
                        }
                    }

                    // --- Col-major calculation using B1 CSR and packedA ---
                    for (int local_k = 0; local_k < kc_eff; ++local_k) {
                        int global_k = kb + local_k;
                        MKL_INT p_start = row_ptr_p1[global_k];
                        MKL_INT p_end   = row_ptr_p1[global_k + 1];
                        MKL_INT row_nnz = p_end - p_start;
                        if (row_nnz <= 0) continue;

                        const int16_t* base = col_idx_p1 + p_start;
                        const int16_t* p0 = std::lower_bound(base, base + row_nnz, (MKL_INT)cb);
                        const int16_t* p1 = std::lower_bound(p0, base + row_nnz, (MKL_INT)(cb + nb_eff));
                        if (p0 == p1) continue;
                        MKL_INT it0 = (MKL_INT)(p0 - col_idx_p1);
                        MKL_INT it1 = (MKL_INT)(p1 - col_idx_p1);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT jidx = col_idx_p1[p];
                            int dst = (int)(jidx - cb);
                            float vb = val_p1[p];
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                // float A_value = packedA[(size_t)local_i * (size_t)kc_eff + (size_t)local_k];
                                const float* Arow_global = denseA_p1 + (size_t)(rb + local_i) * (size_t)colsA;
                                float A_value = Arow_global[(size_t)kb + (size_t)local_k]; // element A[rb+local_i, kb+local_k]
                                float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                                acc_row[dst] += A_value * vb;
                            }
                        }
                    }
                } // kb
                // write back acc_tile into C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_loadu_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
            } // cb
        } // rb
    } // parallel over (b, rb)
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (computing): %.6f s\n",
    //    diff.count());
    
    // t_start = std::chrono::steady_clock::now();
    // free per-thread buffers
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        // if (thread_packedA[t]) portable_aligned_free(thread_packedA[t]);
        // if (thread_packedB[t]) portable_aligned_free(thread_packedB[t]);
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (free C): %.6f s\n",
    //    diff.count());

    return true;
}


// Main function: batch-parallel Gustavson-like fused A1@B1 + A2@B2
bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;
    
    // Precompute tiling parameters (global)
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 8;

    int16_t* rowCounts2_batch = (int16_t*)malloc(sizeof(int16_t) * batch * rowsA);
    MKL_INT* row_ptr2_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (rowsA + 1));
    std::vector<std::vector<int16_t>> col_idx2_batch(batch);
    std::vector<std::vector<int8_t>>   val2_batch(batch);

    auto t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            int cnt = 0;
            int8_t* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) if (Ai[j] != int8_t(0)) ++cnt;
            rowCounts2_batch[b*rowsA + i] = cnt;
        }
    }

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        // A2
        // row_ptr2_batch[b].resize(rowsA + 1);
        row_ptr2_batch[b * (rowsA + 1)] = 0;
        for (int i = 0; i < rowsA; ++i) row_ptr2_batch[b * (rowsA + 1) + i+1] = row_ptr2_batch[b * (rowsA + 1) + i] + rowCounts2_batch[b*rowsA + i];
        MKL_INT nnz2 = row_ptr2_batch[b * (rowsA + 1) + rowsA];
        col_idx2_batch[b].assign((size_t)nnz2, 0);
        val2_batch[b].assign((size_t)nnz2, int8_t(0));
    }

    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            MKL_INT base = row_ptr2_batch[b * (rowsA + 1) + i];
            int off = 0;
            int8_t* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) {
                int8_t x = Ai[j];
                if (x != int8_t(0)) {
                    MKL_INT idx = base + off++;
                    col_idx2_batch[b][idx] = (MKL_INT)j;
                    val2_batch[b][idx] = x;
                }
            }
        }
    }
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    printf("Sparse×Dense (build CSR): %.6f s\n",
       diff.count());

    #pragma omp parallel num_threads(64)
    {
        int nt = omp_get_num_threads();
        // 可选：根据情况只用 min(nt, batch)
        #pragma omp for schedule(static)
        for (int b = 0; b < batch; ++b) {
            float* Cb = denseC + (size_t)b * (size_t)rowsA * (size_t)colsC;
            for (int i = 0; i < rowsA; ++i) {
                float* Crow = Cb + (size_t)i * (size_t)colsC;
                memset(Crow, 0, (size_t)colsC * sizeof(float));
            }
        }
    }

    // --- Preallocate per-thread temporary buffers to avoid repeated malloc/free ---
    int num_threads = 64;
    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    size_t max_packA_elems = (size_t)Kc * (size_t)Rb; // packedA capacity per thread (rows x Kc)
    size_t max_packB_elems = (size_t)Kc * (size_t)Nb; // packedB capacity per thread (Kc x Nb)
    int max_acc_elems_per_row = ((Nb + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;
    
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        size_t bytesAcc = max_acc_tile_elems * sizeof(float);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc; thread_acc_tile_size[t] = bytesAcc;
    }

    #pragma omp parallel for collapse(2) num_threads(64) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                // pointer bases for this batch
                int8_t* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                const MKL_INT* row_ptr_p2 = row_ptr2_batch + b * (rowsA + 1);
                const int16_t* col_idx_p2 = col_idx2_batch[b].data();
                const int8_t*   val_p2     = val2_batch[b].data();

                int rb_eff = std::min(Rb, rowsA - rb);

                float* acc_tile = (float*)thread_acc_tile[tid];


                int nb_eff = std::min(Nb, colsC - cb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;

                // init acc_tile from C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // loop over k-blocks
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0 || nb_eff == 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    // --- Row-major calculation using A2 CSR and packedB ---
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr_p2[i], end = row_ptr_p2[i + 1];
                        if (start >= end) continue;
                        const int16_t* base = col_idx_p2;
                        const int16_t* s = base + start;
                        const int16_t* e = base + end;

                        const int16_t* p0ptr = std::lower_bound(s, e, (MKL_INT)kb);
                        const int16_t* p1ptr = std::lower_bound(p0ptr, e, (MKL_INT)(kb + kc_eff));
                        if (p0ptr == p1ptr) continue;
                        MKL_INT it0 = (MKL_INT)(p0ptr - base);
                        MKL_INT it1 = (MKL_INT)(p1ptr - base);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p2[p];
                            int8_t v = val_p2[p];
                            int k_rel = (int)(k_col - kb);
                            if (k_rel < 0 || k_rel >= kc_eff) continue;

                            // B 在全局布局为 denseB_p2 [colsA x colsC], 取第 k_col 行起始处再偏移 cb
                            const int8_t* Brow_global = (const int8_t*)(denseB_p2 + (size_t)k_col * (size_t)colsC + (size_t)cb);

                            // 把标量 v 转为 float 向量
                            __m256 vv_f = _mm256_set1_ps((float)v);

                            int j = 0;
                            // vec_end 预先计算为 nb_eff - (nb_eff % VEC_WIDTH)
                            for (; j < vec_end; j += VEC_WIDTH) {
                                // load 8 int8 bytes from Brow_global + j
                                __m128i b8 = _mm_loadl_epi64((const __m128i*)(Brow_global + j)); // loads 8 bytes into low 64 bits
                                // widen int8 -> int32 (8 lanes)
                                __m256i b32 = _mm256_cvtepi8_epi32(b8);
                                // convert int32 -> float
                                __m256 b_f = _mm256_cvtepi32_ps(b32);

                                // load acc_row (float) and fmadd: acc += v * b
                                __m256 accv = _mm256_loadu_ps(acc_row + j);
                                accv = _mm256_fmadd_ps(vv_f, b_f, accv);
                                _mm256_storeu_ps(acc_row + j, accv);
                            }

                            // tail scalar
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) {
                                    acc_row[jj] += (float)v * (float)Brow_global[jj];
                                }
                            }
                        }
                    }
                } // kb
                // write back acc_tile into C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_loadu_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
            } // cb
        } // rb
    } // parallel over (b, rb)

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }

    return true;
}


// Main function: batch-parallel Gustavson-like fused A1@B1 + A2@B2
bool GEMM_Batch_Attention_yk_int(
    int8_t* __restrict denseA2,   // [batch][rowsA][colsA]
    int8_t* __restrict denseB2,   // [batch][colsA][colsC]
    float* __restrict denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;

    #ifdef MKL_MAJOR_VERSION
    mkl_set_num_threads(1);
    #endif

    int Kc = 197, Nb = std::min(colsC, 128);
    int Rb = 8;

    if(rowsA == 197 && colsA == 128 && colsC == 197){
        Rb = 8, Kc = 128, Nb = 197;
    }
    else if(rowsA == 197 && colsA == 197 && colsC == 128){
        Rb = 16, Kc = 197, Nb = 128;
    }

    int num_threads = 64;

    const int MADDUBS_PAIR_OUT = 32; // 每次 _mm512_maddubs 处理后对应 32 列输出 (64 bytes in)
    const int BYTES_PER_LOAD = 64;   // 64 bytes per _mm512_loadu_si512 for packed pairs

    // 每线程 acc tile (int32)
    int max_acc_elems_per_row = ((Nb + 15) / 16) * 16; // 16 alignment for safeness
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;

    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    #pragma omp parallel for num_threads(num_threads) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        size_t bytesAcc = max_acc_tile_elems * sizeof(int32_t);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc;
        thread_acc_tile_size[t] = bytesAcc;
        if (pAcc) memset(pAcc, 0, bytesAcc);
    }

    // constants used in inner kernel
    const __m512i xor_0x80_8 = _mm512_set1_epi8((char)0x80); // for unsigned conversion trick
    const __m512i ones8 = _mm512_set1_epi8((char)1);         // for pair sum via maddubs
    const __m512i zero512 = _mm512_setzero_si512();
    const __mmask64 alt_mask = 0xAAAAAAAAAAAAAAAAULL; // alternate bytes mask: 1 on odd bytes

    #pragma omp parallel for collapse(2) num_threads(num_threads) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                int8_t* denseA_p2 = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA;
                int8_t* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                int rb_eff = std::min(Rb, rowsA - rb);
                int32_t* acc_tile = (int32_t*)thread_acc_tile[tid];

                int nb_eff = std::min(Nb, colsC - cb);
                if (nb_eff == 0) continue;
                int acc_elems_per_row = ((nb_eff + 15) / 16) * 16;

                // init acc_tile from C: float -> int32 (truncate)
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    int32_t* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + 16 - 1 < nb_eff; j += 16) {
                        __m512 vf = _mm512_loadu_ps(Crow + j);
                        __m512i vi = _mm512_cvtps_epi32(vf);
                        _mm512_storeu_si512((void*)(dest_row + j), vi);
                    }
                    for (; j < nb_eff; ++j) dest_row[j] = (int32_t) Crow[j];
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0;
                }

                // main k-block loop: process p in pairs (p, p+1) to use maddubs
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0) continue;

                    // process p in pairs
                    int p = 0;
                    for (; p + 1 < kc_eff; p += 2) {
                        int k_index0 = kb + p;
                        int k_index1 = kb + p + 1;

                        // process columns in chunks of 32 outputs (64 bytes interleaved)
                        for (int jcol = 0; jcol < nb_eff; jcol += MADDUBS_PAIR_OUT) {
                            int chunk = std::min(MADDUBS_PAIR_OUT, nb_eff - jcol);
                            // if chunk < MADDUBS_PAIR_OUT, fallback to scalar per-column path
                            if (chunk < MADDUBS_PAIR_OUT) break;

                            // pack B: interleave B[k_index0, cb+jcol + idx] and B[k_index1, cb+jcol + idx]
                            // into 64-byte buffer: [b0_0, b1_0, b0_1, b1_1, ...]
                            alignas(64) int8_t b_interleaved[BYTES_PER_LOAD];
                            for (int idx = 0; idx < MADDUBS_PAIR_OUT; ++idx) {
                                b_interleaved[2*idx    ] = *(denseB_p2 + (size_t)k_index0 * (size_t)colsC + (size_t)(cb + jcol + idx));
                                b_interleaved[2*idx + 1] = *(denseB_p2 + (size_t)k_index1 * (size_t)colsC + (size_t)(cb + jcol + idx));
                            }
                            __m512i vb = _mm512_loadu_si512((const void*)b_interleaved); // 64 bytes load

                            // precompute sum_b_pairs16 = b0 + b1 for each pair (as int16 -> later to int32)
                            __m512i sum_b_pairs16 = _mm512_maddubs_epi16(ones8, vb); // 32 x int16

                            // For each local row, form a_pair = [a0,a1,a0,a1,...] and apply maddubs
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                int a_row = rb + local_i;
                                const int8_t a0 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index0);
                                const int8_t a1 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index1);

                                // build a_pair vector: alternate bytes (a0,a1,a0,a1,...)
                                __m512i a0v = _mm512_set1_epi8((char)a0);
                                __m512i a1v = _mm512_set1_epi8((char)a1);
                                __m512i a_pair = _mm512_mask_mov_epi8(a0v, alt_mask, a1v); // odd lanes take a1

                                // convert a_pair to unsigned domain by xor 0x80
                                __m512i a_pair_u = _mm512_xor_si512(a_pair, xor_0x80_8);

                                // prod16 = maddubs(a_pair_u, vb) -> 32 x int16 = (a^128)*b
                                __m512i prod16 = _mm512_maddubs_epi16(a_pair_u, vb); // 32 x int16

                                // sum_b_pairs16 already computed: sum_b_pairs16 = b0 + b1 (int16)
                                // Need to compute correction = 128 * sum_b_pairs (in int32), since:
                                // prod16 = (a^128)*b = a*b + 128*b  => a*b = prod16 - 128 * sum_b_pairs

                                // convert prod16 (32xint16) -> two halves of 16xint32
                                __m256i prod16_lo_256 = _mm512_castsi512_si256(prod16); // low 256 bits
                                __m256i prod16_hi_256 = _mm512_extracti64x4_epi64(prod16, 1); // high 256 bits

                                __m512i prod32_lo = _mm512_cvtepi16_epi32(prod16_lo_256); // 16 x int32
                                __m512i prod32_hi = _mm512_cvtepi16_epi32(prod16_hi_256); // 16 x int32

                                // convert sum_b_pairs16 -> int32 halves and compute correction = sum_b_pairs * 128
                                __m256i sum16_lo_256 = _mm512_castsi512_si256(sum_b_pairs16);
                                __m256i sum16_hi_256 = _mm512_extracti64x4_epi64(sum_b_pairs16, 1);
                                __m512i sum32_lo = _mm512_cvtepi16_epi32(sum16_lo_256);
                                __m512i sum32_hi = _mm512_cvtepi16_epi32(sum16_hi_256);

                                __m512i corr32_lo = _mm512_slli_epi32(sum32_lo, 7); // *128
                                __m512i corr32_hi = _mm512_slli_epi32(sum32_hi, 7);

                                // final product (a*b) in int32 lanes
                                __m512i final32_lo = _mm512_sub_epi32(prod32_lo, corr32_lo);
                                __m512i final32_hi = _mm512_sub_epi32(prod32_hi, corr32_hi);

                                // accumulate into acc_tile
                                int32_t* dst_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row + jcol;
                                // load current acc 16 int32 (lo)
                                __m512i acc_lo = _mm512_loadu_si512((const void*)(dst_row + 0));
                                acc_lo = _mm512_add_epi32(acc_lo, final32_lo);
                                _mm512_storeu_si512((void*)(dst_row + 0), acc_lo);

                                // load current acc 16 int32 (hi)
                                __m512i acc_hi = _mm512_loadu_si512((const void*)(dst_row + 16));
                                acc_hi = _mm512_add_epi32(acc_hi, final32_hi);
                                _mm512_storeu_si512((void*)(dst_row + 16), acc_hi);
                            } // local_i
                        } // jcol chunks of 32

                        // handle remaining columns < 32 in this pair with scalar or vector int32 path
                        int rem_start = (nb_eff / MADDUBS_PAIR_OUT) * MADDUBS_PAIR_OUT;
                        for (int jj = rem_start; jj < nb_eff; ++jj) {
                            int col_j = cb + jj;
                            int8_t b0 = *(denseB_p2 + (size_t)k_index0 * (size_t)colsC + (size_t)col_j);
                            int8_t b1 = *(denseB_p2 + (size_t)k_index1 * (size_t)colsC + (size_t)col_j);
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                int a_row = rb + local_i;
                                int8_t a0 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index0);
                                int8_t a1 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index1);
                                int32_t addv = (int32_t)((int)a0 * (int)b0 + (int)a1 * (int)b1);
                                int32_t* dst = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row + jj;
                                dst[0] += addv;
                            }
                        }
                    } // p pairs

                    // if kc_eff is odd, handle last p
                    if ((kc_eff & 1) != 0) {
                        int k_last = kb + kc_eff - 1;
                        // process last k scalar / vector (fallback to int32 mul)
                        for (int jcol = 0; jcol < nb_eff; ++jcol) {
                            int col_j = cb + jcol;
                            int8_t bval = *(denseB_p2 + (size_t)k_last * (size_t)colsC + (size_t)col_j);
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                int a_row = rb + local_i;
                                int8_t aval = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_last);
                                int32_t addv = (int32_t)((int)aval * (int)bval);
                                int32_t* dst = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row + jcol;
                                dst[0] += addv;
                            }
                        }
                    }

                } // kb

                // write back acc_tile -> denseC (int32 -> float)
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    int32_t* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    int j = 0;
                    for (; j + 16 - 1 < nb_eff; j += 16) {
                        __m512i vi = _mm512_loadu_si512((const void*)(src_row + j));
                        __m512 vf = _mm512_cvtepi32_ps(vi);
                        _mm512_storeu_ps(Crow + j, vf);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = (float) src_row[j];
                }

            } // cb
        } // rb
    } // parallel

    // free per-thread acc tiles
    #pragma omp parallel for num_threads(num_threads) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }

    return true;
}




// Main function: batch-parallel Gustavson-like fused A1@B1 + A2@B2
bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_ternary(
    float* denseA1,   // [batch][rowsA][colsA]
    int8_t* denseB1,  // [batch][colsA][colsC]
    int8_t* denseA2,  // [batch][rowsA][colsA]
    float* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;
    
    // Precompute tiling parameters (global)
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 16;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }

    // if (rowsA == 197 && colsA == 64 && colsC == 197){
    //     Kc = 64, Nb = std::min(colsC, 64); Rb = 4;
    // }
    // else if(rowsA == 197 && colsA == 197 && colsC == 64){
    //     Kc = 64, Nb = std::min(colsC, 64); Rb = 4;
    // }

    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::min(colsC, std::max(16, Nb));
    // Rb = std::max(1, std::min(Rb, rowsA));

    // auto t_start = std::chrono::steady_clock::now();
    // -------- Allocate per-batch containers (vectors) ----------
    // B1 CSR: rows = colsA, cols = colsC  (one CSR per batch)
    // std::vector<std::vector<int>> rowCounts1_batch(batch, std::vector<int>(colsA));
    int16_t* rowCounts1_batch = (int16_t*)malloc(sizeof(int16_t) * batch * colsA);
    MKL_INT* row_ptr1_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (colsA + 1));
    // std::vector<std::vector<MKL_INT>> row_ptr1_batch(batch);
    std::vector<std::vector<int16_t>> col_idx1_batch(batch);
    std::vector<std::vector<int8_t>>   val1_batch(batch);

    // A2 CSR: rows = rowsA, cols = colsA (one CSR per batch)
    // std::vector<std::vector<int>> rowCounts2_batch(batch, std::vector<int>(rowsA));
    int16_t* rowCounts2_batch = (int16_t*)malloc(sizeof(int16_t) * batch * rowsA);
    MKL_INT* row_ptr2_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (rowsA + 1));
    // std::vector<std::vector<MKL_INT>> row_ptr2_batch(batch);
    std::vector<std::vector<int16_t>> col_idx2_batch(batch);
    std::vector<std::vector<int8_t>>   val2_batch(batch);
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (define variables): %.6f s\n",
    //    diff.count());

    // --- Step 1: compute rowCounts for B1 and A2 in parallel (collapse over batch & row) ---
    // B1 rowCounts: iterate over (b, i) where i in [0, colsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < colsA; ++i) {
            int cnt = 0;
            int8_t* Bi = denseB1 + (size_t)b * (size_t)colsA * (size_t)colsC + (size_t)i * (size_t)colsC;
            for (int j = 0; j < colsC; ++j) if (Bi[j] != 0.0f) ++cnt;
            rowCounts1_batch[b*colsA+i] = cnt;
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (compute rowCounts for B1): %.6f s\n",
    //    diff.count());


    // A2 rowCounts: iterate over (b, i) where i in [0, rowsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            int cnt = 0;
            int8_t* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) if (Ai[j] != 0.0f) ++cnt;
            rowCounts2_batch[b*rowsA + i] = cnt;
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (compute rowCounts for A2): %.6f s\n",
    //    diff.count());

    // --- Step 2: build row_ptr arrays and allocate col_idx/val per batch (parallel over b) ---
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        // B1
        // row_ptr1_batch[b].resize(colsA + 1);
        row_ptr1_batch[b*(colsA + 1)] = 0;
        for (int i = 0; i < colsA; ++i) row_ptr1_batch[b*(colsA + 1) + i+1] = row_ptr1_batch[b*(colsA + 1) + i] + rowCounts1_batch[b*colsA+i];
        MKL_INT nnz1 = row_ptr1_batch[b*(colsA + 1) + colsA];
        col_idx1_batch[b].assign((size_t)nnz1, 0);
        val1_batch[b].assign((size_t)nnz1, 0.0f);

        // A2
        // row_ptr2_batch[b].resize(rowsA + 1);
        row_ptr2_batch[b * (rowsA + 1)] = 0;
        for (int i = 0; i < rowsA; ++i) row_ptr2_batch[b * (rowsA + 1) + i+1] = row_ptr2_batch[b * (rowsA + 1) + i] + rowCounts2_batch[b*rowsA + i];
        MKL_INT nnz2 = row_ptr2_batch[b * (rowsA + 1) + rowsA];
        col_idx2_batch[b].assign((size_t)nnz2, 0);
        val2_batch[b].assign((size_t)nnz2, 0.0f);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (count nnz): %.6f s\n",
    //    diff.count());

    // --- Step 3: fill col_idx/val for B1 and A2 in parallel (collapse to distribute work) ---
    // fill B1 CSR: iterate (b, i in colsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < colsA; ++i) {
            MKL_INT base = row_ptr1_batch[b*(colsA + 1) + i];
            int off = 0;
            int8_t* Bi = denseB1 + (size_t)b * (size_t)colsA * (size_t)colsC + (size_t)i * (size_t)colsC;
            for (int j = 0; j < colsC; ++j) {
                int8_t x = Bi[j];
                if (x != 0.0f) {
                    MKL_INT idx = base + off++;
                    col_idx1_batch[b][idx] = (MKL_INT)j;
                    val1_batch[b][idx] = x;
                }
            }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (fill col_idx/val for B1): %.6f s\n",
    //    diff.count());

    // fill A2 CSR: iterate (b, i in rowsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            MKL_INT base = row_ptr2_batch[b * (rowsA + 1) + i];
            int off = 0;
            int8_t* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) {
                float x = Ai[j];
                if (x != 0.0f) {
                    MKL_INT idx = base + off++;
                    col_idx2_batch[b][idx] = (MKL_INT)j;
                    val2_batch[b][idx] = x;
                }
            }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (fill col_idx/val for A2): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
    // --- zero out denseC (per-batch, per-row) ---
    #pragma omp parallel num_threads(64)
    {
        int nt = omp_get_num_threads();
        // 可选：根据情况只用 min(nt, batch)
        #pragma omp for schedule(static)
        for (int b = 0; b < batch; ++b) {
            float* Cb = denseC + (size_t)b * (size_t)rowsA * (size_t)colsC;
            for (int i = 0; i < rowsA; ++i) {
                float* Crow = Cb + (size_t)i * (size_t)colsC;
                memset(Crow, 0, (size_t)colsC * sizeof(float));
            }
        }
    }

    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (zero denseC): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
    // --- Preallocate per-thread temporary buffers to avoid repeated malloc/free ---
    int num_threads = 64;
    // std::vector<void*> thread_packedA(num_threads, nullptr);
    // std::vector<void*> thread_packedB(num_threads, nullptr);
    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    // std::vector<size_t> thread_packedA_size(num_threads, 0);
    // std::vector<size_t> thread_packedB_size(num_threads, 0);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    size_t max_packA_elems = (size_t)Kc * (size_t)Rb; // packedA capacity per thread (rows x Kc)
    size_t max_packB_elems = (size_t)Kc * (size_t)Nb; // packedB capacity per thread (Kc x Nb)
    int max_acc_elems_per_row = ((Nb + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;
    
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        // size_t bytesA = max_packA_elems * sizeof(float);
        // void* pA = portable_aligned_alloc(ACC_ALIGN, bytesA);
        // if (!pA) pA = malloc(bytesA);
        // thread_packedA[t] = pA; thread_packedA_size[t] = bytesA;

        // size_t bytesB = max_packB_elems * sizeof(float);
        // void* pB = portable_aligned_alloc(ACC_ALIGN, bytesB);
        // if (!pB) pB = malloc(bytesB);
        // thread_packedB[t] = pB; thread_packedB_size[t] = bytesB;

        size_t bytesAcc = max_acc_tile_elems * sizeof(float);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc; thread_acc_tile_size[t] = bytesAcc;
    }

    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (C packing): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
       // -------- Main compute: parallelize over (b, rb) to cover batch and row-blocks ----------
    #pragma omp parallel for collapse(2) num_threads(64) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                // pointer bases for this batch
                float* denseA_p1 = denseA1 + (size_t)b * (size_t)rowsA * (size_t)colsA;
                float* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                const MKL_INT* row_ptr_p1 = row_ptr1_batch + b*(colsA + 1);
                const int16_t* col_idx_p1 = col_idx1_batch[b].data();
                const int8_t*   val_p1     = val1_batch[b].data();

                const MKL_INT* row_ptr_p2 = row_ptr2_batch + b * (rowsA + 1);
                const int16_t* col_idx_p2 = col_idx2_batch[b].data();
                const int8_t*   val_p2     = val2_batch[b].data();

                int rb_eff = std::min(Rb, rowsA - rb);

                // local per-thread buffers (preallocated)
                // float* packedA = (float*)thread_packedA[tid];
                // float* packedB = (float*)thread_packedB[tid];
                float* acc_tile = (float*)thread_acc_tile[tid];


                int nb_eff = std::min(Nb, colsC - cb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;

                // init acc_tile from C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // loop over k-blocks
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0 || nb_eff == 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    // pack B2 block: kc_eff x nb_eff into packedB
                    // for (int kk = 0; kk < kc_eff; ++kk) {
                    //     const float* Brow = denseB_p2 + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    //     float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    //     if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // }

                    // pack A1 rows for this tile: rb_eff x kc_eff (stride = kc_eff)
                    // for (int mm = 0; mm < rb_eff; ++mm) {
                    //     const float* Arow = denseA_p1 + (size_t)(rb + mm) * (size_t)colsA + (size_t)kb;
                    //     float* dest = packedA + (size_t)mm * (size_t)kc_eff;
                    //     if (kc_eff > 0) memcpy(dest, Arow, sizeof(float) * (size_t)kc_eff);
                    // }

                    // --- Row-major calculation using A2 CSR and packedB ---
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr_p2[i], end = row_ptr_p2[i + 1];
                        if (start >= end) continue;
                        const int16_t* base = col_idx_p2;
                        const int16_t* s = base + start;
                        const int16_t* e = base + end;

                        const int16_t* p0ptr = std::lower_bound(s, e, (MKL_INT)kb);
                        const int16_t* p1ptr = std::lower_bound(p0ptr, e, (MKL_INT)(kb + kc_eff));
                        if (p0ptr == p1ptr) continue;
                        MKL_INT it0 = (MKL_INT)(p0ptr - base);
                        MKL_INT it1 = (MKL_INT)(p1ptr - base);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p2[p];
                            float v = val_p2[p];
                            int k_rel = (int)(k_col - kb);
                            if (k_rel < 0 || k_rel >= kc_eff) continue;
                            // const float* Brow = packedB + (size_t)k_rel * (size_t)nb_eff;
                            const float* Brow_global = denseB_p2 + (size_t)k_col * (size_t)colsC + (size_t)cb;
                            __m256 vv = _mm256_set1_ps(v);
                            int j = 0;
                            for (; j < vec_end; j += VEC_WIDTH) {
                                __m256 accv = _mm256_loadu_ps(acc_row + j);
                                __m256 bvec = _mm256_loadu_ps(Brow_global + j);
                                accv = _mm256_fmadd_ps(vv, bvec, accv);
                                _mm256_storeu_ps(acc_row + j, accv);
                            }
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow_global[jj];
                            }
                        }
                    }

                    // --- Col-major calculation using B1 CSR and packedA ---
                    for (int local_k = 0; local_k < kc_eff; ++local_k) {
                        int global_k = kb + local_k;
                        MKL_INT p_start = row_ptr_p1[global_k];
                        MKL_INT p_end   = row_ptr_p1[global_k + 1];
                        MKL_INT row_nnz = p_end - p_start;
                        if (row_nnz <= 0) continue;

                        const int16_t* base = col_idx_p1 + p_start;
                        const int16_t* p0 = std::lower_bound(base, base + row_nnz, (MKL_INT)cb);
                        const int16_t* p1 = std::lower_bound(p0, base + row_nnz, (MKL_INT)(cb + nb_eff));
                        if (p0 == p1) continue;
                        MKL_INT it0 = (MKL_INT)(p0 - col_idx_p1);
                        MKL_INT it1 = (MKL_INT)(p1 - col_idx_p1);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT jidx = col_idx_p1[p];
                            int dst = (int)(jidx - cb);
                            float vb = val_p1[p];
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                // float A_value = packedA[(size_t)local_i * (size_t)kc_eff + (size_t)local_k];
                                const float* Arow_global = denseA_p1 + (size_t)(rb + local_i) * (size_t)colsA;
                                float A_value = Arow_global[(size_t)kb + (size_t)local_k]; // element A[rb+local_i, kb+local_k]
                                float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                                acc_row[dst] += A_value * vb;
                            }
                        }
                    }
                } // kb

                // write back acc_tile into C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_loadu_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
            } // cb
        } // rb
    } // parallel over (b, rb)
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (computing): %.6f s\n",
    //    diff.count());
    
    // t_start = std::chrono::steady_clock::now();
    // free per-thread buffers
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        // if (thread_packedA[t]) portable_aligned_free(thread_packedA[t]);
        // if (thread_packedB[t]) portable_aligned_free(thread_packedB[t]);
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (free C): %.6f s\n",
    //    diff.count());

    return true;
}




bool Sparse_CSRXDense_Fast_Gustavson_Attention_row_major(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        float* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            c += (Ai[j] != 0.0f);
        }
        rowCounts[i] = c;
    }

    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    float density = (float)nnz/(float)(rowsA*colsA);
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) {
                int addr = base + off; 
                col_idx[addr] = (MKL_INT)j; 
                val[addr] = x; 
                ++off; 
            }
        }
    }

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 32, Nb = std::min(colsC, 32);
    int Rb = 32;

    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    // 修正：保证 Nb 不会超过 colsC，同时尽量偏好 16 这一粒度
    Nb = std::min(colsC, std::max(16, Nb));
    Rb = std::max(1, std::min(Rb, rowsA));

    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const float* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;


            int nb_eff = std::min(Nb, colsC - cb);
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }


            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile_buf_tmp) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp); }
        }
    }
    return true;
}


bool Sparse_CSRXDense_Fast_Gustavson_Attention_column_major(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // Build CSR for B (K = colsA rows, N = colsC cols)
    // auto t_start = std::chrono::steady_clock::now();
    std::vector<int> rowCounts(colsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < colsA; ++i) {
        int c = 0;
        float* Bi = denseB + (size_t)i * colsC;
        for (int j = 0; j < colsC; ++j) c += (Bi[j] != 0.0f);
        rowCounts[i] = c;
    }

    std::vector<MKL_INT> row_ptr(colsA + 1, 0);
    for (int i = 0; i < colsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[colsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float> val((size_t)nnz);

    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < colsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Bi = denseB + (size_t)i * colsC;
        for (int j = 0; j < colsC; ++j) {
            float x = Bi[j];
            if (x != 0.0f) {
                int addr = base + off;
                col_idx[addr] = (MKL_INT)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (build CSR): %.6f s\n",
    //    diff.count());

       // zero C
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 32, Nb = std::min(colsC, 32);
    int Rb = 32;

    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::min(colsC, std::max(16, Nb));
    Rb = std::max(1, std::min(Rb, rowsA));

    const float* denseA_p = denseA;
    float* denseC_p = denseC;
    const MKL_INT* row_ptr_p = row_ptr.data();
    const MKL_INT* col_idx_p = col_idx.data();
    const float* val_p = val.data();

    // Note: avoid forcing num_threads here; let OpenMP choose or set externally
    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            int rb_eff = std::min(Rb, rowsA - rb);
            if (rb_eff <= 0) continue;
            int nb_eff = std::min(Nb, colsC - cb);
            if (nb_eff <= 0) continue;

            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;

            // allocate acc_tile based on actual rb_eff (fix bug)
            size_t acc_tile_max_elems = (size_t)rb_eff * (size_t)acc_elems_per_row;
            if (acc_tile_max_elems == 0) continue;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
                if (!acc_tile_buf_tmp) continue;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            // allocate packedA with Kc * rb_eff (max) once per tile
            size_t pack_elems_max = (size_t)Kc * (size_t)rb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems_max * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems_max * sizeof(float));
                packed_portable = false;
                if (!packed_tmp) {
                    if (acc_tile_buf_tmp) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp); }
                    continue;
                }
            }
            float* packedA = (float*)packed_tmp;

            // init acc_tile from C
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile_buf + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            // loop over k-blocks
            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                if (kc_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)rb_eff) continue;

                // pack A rows for this tile: rb_eff x kc_eff
                for (int mm = 0; mm < rb_eff; ++mm) {
                    const float* Arow = denseA_p + (size_t)(rb + mm) * (size_t)colsA + (size_t)kb;
                    float* dest = packedA + (size_t)mm * (size_t)kc_eff;
                    if (kc_eff > 0) memcpy(dest, Arow, sizeof(float) * (size_t)kc_eff);
                }

                // For each k in the block, iterate B.row[k] nonzeros and update acc_tile
                for (int local_k = 0; local_k < kc_eff; ++local_k) {
                    int global_k = kb + local_k;
                    MKL_INT p_start = row_ptr_p[global_k];
                    MKL_INT p_end = row_ptr_p[global_k + 1];
                    MKL_INT row_nnz = p_end - p_start;
                    if (row_nnz <= 0) continue;

                    // base 指向该行在 col_idx 数组的起点（已排好序）
                    const MKL_INT* base = col_idx_p + p_start;

                    // 在该行的 col_idx 子数组上做二分：找到第一个 >= cb 和第一个 >= cb+nb_eff
                    const MKL_INT* p0 = std::lower_bound(base, base + row_nnz, (MKL_INT)cb);
                    const MKL_INT* p1 = std::lower_bound(base, base + row_nnz, (MKL_INT)(cb + nb_eff));

                    if (p0 == p1) continue; // 这一行在本列块没有非零

                    // 转回全局索引位置（注意：p0-base + p_start == p0 - col_idx_p）
                    MKL_INT it0 = (MKL_INT)(p0 - col_idx_p);
                    MKL_INT it1 = (MKL_INT)(p1 - col_idx_p);

                    // 遍历局部区间，避免每个元素再做范围判断                   
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        float A_value = packedA[(size_t)local_i * (size_t)kc_eff + (size_t)local_k];
                        float* acc_row = acc_tile_buf + (size_t)local_i * (size_t)acc_elems_per_row;
                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT j = col_idx_p[p];
                            int dst = (int)(j - cb);        // 0..nb_eff-1
                            float vb = val_p[p];
                            acc_row[dst] += A_value * vb;
                        }
                    }
                }
            } // kb

            // write back
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile_buf + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_loadu_ps(src_row + j);  // use loadu
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }

            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile_buf_tmp) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp); }
        }
    }
    return true;
}


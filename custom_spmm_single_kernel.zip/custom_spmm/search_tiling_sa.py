#!/usr/bin/env python3
"""
sa_search.py

Simulated Annealing search for tiling parameters (tM, tK, tN).
Based on your code structure: uses call_binary(...) to run the C benchmark.

Save as sa_search.py and run:
  python sa_search.py --binary ./matmul_bench --M 2048 --K 2048 --N 2048 --sparsity 0.9
"""
import argparse
import itertools
import math
import os
import random
import subprocess
import sys
import time
from typing import List, Tuple, Optional, Dict, Any

import numpy as np

# ---------------------
# utils (from your code)
# ---------------------
def divisors(n: int, min_val: int = 1, max_val: Optional[int] = None) -> List[int]:
    if n <= 0:
        return [1]
    if max_val is None:
        max_val = n
    divs = set()
    r = int(math.sqrt(n))
    for i in range(1, r + 1):
        if n % i == 0:
            if min_val <= i <= max_val:
                divs.add(i)
            j = n // i
            if min_val <= j <= max_val:
                divs.add(j)
    return sorted(divs)

def call_binary(binary_path: str,
                M: int, K: int, N: int, sparsity: float,
                tM: int, tK: int, tN: int,
                timeout: float = 60.0) -> float:
    cmd = [
        binary_path,
        str(sparsity), str(M), str(K), str(N),
        str(tM), str(tK), str(tN)
    ]
    try:
        res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    except subprocess.TimeoutExpired as e:
        print(f"[ERROR] timeout for cmd: {' '.join(cmd)}", file=sys.stderr)
        return float('inf')
    if res.returncode != 0:
        print(f"[ERROR] non-zero exit ({res.returncode}) for cmd: {' '.join(cmd)}; stderr: {res.stderr.strip()}", file=sys.stderr)
        return float('inf')
    out = (res.stdout or "").strip()
    print(res)
    token = None
    for tok in out.replace(",", " ").split():
        try:
            token = float(tok)
            break
        except ValueError:
            continue
    if token is None:
        print(f"[ERROR] could not parse latency from stdout: {out!r}", file=sys.stderr)
        return float('inf')
    return float(token)

# ---------------------
# Evaluator with cache
# ---------------------
class Evaluator:
    def __init__(self, binary_path: str, M:int=0, K:int=0, N:int=0, sparsity:float=0.0, timeout_per_eval:float=60.0):
        self.binary_path = binary_path
        self.M = M; self.K = K; self.N = N; self.sparsity = sparsity
        self.timeout_per_eval = timeout_per_eval
        self.cache: Dict[Tuple[int,int,int], float] = {}

    def eval_point(self, t: Tuple[int,int,int]) -> float:
        key = (int(t[0]), int(t[1]), int(t[2]))
        if key in self.cache:
            return self.cache[key]
        val = call_binary(self.binary_path, self.M, self.K, self.N, self.sparsity, key[0], key[1], key[2], timeout=self.timeout_per_eval)
        self.cache[key] = val
        return val

# ---------------------
# neighbor generation
# ---------------------
def neighbor_divisible(current: Tuple[int,int,int],
                       cand_M: List[int], cand_K: List[int], cand_N: List[int],
                       max_jump: int = 1,
                       rng: Optional[random.Random] = None) -> Tuple[int,int,int]:
    """Pick neighbor by moving within divisor lists by +/- up to max_jump indices for each dim."""
    if rng is None: rng = random
    tM, tK, tN = current
    # indices
    iM = cand_M.index(tM)
    iK = cand_K.index(tK)
    iN = cand_N.index(tN)
    def mutate_idx(i, L):
        step = rng.randint(-max_jump, max_jump)
        j = max(0, min(len(L)-1, i + step))
        return L[j]
    return (mutate_idx(iM, cand_M), mutate_idx(iK, cand_K), mutate_idx(iN, cand_N))

def neighbor_nondiscrete(current: Tuple[int,int,int],
                          M:int,K:int,N:int,
                          max_rel_step: float = 0.25,
                          rng: Optional[random.Random] = None) -> Tuple[int,int,int]:
    """For non-divisible space: mutate values but ensure returned values are multiples of 8.
    If vmax < 8, fall back to normal integer behavior to avoid impossible constraint.
    """
    if rng is None:
        rng = random.Random()
    tM, tK, tN = current

    def to_mult8(val: int, vmax: int) -> int:
        """Round val to nearest multiple of 8 while staying in [8, vmax] (if vmax>=8).
        If vmax < 8, just clip to [1, vmax].
        """
        if vmax < 8:
            # can't satisfy multiple-of-8 constraint; fallback to clipping
            return max(1, min(vmax, int(val)))
        # round to nearest multiple of 8
        m = int(round(val / 8.0)) * 8
        # ensure at least 8
        if m < 8:
            m = 8
        # clamp to max multiple-of-8 <= vmax
        max_mult = (vmax // 8) * 8
        if max_mult < 8:
            # if vmax between 8 and 15 etc handled above; this is safety
            max_mult = max(8, min(vmax, 8))
        if m > max_mult:
            m = max_mult
        return int(m)

    def mutate_val(v: int, vmax: int) -> int:
        choice = rng.choice(["mul2", "div2", "add", "rand"])
        if choice == "mul2":
            nv = v * 2
        elif choice == "div2":
            nv = max(1, v // 2)
        elif choice == "add":
            # add/sub a small integer proportional to vmax
            delta = max(1, int(max_rel_step * vmax))
            nv = v + rng.randint(-delta, delta)
            nv = max(1, min(vmax, nv))
        else:  # "rand"
            low = max(1, int(max(1, v * (1 - max_rel_step))))
            high = min(vmax, int(max(1, v * (1 + max_rel_step))))
            if high < low:
                low, high = 1, vmax
            nv = rng.randint(low, high)
        # now round/clamp to multiple-of-8 if possible
        return to_mult8(nv, vmax)

    newM = mutate_val(tM, M)
    newK = mutate_val(tK, K)
    newN = mutate_val(tN, N)
    return (newM, newK, newN)

# ---------------------
# Simulated Annealing search
# ---------------------
def sa_search(
    binary_path: str,
    M: int, K: int, N: int, sparsity: float,
    max_evals: int = 200,
    random_seed: int = 0,
    require_divisible: bool = True,
    min_tile: int = 1,
    max_tile_M: Optional[int] = None,
    max_tile_K: Optional[int] = None,
    max_tile_N: Optional[int] = None,
    init_solution: Optional[Tuple[int,int,int]] = None,
    restarts: int = 3,
    init_temp: float = 1.0,
    alpha: float = 0.95,
    max_iters_per_restart: int = 100,
    max_jump: int = 1,
    timeout_per_eval: float = 60.0,
) -> Dict[str, Any]:
    rng = random.Random(random_seed)
    np_rng = np.random.default_rng(random_seed)

    if max_tile_M is None: max_tile_M = M
    if max_tile_K is None: max_tile_K = K
    if max_tile_N is None: max_tile_N = N

    # generate candidate divisor lists if needed
    if require_divisible:
        cand_M = divisors(M, min_tile, max_tile_M)
        cand_K = divisors(K, min_tile, max_tile_K)
        cand_N = divisors(N, min_tile, max_tile_N)
        if not cand_M or not cand_K or not cand_N:
            raise ValueError("Empty divisor lists for divisible mode.")
    else:
        cand_M = list(range(min_tile, min(max_tile_M, M) + 1, 8))
        cand_K = list(range(min_tile, min(max_tile_K, K) + 1, 8))
        cand_N = list(range(min_tile, min(max_tile_N, N) + 1, 8))

    evaluator = Evaluator(binary_path, M, K, N, sparsity, timeout_per_eval=timeout_per_eval)

    best_overall = None
    best_overall_val = float('inf')
    history = []  # record (t, val, eval_count)

    evals_done = 0
    # total budget will be max_evals across restarts (not per restart)
    per_restart_budget = max(1, max_evals // max(1, restarts))

    for r in range(restarts):
        # choose start
        if r == 0 and init_solution is not None:
            cur = tuple(init_solution)
        else:
            cur = (rng.choice(cand_M), rng.choice(cand_K), rng.choice(cand_N))
        cur_val = evaluator.eval_point(cur)
        evals_done += 1
        if cur_val < best_overall_val:
            best_overall = cur; best_overall_val = cur_val
        T = init_temp
        it = 0
        # iterate until per-restart budget or max_iters_per_restart
        while it < max_iters_per_restart and evals_done < max_evals:
            # generate neighbor
            if require_divisible:
                nxt = neighbor_divisible(cur, cand_M, cand_K, cand_N, max_jump=max_jump, rng=rng)
            else:
                nxt = neighbor_nondiscrete(cur, M, K, N, rng=rng)
            nxt_val = evaluator.eval_point(nxt)
            evals_done += 1
            # acceptance (minimization)
            delta = nxt_val - cur_val
            accept = False
            if delta <= 0:
                accept = True
            else:
                # probabilistic acceptance
                prob = math.exp(-delta / max(1e-12, T))
                if rng.random() < prob:
                    accept = True
            if accept:
                cur = nxt
                cur_val = nxt_val
                # update global best
                if cur_val < best_overall_val:
                    best_overall = cur
                    best_overall_val = cur_val
                    print(f"[SA] restart {r} iter {it}: new best {best_overall} -> {best_overall_val} (evals={evals_done})")
            # cool down
            T *= alpha
            it += 1
            # record history occasionally
            if evals_done % 5 == 0:
                history.append({"tiling": cur, "latency": cur_val, "evals": evals_done})
            # stop early if temperature is extremely small
            if T < 1e-12:
                break
            # stop if reached global budget
            if evals_done >= max_evals:
                break
        # end restart
    # end restarts

    # include best in cache/history
    history.insert(0, {"tiling": best_overall, "latency": best_overall_val, "evals": evals_done})
    return {"best_tiling": {"tiling_M": int(best_overall[0]), "tiling_K": int(best_overall[1]), "tiling_N": int(best_overall[2])},
            "best_latency": float(best_overall_val),
            "evaluations": evals_done,
            "history": history,
            "eval_cache": evaluator.cache}

# ---------------------
# CLI
# ---------------------
def main():
    parser = argparse.ArgumentParser(description="Simulated Annealing search for tiling parameters.")
    parser.add_argument("--binary", type=str, default="./matmul_bench", help="Path to C executable.")
    parser.add_argument("--M", type=int, required=True)
    parser.add_argument("--K", type=int, required=True)
    parser.add_argument("--N", type=int, required=True)
    parser.add_argument("--sparsity", type=float, required=True)
    parser.add_argument("--max_evals", type=int, default=200)
    parser.add_argument("--random_seed", type=int, default=0)
    parser.add_argument("--no_require_divisible", action="store_true", help="If set, tiling does not need to divide dimensions.")
    parser.add_argument("--min_tile", type=int, default=1)
    parser.add_argument("--max_tile_M", type=int, default=None)
    parser.add_argument("--max_tile_K", type=int, default=None)
    parser.add_argument("--max_tile_N", type=int, default=None)
    parser.add_argument("--init", type=int, nargs=3, default=None, help="Optional initial tiling tM tK tN")
    parser.add_argument("--restarts", type=int, default=3)
    parser.add_argument("--init_temp", type=float, default=1.0)
    parser.add_argument("--alpha", type=float, default=0.95, help="Multiplicative cooling factor per iteration")
    parser.add_argument("--max_iters_per_restart", type=int, default=100)
    parser.add_argument("--max_jump", type=int, default=1, help="Max index jump in divisor list when require_divisible")
    parser.add_argument("--timeout_per_eval", type=float, default=60.0)

    args = parser.parse_args()

    require_divisible = not args.no_require_divisible

    result = sa_search(
        binary_path=args.binary,
        M=args.M, K=args.K, N=args.N, sparsity=args.sparsity,
        max_evals=args.max_evals,
        random_seed=args.random_seed,
        require_divisible=require_divisible,
        min_tile=args.min_tile,
        max_tile_M=args.max_tile_M,
        max_tile_K=args.max_tile_K,
        max_tile_N=args.max_tile_N,
        init_solution=tuple(args.init) if args.init else None,
        restarts=args.restarts,
        init_temp=args.init_temp,
        alpha=args.alpha,
        max_iters_per_restart=args.max_iters_per_restart,
        max_jump=args.max_jump,
        timeout_per_eval=args.timeout_per_eval,
    )

    best = result["best_tiling"]
    print("=== SA Result ===")
    print(f"Best tiling: (M={best['tiling_M']}, K={best['tiling_K']}, N={best['tiling_N']})")
    print(f"Best latency: {result['best_latency']:.6f} (evaluations={result['evaluations']})")
    # optional: print small history
    print("Top history entries:")
    for h in result["history"][:8]:
        print(h)

if __name__ == "__main__":
    main()

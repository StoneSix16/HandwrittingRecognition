g++ -O3 -g -std=c++17 -mfma -mavx2 -mavx512f -mavx512dq -mavx512bw -mavx512vl -pthread -funroll-loops -ffast-math \
    custom_attention.cpp \
    -I${MKLROOT}/include \
    -L${MKLROOT}/lib/intel64 \
    -Wl,--no-as-needed \
    -lmkl_intel_lp64 -lmkl_core -lmkl_intel_thread \
    -liomp5 -lm -ldl -fopenmp \
    -o custom_attention

#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <mkl.h>
#include <mkl_spblas.h>

void ST_BIF_forward_scale_int(float* x_t, float* V_t_1, float* T_t_1, int8_t* output, int N, float v_th, int T_max, int T_min);
void ST_BIF_forward_scale_int_AVX2(float* x_t, float* V_t_1, float* T_t_1, int8_t* output, int N, float v_th, int T_max, int T_min);

float* rand01_matrix_alloc(size_t rows, size_t cols, int seed);

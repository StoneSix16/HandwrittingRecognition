#include <iostream>
#include <vector>
#include <mkl.h>

void build_csr_with_mkl(float* denseA,
                        int rowsA,
                        int colsA,
                        std::vector<MKL_INT>& row_ptr,
                        std::vector<MKL_INT>& col_idx,
                        std::vector<float>& val) {
    int job[6] = {0, 1, 0, 2, rowsA, 0};  // row-major
    int info = 0;

    MKL_INT m = rowsA;
    MKL_INT n = colsA;
    MKL_INT lda = colsA;  // row-major 时 lda=列数

    // 第一次调用：只填 row_ptr
    row_ptr.resize(rowsA + 1);
    mkl_sdnscsr(job, &m, &n,
                denseA, &lda,
                nullptr, nullptr, row_ptr.data(), &info);
    if (info != 0) {
        std::cerr << "mkl_sdnscsr phase1 failed, info=" << info << "\n";
        return;
    }

    MKL_INT nnz = row_ptr[m];
    col_idx.resize(nnz);
    val.resize(nnz);

    // 第二次调用：填充 col_idx 和 val
    mkl_sdnscsr(job, &m, &n,
                denseA, &lda,
                val.data(), col_idx.data(), row_ptr.data(), &info);
    if (info != 0) {
        std::cerr << "mkl_sdnscsr phase2 failed, info=" << info << "\n";
        return;
    }
}

int main() {
    const int rowsA = 3, colsA = 4;
    float denseA[rowsA * colsA] = {
        1, 0, 2, 0,
        0, 3, 0, 4,
        0, 0, 0, 5
    };

    std::vector<MKL_INT> row_ptr, col_idx;
    std::vector<float> val;

    build_csr_with_mkl(denseA, rowsA, colsA, row_ptr, col_idx, val);

    std::cout << "row_ptr: ";
    for (auto x : row_ptr) std::cout << x << " ";
    std::cout << "\n";

    std::cout << "col_idx: ";
    for (auto x : col_idx) std::cout << x << " ";
    std::cout << "\n";

    std::cout << "val: ";
    for (auto x : val) std::cout << x << " ";
    std::cout << "\n";
}

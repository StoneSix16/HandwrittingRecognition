// optimized: acc_tile init moved outside kb loop, memcpy copy, reuse acc_tile per (cb,rb)
#include "MKL_Sparse_Methods.h"
#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>

// portable aligned alloc/free
static inline void* portable_aligned_alloc(size_t alignment, size_t size) {
    if (size == 0) return nullptr;
    size_t extra = alignment - 1 + sizeof(void*);
    void* raw = malloc(size + extra);
    if (!raw) return nullptr;
    uintptr_t raw_addr = (uintptr_t)raw + sizeof(void*);
    uintptr_t aligned = (raw_addr + (alignment - 1)) & ~(alignment - 1);
    void** store = (void**)(aligned - sizeof(void*));
    *store = raw;
    return (void*)aligned;
}
static inline void portable_aligned_free(void* p) {
    if (!p) return;
    void** store = (void**)((uintptr_t)p - sizeof(void*));
    void* raw = *store;
    free(raw);
}

#if defined(_MSC_VER)
static inline void prefetch_read(const void* p) { _mm_prefetch((const char*)p, _MM_HINT_T0); }
#else
static inline void prefetch_read(const void* p) { __builtin_prefetch(p, 0, 1); }
#endif

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        float* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const float* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }


            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    // MKL_INT it0 = cursor[local_i];
                    // MKL_INT end = row_ptr_p[i + 1];
                    // while (it0 < end && col_idx_p[it0] < kb) ++it0;
                    // cursor[local_i] = it0;
                    // MKL_INT it1 = it0;
                    // while (it1 < end && col_idx_p[it1] < kblock_end) ++it1;
                    // if (it0 >= it1) continue;
                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile_buf_tmp) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp); }
        }
    }

    return true;
}


inline __m256 apply_sign_scalar(__m256 v, int8_t x) {
    static const __m256 sign_mask = _mm256_set1_ps(-0.0f);
    if (x == 1) {
        return v;
    } else {
        return _mm256_xor_ps(v, sign_mask);
    }
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // printf("byte=%ld\n",sizeof(float) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_load_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}


bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_packB(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            int Kblocks = (colsA + Kc - 1) / Kc;
            int Nblocks = (colsC + Nb - 1) / Nb;

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                float* packedB = (float*)packed_tmp;
                
                int kb_block = kb / Kc;
                int cb_block = cb / Nb;
                size_t block_id = (size_t)kb_block * (size_t)Nblocks + (size_t)cb_block;
                // pointer to the start of this Kc x Nc packed block
                const float* packed_block = denseB_p + block_id * (size_t)Kc * (size_t)Nb;

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        float v = val_p[p];
                        size_t row_offset = (size_t)(k_col - kb) * (size_t)Nb;
                        const float* Brow = packed_block + row_offset;
                        __m256 vv = _mm256_set1_ps(v);
                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec = _mm256_loadu_ps(Brow + j);
                            accv = _mm256_fmadd_ps(vv, bvec, accv);
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        if (vec_end < nb_eff) {
                            for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                        }
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256 tmpv = _mm256_load_ps(src_row + j);
                    _mm256_storeu_ps(Crow + j, tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}


bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_int(
    int8_t* denseA,
    int8_t* denseB,
    int32_t* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        #pragma omp simd
        for (int j = 0; j < colsA; ++j) {
            int8_t x = Ai[j];
            if (x != 0.0f) { col_idx[base + off] = (MKL_INT)j; val[base + off] = x; ++off; }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        int32_t* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const int8_t* val_p = val.data();
            int8_t* denseB_p = denseB;
            int32_t* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(int32_t));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(int32_t));
                acc_tile_buf_portable = false;
            }
            int32_t* acc_tile_buf = (int32_t*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(int8_t));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(int8_t));
                packed_portable = false;
            }

            int rb_eff = std::min(Rb, rowsA - rb);
            int32_t* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                int32_t* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                int32_t* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(int32_t) * (size_t)nb_eff);
                for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            }

            std::vector<MKL_INT> cursor(rb_eff);
            for (int local_i = 0; local_i < rb_eff; ++local_i) cursor[local_i] = row_ptr_p[rb + local_i];

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                int8_t* packedB = (int8_t*)packed_tmp;
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const int8_t* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    int8_t* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(int8_t) * (size_t)nb_eff);
                }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    int32_t* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    MKL_INT p = it0;
                    // singletons
                    for (; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        int8_t v8 = val_p[p]; // ∈ {-1, +1}
                        const int8_t* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;

                        int j = 0;
                        // sign = +1 或 -1（int）
                        int sign = (int)v8;
                        __m256i sign_vec = _mm256_set1_epi32(sign);

                        for (; j < vec_end; j += VEC_WIDTH) {
                            // load 8 int8 -> widen to 8 int32
                            __m128i b8  = _mm_loadl_epi64((const __m128i*)(Brow + j)); // loads 8 bytes
                            __m256i b32 = _mm256_cvtepi8_epi32(b8);                    // widen to 8 x i32

                            // prod = sign * b32
                            __m256i prod = _mm256_mullo_epi32(sign_vec, b32);

                            // acc_row += prod
                            __m256i accv = _mm256_loadu_si256((const __m256i*)(acc_row + j));
                            accv = _mm256_add_epi32(accv, prod);
                            _mm256_storeu_si256((__m256i*)(acc_row + j), accv);
                        }
                        // tail
                        for (; j < nb_eff; ++j) acc_row[j] += sign * (int32_t)Brow[j];
                    } // singletons
                }
            }
            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                int i = rb + local_i;
                int32_t* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                int32_t* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                int j = 0;
                for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                    __m256i tmpv = _mm256_loadu_si256((const __m256i*)(src_row + j));
                    _mm256_storeu_si256((__m256i*)(Crow + j), tmpv);
                }
                for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (packed_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}

uint8_t csr_value_encode(float A, float B, float C, float D) {
    int A1 = A > 0 ? 1 : 0;
    int B1 = B > 0 ? 1 : 0;
    int C1 = C > 0 ? 1 : 0;
    int D1 = D > 0 ? 1 : 0;

    int A2 = A < 0 ? 1 : 0;
    int B2 = B < 0 ? 1 : 0;
    int C2 = C < 0 ? 1 : 0;
    int D2 = D < 0 ? 1 : 0;

    uint8_t result; // 高4位是pos，低四位是neg
    result = ((A1 << 7) + (B1 << 6) + (C1 << 5) + (D1 << 4)) + ((A2 << 3) + (B2 << 2) + (C2 << 1) + D2);
    return result;
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_LUT(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j){
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<uint8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j) {
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) {
                int pos = base + off;
                col_idx[pos] = j;
                // 考虑不能被4整除的情况
                int t = std::min((j + 1) * LWIDTH, colsA) - j * LWIDTH;
                int jj = j * LWIDTH;
                // printf("Ai[jj]=%d, Ai[jj + 1]=%d, Ai[jj + 2]=%d, Ai[jj + 3]=%d\n",Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                if (t == LWIDTH)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                else if (t == LWIDTH - 1)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], 0);
                else if (t == LWIDTH - 2)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], 0, 0);
                else if (t == LWIDTH - 3)
                    val[pos] = csr_value_encode(Ai[jj], 0, 0, 0);
                ++off;
            }
        }
    }
    colsA = (colsA + LWIDTH - 1) / LWIDTH; // calculation of colsA reduce LWIDTH times
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    // 2) zero C
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int i = 0; i < rowsA; ++i) {
        float* row = denseC + (size_t)i * colsC;
        std::fill_n(row, colsC, 0.0f);
    }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 128, Kc = 128, Nb = 64;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 128, Kc = 512, Nb = 64;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }

    if (Rb > rowsA) Rb = rowsA;
    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));
    // printf("rowsA=%d,colsA=%d,colsC=%d,Kc=%d,Nb=%d,Rb=%d\n",rowsA,colsA,colsC,Kc,Nb, Rb);


    #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
    for (int rb = 0; rb < rowsA; rb += Rb) {
        for (int cb = 0; cb < colsC; cb += Nb) {
            // Pointers to avoid capturing vectors etc.
            const MKL_INT* row_ptr_p = row_ptr.data();
            const MKL_INT* col_idx_p = col_idx.data();
            const uint8_t* val_p = val.data();
            float* denseB_p = denseB;
            float* denseC_p = denseC;

            int nb_eff = Nb;
            int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
            int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
            size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
            size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
            void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
            bool acc_tile_buf_portable = true;
            if (!acc_tile_buf_tmp) {
                acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                acc_tile_buf_portable = false;
            }
            float* acc_tile_buf = (float*)acc_tile_buf_tmp;

            size_t pack_elems = (size_t)LWIDTH_POW2 * (size_t)Kc * (size_t)nb_eff;
            void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
            bool packed_portable = true;
            if (!packed_tmp) {
                packed_tmp = malloc(pack_elems * sizeof(float));
                packed_portable = false;
            }


            int rb_eff = std::min(Rb, rowsA - rb);
            float* acc_tile = acc_tile_buf; // prefix
            // init acc_tile from denseC (per-row memcpy)
            // for (int local_i = 0; local_i < rb_eff; ++local_i) {
            //     int i = rb + local_i;
            //     float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
            //     float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
            //     if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
            //     for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
            // }

            std::vector<MKL_INT> cursor(rb_eff);
            for (int local_i = 0; local_i < rb_eff; ++local_i) cursor[local_i] = row_ptr_p[rb + local_i];

            for (int kb = 0; kb < colsA; kb += Kc) {
                int kc_eff = std::min(Kc, colsA - kb);
                int kblock_end = kb + kc_eff;

                if (kc_eff == 0 || nb_eff == 0) continue;
                if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                // float* packedB = (float*)packed_tmp;
                // for (int lut_idx=0; lut_idx < LWIDTH_POW2; ++lut_idx){
                //     for (int kk = 0; kk < kc_eff; ++kk) {
                //         const float* Brow = denseB_p + (size_t)lut_idx * (size_t)colsA * (size_t)colsC + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                //         float* dest = packedB + (size_t)lut_idx * (size_t)kc_eff * (size_t)nb_eff + (size_t)kk * (size_t)nb_eff;
                //         if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                //     }
                // }

                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    // MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    // if (start >= end) continue;
                    // MKL_INT* base = col_idx.data();
                    // MKL_INT* s = base + start;
                    // MKL_INT* e = base + end;

                    // MKL_INT* p0 = std::lower_bound(s, e, kb);
                    // MKL_INT it0 = (MKL_INT)(p0 - base);

                    // MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                    // MKL_INT it1 = (MKL_INT)(p1 - base);

                    // MKL_INT p = it0;
                    // // singletons
                    // for (; p < it1; ++p) {
                    //     MKL_INT k_col = col_idx_p[p];
                    //     uint8_t v = val_p[p];
                    //     uint8_t pos_idx = (v >> LWIDTH) & 0x0F;
                    //     uint8_t neg_idx = v & 0x0F;
                    //     const float* Brow_pos = packedB + (size_t)pos_idx * (size_t)kc_eff * (size_t)nb_eff + (size_t)(k_col - kb) * (size_t)nb_eff;
                    //     const float* Brow_neg = packedB + (size_t)neg_idx * (size_t)kc_eff * (size_t)nb_eff + (size_t)(k_col - kb) * (size_t)nb_eff;

                    //     // const float* Brow_pos = denseB_p + (size_t)pos_idx * (size_t)colsA * (size_t)colsC + (size_t)k_col * (size_t)colsC + (size_t)cb;
                    //     // const float* Brow_neg = denseB_p + (size_t)neg_idx * (size_t)colsA * (size_t)colsC + (size_t)k_col * (size_t)colsC + (size_t)cb;
                    //     // printf("v=%d, pos_idx=%d, neg_idx=%d, kc_eff=%d, nb_eff=%d, pos_offset=%d, neg_offset=%d, k_col=%d, kb=%d, rb=%d, cb=%d, local_i=%d\n",
                    //     //                             v, pos_idx,neg_idx,kc_eff,nb_eff,int(Brow_pos-denseB_p),int(Brow_neg-denseB_p),k_col,kb,rb,cb,local_i);
                    //     int j = 0;
                    //     for (; j < vec_end; j += VEC_WIDTH) {
                    //         __m256 accv = _mm256_load_ps(acc_row + j);
                    //         __m256 bvec_pos = _mm256_load_ps(Brow_pos + j);
                    //         __m256 bvec_neg = _mm256_load_ps(Brow_neg + j);
                    //         accv = _mm256_add_ps(accv, _mm256_sub_ps(bvec_pos, bvec_neg));
                    //         _mm256_store_ps(acc_row + j, accv);
                    //     }
                    //     if (vec_end < nb_eff) {
                    //         for (int jj = vec_end; jj < nb_eff; ++jj){
                    //             acc_row[jj] += Brow_pos[jj] - Brow_neg[jj];
                    //         }
                    //     }
                    // } // singletons
                }
            }
            // for (int local_i = 0; local_i < rb_eff; ++local_i) {
            //     int i = rb + local_i;
            //     float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
            //     float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
            //     int j = 0;
            //     for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
            //         __m256 tmpv = _mm256_load_ps(src_row + j);
            //         _mm256_storeu_ps(Crow + j, tmpv);
            //     }
            //     for (; j < nb_eff; ++j) Crow[j] = src_row[j];
            // }
            if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
            if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
        }
    }

    return true;
}
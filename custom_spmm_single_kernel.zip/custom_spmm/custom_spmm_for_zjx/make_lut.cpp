#include "MKL_Sparse_Methods.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

float* make_weight_LUT(float* W, int M, int N) {
    // 计算需要的组数（向上取整）
    int M_groups = (M + LWIDTH - 1) / LWIDTH;  // 等价于 ceil(M/LWIDTH)

    // 定义16个4维的0-1向量（0-15的二进制表示）
    int binary_vectors[LWIDTH_POW2][LWIDTH] = {
        {0, 0, 0, 0}, {0, 0, 0, 1}, {0, 0, 1, 0}, {0, 0, 1, 1},
        {0, 1, 0, 0}, {0, 1, 0, 1}, {0, 1, 1, 0}, {0, 1, 1, 1},
        {1, 0, 0, 0}, {1, 0, 0, 1}, {1, 0, 1, 0}, {1, 0, 1, 1},
        {1, 1, 0, 0}, {1, 1, 0, 1}, {1, 1, 1, 0}, {1, 1, 1, 1}
    };

    float* weightLUT = (float*)malloc(LWIDTH_POW2 * M_groups * N * sizeof(float));
    if (weightLUT == NULL) {
        fprintf(stderr, "Error: Failed to allocate memory for weightLUT\n");
        return NULL;
    }
    // 执行映射操作 - 修改了索引顺序
    for (int lut_idx = 0; lut_idx < LWIDTH_POW2; lut_idx++){
        for (int m = 0; m < M_groups; m++) {
            for (int n = 0; n < N; n++) {
                weightLUT[lut_idx * M_groups * N + m*N + n] = 0.0f;

                for (int k = 0; k < LWIDTH; k++) {
                    int row_in_W = m * LWIDTH + k; // 在原矩阵W中的行号
                    
                    if (row_in_W < M) {
                        weightLUT[lut_idx * M_groups * N + m*N + n] += W[row_in_W*N+n] * binary_vectors[lut_idx][k];
                    }                        
                }
            }
        }
    }
    return weightLUT;
}

// 对应的释放函数
void free_weight_LUT(float* A) {
    if (A == NULL) return;
    free(A);  // 释放一级指针数组
}


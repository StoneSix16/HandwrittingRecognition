# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DeiT: https://github.com/facebookresearch/deit
# BEiT: https://github.com/microsoft/unilm/tree/master/beit
# --------------------------------------------------------

import math
import sys
from typing import Iterable, Optional

import torch
# import wandb
from timm.data import Mixup
from timm.utils import accuracy
from torch.utils.tensorboard import SummaryWriter
import util.misc as misc
import util.lr_sched as lr_sched
from copy import deepcopy
import torch.nn.functional as F
from spike_quan_wrapper import open_dropout
from spike_quan_layer import cal_overfire_loss
from torch.nn.utils import prune
import re
from torch.utils.checkpoint import checkpoint
from spike_quan_layer import ST_BIFNeuron_MS, MyQuan
import time
from torch.profiler import profile, record_function, ProfilerActivity, tensorboard_trace_handler


def get_logits_loss(fc_t, fc_s, one_hot_label, temp, num_classes=1000):
    s_input_for_softmax = fc_s / temp
    t_input_for_softmax = fc_t / temp

    softmax = torch.nn.Softmax(dim=1)
    logsoftmax = torch.nn.LogSoftmax()

    t_soft_label = softmax(t_input_for_softmax)

    softmax_loss = - torch.sum(t_soft_label * logsoftmax(s_input_for_softmax), 1, keepdim=True)

    fc_s_auto = fc_s.detach()
    fc_t_auto = fc_t.detach()
    log_softmax_s = logsoftmax(fc_s_auto)
    log_softmax_t = logsoftmax(fc_t_auto)
    # one_hot_label = F.one_hot(label, num_classes=num_classes).float()
    softmax_loss_s = - torch.sum(one_hot_label * log_softmax_s, 1, keepdim=True)
    softmax_loss_t = - torch.sum(one_hot_label * log_softmax_t, 1, keepdim=True)

    focal_weight = softmax_loss_s / (softmax_loss_t + 1e-7)
    ratio_lower = torch.zeros(1).cuda()
    focal_weight = torch.max(focal_weight, ratio_lower)
    focal_weight = 1 - torch.exp(- focal_weight)
    softmax_loss = focal_weight * softmax_loss

    soft_loss = (temp ** 2) * torch.mean(softmax_loss)

    return soft_loss

def train_one_epoch(model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None,
                    args=None):
    model.train(True)
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = args.print_freq

    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):
        if args.profile_time and data_iter_step >= 2:
            break
        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)

        with torch.cuda.amp.autocast():
            if args.mode != "SNN":
                outputs = model(samples)
            else:
                outputs, counts = model(samples, verbose=False)
            loss = criterion(outputs, targets)

        loss_value = loss.item()

        if not math.isfinite(loss_value):
            print("Loss is {}, stopping training".format(loss_value))
            sys.exit(1)

        loss /= accum_iter
        loss_scaler(loss, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        # 对于模型的每个参数，计算其梯度的L2范数
        # for param in model.parameters():
        #     if param.grad is not None:
        #         grad_norm = torch.norm(param.grad, p=2)
        #         print(grad_norm)
        # loss_scaler.scale(loss).backward()
        # torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=20, norm_type=2)
        # loss_scaler.step(optimizer)
        # loss_scaler.update()
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        metric_logger.update(loss=loss_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        if args.mode == "SNN":
            model.module.reset()

        loss_value_reduce = misc.all_reduce_mean(loss_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)
            if args.mode == "SNN":
                log_writer.add_scalar('counts', counts, epoch_1000x)
            if args.wandb:
                wandb.log({'loss_curve': loss_value_reduce}, step=epoch_1000x)
                wandb.log({'lr_curve': max_lr}, step=epoch_1000x)
                if args.mode == "SNN":
                    wandb.log({'counts': counts}, step=epoch_1000x)
    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}

def replace_decimal_strings(input_string):
    pattern = r'\.(\d+)'
    
    replaced_string = re.sub(pattern, r'[\1]', input_string)

    return replaced_string

def unstruct_prune(model,ratio):
    
    # reset weight_mask
    for name, m in model.named_modules():
        if isinstance(m,torch.nn.Linear) or isinstance(m,torch.nn.Conv2d):
            if hasattr(m,"weight_mask"):
                print(m)
                m.weight.data = m.weight_orig
                m.weight_mask[m.weight_mask==0] = 1

    parameters_to_prune = []
    for name, m in model.named_modules():
        # if isinstance(m,torch.nn.Linear) or isinstance(m,torch.nn.Conv2d):
        #     parameters_to_prune.append((m ,'weight'))
        if name.count("proj")>0 or name.count("fc2")>0:
            if isinstance(m,torch.nn.Sequential) and isinstance(m[0],torch.nn.Linear):
                # print(name,m)
                parameters_to_prune.append((m[0],'weight'))
            elif isinstance(m,torch.nn.Linear):
                # print(name,m)
                parameters_to_prune.append((m ,'weight'))
    # print(tuple(parameters_to_prune),ratio)

    # global_unstructured
    prune.global_unstructured(
    parameters_to_prune,
    pruning_method=prune.L1Unstructured,
        amount=ratio,
    )
    zero_number = 0
    total_bumber = 0
    for name, m in model.named_modules():
        if name.count("proj")>0 or name.count("fc2")>0:
            if isinstance(m,torch.nn.Sequential) and isinstance(m[0],torch.nn.Linear):
                zero_number = zero_number + torch.sum(m[0].weight==0)
                total_bumber = total_bumber + m[0].weight.numel()
            elif isinstance(m,torch.nn.Linear):
                zero_number = zero_number + torch.sum(m.weight==0)
                total_bumber = total_bumber + m.weight.numel()

    print("prune finish!!!!! global sparsity:",(zero_number/total_bumber)*100)
    
def train_one_epoch_distill_prune(model: torch.nn.Module, model_teacher: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None,
                    args=None):
    model.train(True)
    model_teacher.eval()
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = args.print_freq

    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))
    
    # first prune for a certain ratio
    unstruct_prune(model,args.ratio[epoch])
    
    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):

        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)

        with torch.cuda.amp.autocast():
            outputs = model(samples)
            outputs_teacher = model_teacher(samples)
            loss = criterion(outputs, targets)
            loss_distill = get_logits_loss(outputs_teacher, outputs, targets, args.temp)
            loss_all = loss + loss_distill

        loss_value = loss.item()
        loss_distill_value = loss_distill.item()
        loss_all_value = loss_all.item()

        if not math.isfinite(loss_all_value):
            print("Loss is {}, stopping training".format(loss_all_value))
            sys.exit(1)

        loss_all /= accum_iter
        loss_scaler(loss_all, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        metric_logger.update(loss_all=loss_all_value, loss=loss_value, loss_distill=loss_distill_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        loss_all_value_reduce = misc.all_reduce_mean(loss_all_value)
        loss_value_reduce = misc.all_reduce_mean(loss_value)
        loss_distill_value_reduce = misc.all_reduce_mean(loss_distill_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss_all', loss_all_value_reduce, epoch_1000x)
            log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('loss_distill', loss_distill_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)
            if args.wandb:
                wandb.log({'loss_all_curve': loss_all_value_reduce}, step=epoch_1000x)
                wandb.log({'loss_curve': loss_value_reduce}, step=epoch_1000x)
                wandb.log({'loss_distill_curve': loss_distill_value_reduce}, step=epoch_1000x)
                wandb.log({'lr_curve': max_lr}, step=epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}



def train_one_epoch_distill(model: torch.nn.Module, model_teacher: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None, aug=None, trival_aug=None,
                    args=None):
    model.train(True)
    model_teacher.eval()
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = args.print_freq
    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):
        
        # if data_iter_step > 2000:
        #     break
        
        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        if args.dataset == "cifar10dvs" or args.dataset == "dvs128":
            N = samples.shape[0]
            if aug != None:
                # image = image.flatten(1, 2).contiguous() # 合并T,C
                samples = torch.stack([(aug(samples[i])) for i in range(N)])
                # image = image.reshape(N,T,C,H,W)

            if trival_aug != None:
                # image = image.flatten(0,1).contiguous()
                samples = torch.stack([(trival_aug(samples[i])) for i in range(N)])
                # image = image.reshape(N,T,C,H,W).contiguous()
            # print("samples",samples.shape)
            if args.mode == "SNN" and args.dataset == "dvs128":
                pass
            else:
                samples = samples.sum(dim=1)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)
            targets_one_hot = targets
        else:
            targets_one_hot = torch.nn.functional.one_hot(targets, args.nb_classes)
        # print(model.module.blocks[0].norm1[0].weight)
        with torch.amp.autocast(device_type='cuda', enabled=True):
            if args.mode != "SNN":
                outputs = model(samples)
                # outputs_teacher = model_teacher(samples)
                loss = criterion(outputs.float(), targets)
            else:
                outputs, counts, output_ts = model(samples, verbose=True)
                # outputs_teacher = model_teacher(samples)
                # loss = criterion(output_ts[7].float(), targets) + (torch.abs(output_ts[8]) - torch.abs(output_ts[7])).sum()/output_ts[8:].numel()
                loss = criterion(outputs.float(), targets)
            # loss_distill = get_logits_loss(outputs_teacher, outputs, targets_one_hot, args.temp, num_classes=args.nb_classes)
            loss_distill = torch.tensor(0.0).to(loss.device)
            if hasattr(args, "suppress_over_fire") and args.suppress_over_fire:
                overfire_loss = cal_overfire_loss(model)*0.1
            loss_all = loss + loss_distill + (overfire_loss if hasattr(args, "suppress_over_fire") and args.suppress_over_fire else 0.0)
        loss_value = loss.item()
        loss_distill_value = loss_distill.item()
        if hasattr(args, "suppress_over_fire") and args.suppress_over_fire:
            overfire_loss_value  = overfire_loss.item()
        loss_all_value = loss_all.item()

        if not math.isfinite(loss_all_value):
            print("Loss is {}, stopping training".format(loss_all_value))
            sys.exit(1)

        loss_all /= accum_iter
        loss_scaler(loss_all, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0,data_iter_step=data_iter_step)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        if hasattr(args, "suppress_over_fire") and args.suppress_over_fire:
            metric_logger.update(loss_all=loss_all_value, loss=loss_value, loss_distill=loss_distill_value, overfire_loss = overfire_loss_value)
        else:
            metric_logger.update(loss_all=loss_all_value, loss=loss_value, loss_distill=loss_distill_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        loss_all_value_reduce = misc.all_reduce_mean(loss_all_value)
        loss_value_reduce = misc.all_reduce_mean(loss_value)
        loss_distill_value_reduce = misc.all_reduce_mean(loss_distill_value)
        if hasattr(args, "suppress_over_fire") and args.suppress_over_fire:
            overfire_loss_value_reduce = misc.all_reduce_mean(overfire_loss_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss_all', loss_all_value_reduce, epoch_1000x)
            log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('loss_distill', loss_distill_value_reduce, epoch_1000x)
            if hasattr(args, "suppress_over_fire") and args.suppress_over_fire:
                log_writer.add_scalar('loss_overfire', overfire_loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)
            if args.wandb:
                wandb.log({'loss_all_curve': loss_all_value_reduce}, step=epoch_1000x)
                wandb.log({'loss_curve': loss_value_reduce}, step=epoch_1000x)
                wandb.log({'loss_distill_curve': loss_distill_value_reduce}, step=epoch_1000x)
                if hasattr(args, "suppress_over_fire") and args.suppress_over_fire:
                    wandb.log({'loss_overfire_curve': overfire_loss_value_reduce}, step=epoch_1000x)
                wandb.log({'lr_curve': max_lr}, step=epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


def train_one_epoch_distill_mse(model: torch.nn.Module, model_teacher: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer=None,
                    args=None):
    model.train(True)
    model_teacher.eval()
    metric_logger = misc.MetricLogger(delimiter="  ")
    metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
    header = 'Epoch: [{}]'.format(epoch)
    print_freq = args.print_freq
    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):

        # we use a per iteration (instead of per epoch) lr scheduler
        if data_iter_step % accum_iter == 0:
            lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

        samples = samples.to(device, non_blocking=True)
        targets = targets.to(device, non_blocking=True)

        if mixup_fn is not None:
            samples, targets = mixup_fn(samples, targets)
        # print(model.module.blocks[0].norm1[0].weight)
        with torch.cuda.amp.autocast():
            if args.mode != "SNN":
                outputs = model(samples)
            else:
                outputs, counts = model(samples, verbose=False)
            outputs_teacher = model_teacher(samples)
            loss = criterion(outputs, targets).detach()
            # loss_distill = get_logits_loss(outputs_teacher, outputs, targets, args.temp)
            loss_distill = torch.nn.functional.mse_loss(outputs, outputs_teacher)
            loss_all = loss + loss_distill
        loss_value = loss.item()
        loss_distill_value = loss_distill.item()
        loss_all_value = loss_all.item()

        if not math.isfinite(loss_all_value):
            print("Loss is {}, stopping training".format(loss_all_value))
            sys.exit(1)

        loss_all /= accum_iter
        loss_scaler(loss_all, optimizer, clip_grad=max_norm,
                    parameters=model.parameters(), create_graph=False,
                    update_grad=(data_iter_step + 1) % accum_iter == 0)
        if (data_iter_step + 1) % accum_iter == 0:
            optimizer.zero_grad()

        torch.cuda.synchronize()

        metric_logger.update(loss_all=loss_all_value, loss=loss_value, loss_distill=loss_distill_value)
        min_lr = 10.
        max_lr = 0.
        for group in optimizer.param_groups:
            min_lr = min(min_lr, group["lr"])
            max_lr = max(max_lr, group["lr"])

        metric_logger.update(lr=max_lr)

        loss_all_value_reduce = misc.all_reduce_mean(loss_all_value)
        loss_value_reduce = misc.all_reduce_mean(loss_value)
        loss_distill_value_reduce = misc.all_reduce_mean(loss_distill_value)
        if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
            """ We use epoch_1000x as the x-axis in tensorboard.
            This calibrates different curves when batch size changes.
            """
            epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
            log_writer.add_scalar('loss_all', loss_all_value_reduce, epoch_1000x)
            log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
            log_writer.add_scalar('loss_distill', loss_distill_value_reduce, epoch_1000x)
            log_writer.add_scalar('lr', max_lr, epoch_1000x)
            if args.wandb:
                wandb.log({'loss_all_curve': loss_all_value_reduce}, step=epoch_1000x)
                wandb.log({'loss_curve': loss_value_reduce}, step=epoch_1000x)
                wandb.log({'loss_distill_curve': loss_distill_value_reduce}, step=epoch_1000x)
                wandb.log({'lr_curve': max_lr}, step=epoch_1000x)

    # gather the stats from all processes
    metric_logger.synchronize_between_processes()
    print("Averaged stats:", metric_logger)
    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


def Align_QANN_SNN(model: torch.nn.Module, QANN_model: torch.nn.Module, criterion: torch.nn.Module,
                    data_loader: Iterable, optimizer: torch.optim.Optimizer,
                    device: torch.device, epoch: int, loss_scaler, max_norm: float = 0,
                    mixup_fn: Optional[Mixup] = None, log_writer:Optional[SummaryWriter] = None,
                    args=None):
    torch.set_printoptions(precision=6)
    model_layer_out = None    
    ideal_snn_out = None   
    name1 = ""
    name2 = ""
    def qann_layer_hook(module, inp, out):
        nonlocal ideal_snn_out, model, name2, log_writer
        s_scale = module.s.type(out.dtype)
        qann_model_layer_out = out+0.0
        ideal_snn_out = []
        # if log_writer is not None:
        #     log_writer.add_histogram(tag=f"{name1}/quan_sum", values=(qann_model_layer_out/s_scale).detach().cpu(), global_step=0)
        for i in range(model.module.T):
            out1 = qann_model_layer_out*0.0
            out1[qann_model_layer_out>=s_scale-1e-3] = s_scale
            out1[qann_model_layer_out<=-s_scale+1e-3] = -s_scale
            qann_model_layer_out = qann_model_layer_out - out1
            # if log_writer is not None:
            #     log_writer.add_histogram(tag=f"{name1}/quan", values=(out1/s_scale).detach().cpu(), global_step=i)
            ideal_snn_out.append(out1)

        ideal_snn_out = torch.stack(ideal_snn_out,dim=0).detach()

    def snn_layer_hook(module, inp, out):
        nonlocal model_layer_out, name1, log_writer
        T = model.module.T
        model_layer_out = out.reshape(torch.Size([T,out.shape[0]//T]) + out.shape[1:])
        # for i in range(T):
        #     if log_writer is not None:
        #         log_writer.add_histogram(tag=f"{name1}/ST_BIF", values=(model_layer_out[i]/module.q_threshold).detach().cpu(), global_step=i)
        # if log_writer is not None:
        #     log_writer.add_histogram(tag=f"{name1}/ST_BIF_sum", values=((model_layer_out/module.q_threshold).sum(dim=0)).detach().cpu(), global_step=0)
        # model_layer_out = out.sum(dim=0)
    
    model.train(True)
    QANN_model.eval()
    print_freq = args.print_freq
    accum_iter = args.accum_iter

    optimizer.zero_grad()

    if log_writer is not None:
        print('log_dir: {}'.format(log_writer.log_dir))

    index1 = -1
    index2 = -1
    
    # for param in model.parameters():
    #     param.requires_grad = False
    
    while(1):
                
        for i, (name1, module1) in enumerate(list(model.named_modules())):
            if isinstance(module1, ST_BIFNeuron_MS) and i > index1:
                index1 = i
                break

        for i, (name2, module2) in enumerate(list(QANN_model.named_modules())):
            if isinstance(module2, MyQuan) and i > index2:
                index2 = i
                break
        
        if name1.count("attn_IF") > 0:
            continue

        print(name1,name2)
        if i == len(list(QANN_model.named_modules())) - 1:
            break
        
        h1 = module1.register_forward_hook(snn_layer_hook)
        h2 = module2.register_forward_hook(qann_layer_hook)

        # if epoch < 20:
        #     print(f"skip layer {name1}!!!")
        #     epoch = epoch + 1
        #     continue
        
        # module1.time_allocator.requires_grad = True
        # for param in module1.parameters():
        #     param.requires_grad = True
        
        print(f"aligning {name1} layer.....")

        metric_logger = misc.MetricLogger(delimiter="  ")
        metric_logger.add_meter('lr', misc.SmoothedValue(window_size=1, fmt='{value:.6f}'))
        header = 'Epoch: [{}]'.format(epoch)

        epoch = epoch + 1
        for data_iter_step, (samples, targets) in enumerate(metric_logger.log_every(data_loader, print_freq, header)):            
            
            
            # if name1.count("after_attn_IF") > 0 or name1.count("proj_IF") > 0 or name1.count("norm2") > 0:
            #     if data_iter_step > 1000:
            #         break
            # else:
            if data_iter_step > 200:
                break
            # if data_iter_step % accum_iter == 0:
            #     lr_sched.adjust_learning_rate(optimizer, data_iter_step / len(data_loader) + epoch, args)

            samples = samples.to(device, non_blocking=True)
            targets = targets.to(device, non_blocking=True)

            if mixup_fn is not None:
                samples, targets = mixup_fn(samples, targets)
            # print(model.module.blocks[0].norm1[0].weight)
            with torch.cuda.amp.autocast():
                # print("=========================SNN==========================")
                outputs_snn, counts = model(samples, verbose=False)
                # print("=========================QANN==========================")
                outputs_qann = QANN_model(samples)
                # print(model_layer_out.shape, ideal_snn_out.shape)
                loss = torch.nn.functional.l1_loss(model_layer_out, ideal_snn_out,reduction="mean") + \
                        torch.nn.functional.l1_loss(outputs_snn, outputs_qann,reduction="mean")*0.0

            loss_value = loss.item()

            if not math.isfinite(loss_value):
                print("Loss is {}, stopping training".format(loss_value))
                sys.exit(1)

            # if loss_value < 1e-4:
            #     pass
            # else:
            loss /= accum_iter
            loss_scaler(loss, optimizer, clip_grad=max_norm,
                        parameters=model.parameters(), create_graph=False,
                        update_grad=(data_iter_step + 1) % accum_iter == 0)

            # print("module1.time_allocator.grad",module1.time_allocator.grad)
            
            optimizer.zero_grad()

            torch.cuda.synchronize()

            metric_logger.update(loss=loss_value)
            min_lr = 10.
            max_lr = 0.
            for group in optimizer.param_groups:
                min_lr = min(min_lr, group["lr"])
                max_lr = max(max_lr, group["lr"])

            metric_logger.update(lr=max_lr)

            loss_value_reduce = misc.all_reduce_mean(loss_value)
            if log_writer is not None and (data_iter_step + 1) % accum_iter == 0:
                """ We use epoch_1000x as the x-axis in tensorboard.
                This calibrates different curves when batch size changes.
                """
                epoch_1000x = int((data_iter_step / len(data_loader) + epoch) * 1000)
                log_writer.add_scalar('loss', loss_value_reduce, epoch_1000x)
                log_writer.add_scalar('lr', max_lr, epoch_1000x)
                if args.wandb:
                    wandb.log({'loss_curve': loss_value_reduce}, step=epoch_1000x)
                    wandb.log({'lr_curve': max_lr}, step=epoch_1000x)

            if loss_value_reduce < 1e-4:
                print(f"loss is less than 1e-4 during training, {name1} layer alignment finish!!!!")
                break

        # gather the stats from all processes
        metric_logger.synchronize_between_processes()                
        stats = {k: meter.global_avg for k, meter in metric_logger.meters.items()}
        if stats['loss'] < 1e-3:
            print(f"loss is less than 1e-3 after training, {name1} layer alignment finish!!!!")
            #     break
        h1.remove()
        h2.remove()    

        # for param in module1.parameters():
        #     param.requires_grad = False
        # module1.time_allocator.requires_grad = False

    # for param in model.parameters():
    #     param.requires_grad = True


@torch.no_grad()
def evaluate(data_loader, model, device, snn_aug, mode, args):
    criterion = torch.nn.CrossEntropyLoss()

    metric_logger = misc.MetricLogger(delimiter="  ")
    header = 'Test:'

    # switch to evaluation mode
    model.eval()
    # open_dropout(model)
    # if args.mode == "SNN":
    #     model.max_T = 0
    total_num = 0
    correct_per_timestep = None
    
    max_T = 0
    for batch in metric_logger.log_every(data_loader, 1, header):
        images = batch[0]
        target = batch[-1]
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        if args.dataset == "cifar10dvs" or args.dataset == "dvs128":
            N = images.shape[0]
            if snn_aug != None:
                # image = image.flatten(1, 2).contiguous() # 合并T,C
                images = torch.stack([(snn_aug(images[i])) for i in range(N)])
            if args.mode == "SNN" and args.dataset == "dvs128":
                pass
            else:
                images = images.sum(dim=1)
        # compute output
        # with torch.cuda.amp.autocast():
        if mode != "SNN":
            t1 = time.perf_counter()
            output = model(images)
            t2 = time.perf_counter()
            total_time = t2 - t1
        else:
            # accu_per_timestep: cur_T * B * n_classes
            t1 = time.perf_counter()
            output, count, accu_per_timestep = model(images, verbose=True)
            t2 = time.perf_counter()
            total_time = t2 - t1
            # print(accu_per_timestep.shape, count)
            max_T = max(max_T, count)
            # print(max_T)
            if accu_per_timestep.shape[0] < max_T:
                padding_per_timestep = accu_per_timestep[-1].unsqueeze(0)
                padding_length = max_T - accu_per_timestep.shape[0]
                accu_per_timestep = torch.cat(
                    [accu_per_timestep, padding_per_timestep.repeat(padding_length, 1, 1)], dim=0)

            if correct_per_timestep is not None and correct_per_timestep.shape[0] < max_T:
                for t in range(correct_per_timestep.shape[0], max_T):
                    metric_logger.meters['acc@{}'.format(t + 1)] = deepcopy(metric_logger.meters['acc@{}'.format(correct_per_timestep.shape[0])])

            _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)

            # if correct_per_timestep is None:
            #     _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            #     correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
            # else:
            #     _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            #     # print(correct_per_timestep.shape, predicted_per_time_step.shape, target.unsqueeze(0).shape)
            #     correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
        # output = model(images)
        loss = criterion(output, target)

        total_num += images.shape[0]

        acc1, acc5 = accuracy(output, target, topk=(1, 5))
        # print(output.argmax(-1).reshape(-1))
        # print(target)
        # print("acc1, acc5",acc1, acc5)

        batch_size = images.shape[0]
        metric_logger.update(loss=loss.item())
        metric_logger.meters['acc1'].update(acc1.item(), n=batch_size)
        metric_logger.meters['acc5'].update(acc5.item(), n=batch_size)
        metric_logger.meters['model_time'].update(total_time)
        if mode == "SNN":
            for t in range(max_T):
                metric_logger.meters['acc@{}'.format(t + 1)].update(
                    correct_per_timestep[t].cpu().item() * 100. / batch_size, n=batch_size)
            model.reset()
        
        # break

        # count1 += 1
        # if count1 >= 3:
        #     break
    # gather the stats from all processes
    # accuracy_per_timestep = correct_per_timestep.float().cpu().data / float(total_num)
    print("Evaluation End")
    metric_logger.synchronize_between_processes()
    print('* Acc@1 {top1.global_avg:.3f} Acc@5 {top5.global_avg:.3f} loss {losses.global_avg:.3f}'
          .format(top1=metric_logger.acc1, top5=metric_logger.acc5, losses=metric_logger.loss))

    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}

@torch.no_grad()
def evaluateLCC(data_loader, model, device, snn_aug, mode, args):
    print("Testing LoCC SNN.....")
    
    criterion = torch.nn.CrossEntropyLoss()

    metric_logger = misc.MetricLogger(delimiter="  ")
    header = 'Test:'

    # switch to evaluation mode
    model.eval()
    # open_dropout(model)
    # if args.mode == "SNN":
    #     model.max_T = 0
    total_num = 0
    correct_per_timestep = None
    
    max_T = 0
    count1 = 0
        
    for batch in metric_logger.log_every(data_loader, 1, header):
        images = batch[0]
        target = batch[-1]
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)

        # compute output
        # with torch.cuda.amp.autocast():
        if mode != "SNN":
            t1 = time.perf_counter()
            output = model(images)
            t2 = time.perf_counter()
            total_time = t2 - t1
        else:
            # accu_per_timestep: cur_T * B * n_classes
            t1 = time.perf_counter()
            output, count, accu_per_timestep = model(images, verbose=True)
            t2 = time.perf_counter()
            total_time = t2 - t1
            # print(accu_per_timestep.shape, count)
            max_T = max(max_T, count)
            # print(max_T)
            if accu_per_timestep.shape[0] < max_T:
                padding_per_timestep = accu_per_timestep[-1].unsqueeze(0)
                padding_length = max_T - accu_per_timestep.shape[0]
                accu_per_timestep = torch.cat(
                    [accu_per_timestep, padding_per_timestep.repeat(padding_length, 1, 1)], dim=0)

            if correct_per_timestep is not None and correct_per_timestep.shape[0] < max_T:
                for t in range(correct_per_timestep.shape[0], max_T):
                    metric_logger.meters['acc@{}'.format(t + 1)] = deepcopy(metric_logger.meters['acc@{}'.format(correct_per_timestep.shape[0])])

            _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
            # if correct_per_timestep is None:
            #     _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            #     correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
            # else:
            #     _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            #     # print(correct_per_timestep.shape, predicted_per_time_step.shape, target.unsqueeze(0).shape)
            #     correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
        # output = model(images)
        loss = criterion(output, target)

        total_num += images.shape[0]

        acc1, acc5 = accuracy(output, target, topk=(1, 5))
        # print(output.argmax(-1).reshape(-1))
        # print(target)
        # print("acc1, acc5",acc1, acc5)

        batch_size = images.shape[0]
        metric_logger.update(loss=loss.item())
        metric_logger.meters['acc1'].update(acc1.item(), n=batch_size)
        metric_logger.meters['acc5'].update(acc5.item(), n=batch_size)
        metric_logger.meters['model_time'].update(total_time)
        if mode == "SNN":
            for t in range(max_T):
                metric_logger.meters['acc@{}'.format(t + 1)].update(
                    correct_per_timestep[t].cpu().item() * 100. / batch_size, n=batch_size)

        # count1 += 1
        # if count1 >= 1:
        #     break
    # gather the stats from all processes
    # accuracy_per_timestep = correct_per_timestep.float().cpu().data / float(total_num)
    print("Evaluation End")
    metric_logger.synchronize_between_processes()
    print('* Acc@1 {top1.global_avg:.3f} Acc@5 {top5.global_avg:.3f} loss {losses.global_avg:.3f}'
          .format(top1=metric_logger.acc1, top5=metric_logger.acc5, losses=metric_logger.loss))

    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}


@torch.no_grad()
def evaluateProfile(data_loader, model, device, snn_aug, mode, args):
    criterion = torch.nn.CrossEntropyLoss()

    metric_logger = misc.MetricLogger(delimiter="  ")
    header = 'Test:'

    # switch to evaluation mode
    model.eval()
    # open_dropout(model)
    # if args.mode == "SNN":
    #     model.max_T = 0
    total_num = 0
    correct_per_timestep = None
    # warmup = 10
    # iter1 = 0
    
    max_T = 0
    count1 = 0
    for batch in data_loader:
        images = batch[0]
        target = batch[-1]
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        output, count, accu_per_timestep = model(images, verbose=True)
        if mode == "SNN":
            model.reset()
        break
        
    
    for batch in metric_logger.log_every(data_loader, 1, header):
        images = batch[0]
        target = batch[-1]
        images = images.to(device, non_blocking=True)
        target = target.to(device, non_blocking=True)
        if args.dataset == "cifar10dvs" or args.dataset == "dvs128":
            N = images.shape[0]
            if snn_aug != None:
                # image = image.flatten(1, 2).contiguous() # 合并T,C
                images = torch.stack([(snn_aug(images[i])) for i in range(N)])
            if args.mode == "SNN" and args.dataset == "dvs128":
                pass
            else:
                images = images.sum(dim=1)
        # compute output
        # with torch.cuda.amp.autocast():
        if mode != "SNN":
            t1 = time.perf_counter()
            output = model(images)
            t2 = time.perf_counter()
            total_time = t2 - t1
        else:
            # accu_per_timestep: cur_T * B * n_classes
            # iter1 = iter1 + 1
            # if iter1 <= warmup:
            #     output, count, accu_per_timestep = model(images, verbose=True)
            #     model.reset()
            #     continue
            activities = [ProfilerActivity.CPU]
            # trace_handler 会在每个 step 后写入事件文件到 log_dir
            with profile(
                    activities=activities,
                    record_shapes=True,
                    profile_memory=False,
                    with_stack=True,
                    on_trace_ready=tensorboard_trace_handler(args.log_dir)
                ) as prof:
                t1 = time.perf_counter()
                output, count, accu_per_timestep = model(images, verbose=True)
                t2 = time.perf_counter()

            print(prof.key_averages().table(
                sort_by="cpu_time_total", row_limit=50, top_level_events_only=False
            ))
            print(f"\n✅ Trace written to {args.log_dir}.")
            print("   运行 TensorBoard：")
            print(f"     tensorboard --logdir={args.log_dir}")
            print("   然后在浏览器打开 http://localhost:6006")
            print("   选择 “Profiler” 面板，切换到 Operator Tree / Call Stack / Call Graph 查看调用关系。")            
            total_time = (t2 - t1)
            print("model_time=",total_time*1000,"ms")
            # print(accu_per_timestep.shape, count)
            max_T = max(max_T, count)
            # print(max_T)
            if accu_per_timestep.shape[0] < max_T:
                padding_per_timestep = accu_per_timestep[-1].unsqueeze(0)
                padding_length = max_T - accu_per_timestep.shape[0]
                accu_per_timestep = torch.cat(
                    [accu_per_timestep, padding_per_timestep.repeat(padding_length, 1, 1)], dim=0)

            if correct_per_timestep is not None and correct_per_timestep.shape[0] < max_T:
                for t in range(correct_per_timestep.shape[0], max_T):
                    metric_logger.meters['acc@{}'.format(t + 1)] = deepcopy(metric_logger.meters['acc@{}'.format(correct_per_timestep.shape[0])])

            _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)

            # if correct_per_timestep is None:
            #     _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            #     correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
            # else:
            #     _, predicted_per_time_step = torch.max(accu_per_timestep.data, 2)
            #     # print(correct_per_timestep.shape, predicted_per_time_step.shape, target.unsqueeze(0).shape)
            #     correct_per_timestep = torch.sum((predicted_per_time_step == target.unsqueeze(0)), dim=1)
        # output = model(images)
        loss = criterion(output, target)

        total_num += images.shape[0]

        acc1, acc5 = accuracy(output, target, topk=(1, 5))
        # print(output.argmax(-1).reshape(-1))
        # print(target)
        # print("acc1, acc5",acc1, acc5)

        batch_size = images.shape[0]
        metric_logger.update(loss=loss.item())
        metric_logger.meters['acc1'].update(acc1.item(), n=batch_size)
        metric_logger.meters['acc5'].update(acc5.item(), n=batch_size)
        metric_logger.meters['model_time'].update(total_time)
        if mode == "SNN":
            for t in range(max_T):
                metric_logger.meters['acc@{}'.format(t + 1)].update(
                    correct_per_timestep[t].cpu().item() * 100. / batch_size, n=batch_size)
            model.reset()
        
        break

        # count1 += 1
        # if count1 >= 3:
        #     break
    # gather the stats from all processes
    # accuracy_per_timestep = correct_per_timestep.float().cpu().data / float(total_num)
    print("Evaluation End")
    metric_logger.synchronize_between_processes()
    print('* Acc@1 {top1.global_avg:.3f} Acc@5 {top5.global_avg:.3f} loss {losses.global_avg:.3f}'
          .format(top1=metric_logger.acc1, top5=metric_logger.acc5, losses=metric_logger.loss))

    return {k: meter.global_avg for k, meter in metric_logger.meters.items()}

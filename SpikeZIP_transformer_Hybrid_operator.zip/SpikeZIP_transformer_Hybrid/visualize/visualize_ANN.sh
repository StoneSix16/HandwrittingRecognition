python swin_visualize.py \
    --model_path /data/kang_you1/SpikeZIP_transformer_resnet1/output/T-SNN_swin_tiny_imagenet_relu_ANN_act32_weightbit32_NormTypedyt_second_good/checkpoint-best.pth \
    --NormType dyt \
    --remove_softmax \
    --act_layer relu \
    --use-cuda \
    --image-path /home/kang_you/SpikeZIP_transformer_Hybrid/visualize/n02086646_280.JPEG \


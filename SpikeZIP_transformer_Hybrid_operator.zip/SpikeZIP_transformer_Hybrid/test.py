import torch
import math

def make_weight_LUT(W: torch.Tensor, LWIDTH: int = 4) -> torch.Tensor:
    """
    Generate weight LUT from W (MxN) to shape (2^LWIDTH, M_groups, N),
    where M_groups = ceil(M / LWIDTH).
    - W: 2D tensor (M, N)
    - returns: 3D contiguous tensor (2^LWIDTH, M_groups, N)
    """
    if W.dim() != 2:
        raise ValueError("W must be 2D tensor with shape (M, N).")
    if LWIDTH <= 0 or LWIDTH > 30:
        raise ValueError("LWIDTH must be positive (reasonable small integer).")

    M, N = W.shape
    device = W.device
    dtype = W.dtype

    # groups and padding rows
    M_groups = (M + LWIDTH - 1) // LWIDTH
    total_rows = M_groups * LWIDTH
    pad_rows = total_rows - M

    # ensure contiguous input for safe view/reshape
    Wc = W.contiguous()
    if pad_rows > 0:
        pad_tensor = torch.zeros((pad_rows, N), dtype=dtype, device=device)
        Wc = torch.cat([Wc, pad_tensor], dim=0)

    # reshape to (M_groups, LWIDTH, N)
    Wg = Wc.view(M_groups, LWIDTH, N)  # contiguous

    # build binary vectors in msb->lsb order to match your C table:
    # for i in 0..2^LWIDTH-1 produce [ (i>>(LWIDTH-1))&1, ..., (i>>0)&1 ]
    P = 1 << LWIDTH
    bin_list = []
    for i in range(P):
        bits = [ (i >> (LWIDTH - 1 - k)) & 1 for k in range(LWIDTH) ]  # msb..lsb
        bin_list.append(bits)
    binary = torch.tensor(bin_list, dtype=dtype, device=device)  # shape (P, LWIDTH)

    # einsum to compute: for each lut index b and each group g and column n:
    # lut[b, g, n] = sum_k binary[b, k] * Wg[g, k, n]
    lut = torch.einsum('bk,gkn->bgn', binary, Wg)

    # ensure contiguous and return
    return lut.contiguous()

# --------------------------
# 示例 / 测试
if __name__ == "__main__":
    # 示例：M=6, N=5 -> M_groups = ceil(6/4)=2 -> 输出形状 (16,2,5)
    M, N = 5, 6
    W = torch.arange(M * N, dtype=torch.float32).view(M, N)
    lut = make_weight_LUT(W)
    print("W.shape:\n", W)
    print("lut.shape:\n", lut)
    print("lut.is_contiguous():", lut.is_contiguous())

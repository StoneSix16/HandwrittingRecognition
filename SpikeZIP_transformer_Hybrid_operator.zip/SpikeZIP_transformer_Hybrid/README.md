# The code for transformer-based ANN-SNN Conversion Algorithm
- based on ST-BIF neuron


# Copyright (c) Meta Platforms, Inc. and affiliates.
# All rights reserved.

# This source code is licensed under the license found in the
# LICENSE file in the root directory of this source tree.
# --------------------------------------------------------
# References:
# DeiT: https://github.com/facebookresearch/deit
# BEiT: https://github.com/microsoft/unilm/tree/master/beit
# --------------------------------------------------------

import argparse
import datetime
import json
import numpy as np
import os
import time
from pathlib import Path
from copy import deepcopy

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
from torch.utils.tensorboard import SummaryWriter
from functools import partial
import timm
from torchvision import transforms
from util.SNNaugment import SNNAugmentWide
# assert timm.__version__ == "0.3.2"  # version check
from timm.models.layers import trunc_normal_
from timm.data.mixup import Mixup
from timm.loss import LabelSmoothingCrossEntropy, SoftTargetCrossEntropy

import util.lr_decay as lrd
import util.misc as misc
from util.datasets import build_dataset
from util.pos_embed import interpolate_pos_embed
from util.misc import NativeScalerWithGradNormCount as NativeScaler
from spike_quan_wrapper_ICML import myquan_replace, SNNWrapper, SNNWrapperLCC, SNNWrapperFuse, remove_softmax, MyBatchNorm1d, SNNWrapper_MS, add_bn_in_mlp, ST_BIFNeuron_SS, SNNWrapperINT, SNNWrapperLUT
from spike_quan_layer import MyLayerNorm, set_init_false, DyT, DyHT, DyHT_ReLU
import timm.optim.optim_factory as optim_factory

import models_vit
# import wandb

from engine_finetune import evaluate, train_one_epoch_distill, train_one_epoch_distill_mse, Align_QANN_SNN, evaluateLCC, evaluateProfile
from PowerNorm import MaskPowerNorm
import warnings

warnings.filterwarnings("ignore", category=UserWarning)
# torch.set_default_dtype(torch.double)
# torch.set_default_tensor_type(torch.DoubleTensor)
torch.set_printoptions(precision=15)

def get_args_parser():
    parser = argparse.ArgumentParser('MAE fine-tuning for image classification', add_help=False)
    parser.add_argument('--batch_size', default=64, type=int,
                        help='Batch size per GPU (effective batch size is batch_size * accum_iter * # gpus')
    parser.add_argument('--epochs', default=50, type=int)
    parser.add_argument('--print_freq', default=1000, type=int,
                        help='print_frequency')
    parser.add_argument('--accum_iter', default=1, type=int,
                        help='Accumulate gradient iterations (for increasing the effective batch size under memory constraints)')
    parser.add_argument('--project_name', default='T-SNN', type=str, metavar='MODEL',
                        help='Name of model to train')

    # Model parameters
    parser.add_argument('--model', default='vit_small_patch16', type=str, metavar='MODEL',
                        help='Name of model to train')
    parser.add_argument('--model_teacher', default='vit_base_patch16', type=str, metavar='MODEL',
                        help='Name of model to train')

    parser.add_argument('--input_size', default=224, type=int,
                        help='images input size')
    parser.add_argument('--encoding_type', default="analog", type=str,
                        help='encoding type for snn')
    parser.add_argument('--time_step', default=2000, type=int,
                        help='time-step for snn')
    parser.add_argument('--drop_path', type=float, default=0.1, metavar='PCT',
                        help='Drop path rate (default: 0.1)')
    parser.add_argument('--drop_rate', type=float, default=0.0, metavar='PCT',
                        help='Dropout rate')

    # Optimizer parameters
    parser.add_argument('--clip_grad', type=float, default=None, metavar='NORM',
                        help='Clip gradient norm (default: None, no clipping)')
    parser.add_argument('--weight_decay', type=float, default=0.05,
                        help='weight decay (default: 0.05)')

    parser.add_argument('--lr', type=float, default=None, metavar='LR',
                        help='learning rate (absolute lr)')
    parser.add_argument('--blr', type=float, default=1e-3, metavar='LR',
                        help='base learning rate: absolute_lr = base_lr * total_batch_size / 256')
    parser.add_argument('--layer_decay', type=float, default=0.75,
                        help='layer-wise lr decay from ELECTRA/BEiT')
    parser.add_argument('--act_layer', type=str, default="relu",
                        help='Using ReLU or GELU as activation')
    parser.add_argument('--act_layer_teacher', type=str, default="gelu",
                        help='Using ReLU or GELU as activation for teacher model')

    parser.add_argument('--min_lr', type=float, default=1e-6, metavar='LR',
                        help='lower lr bound for cyclic schedulers that hit 0')
    parser.add_argument('--temp', type=float, default=2.0, metavar='T',
                        help='temperature for distillation')

    parser.add_argument('--warmup_epochs', type=int, default=5, metavar='N',
                        help='epochs to warmup LR')

    # Augmentation parameters
    parser.add_argument('--color_jitter', type=float, default=None, metavar='PCT',
                        help='Color jitter factor (enabled only when not using Auto/RandAug)')
    parser.add_argument('--aa', type=str, default='rand-m9-mstd0.5-inc1', metavar='NAME',
                        help='Use AutoAugment policy. "v0" or "original". " + "(default: rand-m9-mstd0.5-inc1)'),
    parser.add_argument('--no_aug', action='store_true', default=False,
                        help='do not apply augmentation')
    parser.add_argument('--smoothing', type=float, default=0.1,
                        help='Label smoothing (default: 0.1)')

    # * Random Erase params
    parser.add_argument('--reprob', type=float, default=0.25, metavar='PCT',
                        help='Random erase prob (default: 0.25)')
    parser.add_argument('--remode', type=str, default='pixel',
                        help='Random erase mode (default: "pixel")')
    parser.add_argument('--recount', type=int, default=1,
                        help='Random erase count (default: 1)')
    parser.add_argument('--resplit', action='store_true', default=False,
                        help='Do not random erase first (clean) augmentation split')

    # * Mixup params
    parser.add_argument('--mixup', type=float, default=0,
                        help='mixup alpha, mixup enabled if > 0.')
    parser.add_argument('--cutmix', type=float, default=0,
                        help='cutmix alpha, cutmix enabled if > 0.')
    parser.add_argument('--cutmix_minmax', type=float, nargs='+', default=None,
                        help='cutmix min/max ratio, overrides alpha and enables cutmix if set (default: None)')
    parser.add_argument('--mixup_prob', type=float, default=1.0,
                        help='Probability of performing mixup or cutmix when either/both is enabled')
    parser.add_argument('--mixup_switch_prob', type=float, default=0.5,
                        help='Probability of switching to cutmix when both mixup and cutmix enabled')
    parser.add_argument('--mixup_mode', type=str, default='batch',
                        help='How to apply mixup/cutmix params. Per "batch", "pair", or "elem"')

    # * Finetuning params
    parser.add_argument('--finetune', default='',
                        help='finetune from checkpoint')
    parser.add_argument('--pretrain_teacher', default='',
                        help='pretrained teacher model')
    parser.add_argument('--global_pool', action='store_true')
    parser.set_defaults(global_pool=True)
    parser.add_argument('--cls_token', action='store_false', dest='global_pool',
                        help='Use class token instead of global pool for classification')

    # Dataset parameters
    parser.add_argument('--dataset', default='imagenet', type=str,
                        help='dataset name')
    parser.add_argument('--data_path', default='/datasets01/imagenet_full_size/061417/', type=str,
                        help='dataset path')
    parser.add_argument('--nb_classes', default=1000, type=int,
                        help='number of the classification types')
    parser.add_argument('--define_params', action='store_true')
    parser.add_argument('--mean', nargs='+', type=float)
    parser.add_argument('--std', nargs='+', type=float)

    parser.add_argument('--output_dir', default='./output_dir',
                        help='path where to save, empty for no saving')
    parser.add_argument('--log_dir', default='./output_dir',
                        help='path where to tensorboard log')
    parser.add_argument('--device', default='cpu',
                        help='device to use for training / testing')
    parser.add_argument('--seed', default=0, type=int)
    parser.add_argument('--resume', default='',
                        help='resume from checkpoint')
    parser.add_argument('--convEmbedding', action='store_true',
                        help='ConvEmbedding from QKFormer')

    parser.add_argument('--start_epoch', default=0, type=int, metavar='N',
                        help='start epoch')
    parser.add_argument('--eval', action='store_true',
                        help='Perform evaluation only')
    parser.add_argument('--wandb', action='store_true',
                        help='Using wandb or not')
    parser.add_argument('--dist_eval', action='store_true', default=False,
                        help='Enabling distributed evaluation (recommended during training for faster monitor')
    parser.add_argument('--num_workers', default=32, type=int)
    parser.add_argument('--pin_mem', action='store_true',
                        help='Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.')
    parser.add_argument('--no_pin_mem', action='store_false', dest='pin_mem')
    parser.set_defaults(pin_mem=True)

    # distributed training parameters
    parser.add_argument('--world_size', default=1, type=int,
                        help='number of distributed processes')
    parser.add_argument('--local_rank', default=-1, type=int)
    parser.add_argument('--dist_on_itp', action='store_true')
    parser.add_argument('--dist_url', default='env://',
                        help='url used to set up distributed training')

    # training mode
    parser.add_argument('--mode', default="ANN", type=str,
                        help='the running mode of the script["ANN", "QANN_PTQ", "QANN_QAT", "SNN"]')

    # LSQ quantization
    parser.add_argument('--level', default=32, type=int,
                        help='the quantization levels')
    parser.add_argument('--weight_quantization_bit', default=32, type=int, help="the weight quantization bit")
    parser.add_argument('--neuron_type', default="ST-BIF", type=str,
                        help='neuron type["ST-BIF", "IF"]')
    parser.add_argument('--remove_softmax', action='store_true',
                        help='need softmax or not')
    parser.add_argument('--NormType', default='layernorm', type=str,
                        help='the normalization type')
    parser.add_argument('--prune', action='store_true',
                        help='prune or not')
    parser.add_argument('--prune_ratio', type=float, default="3e8",
                        help='prune ratio')
    parser.add_argument('--hybrid_training', action='store_true', default=False,
                        help='training after conversion')
    parser.add_argument('--record_inout', action='store_true', default=False,
                        help='record the snn input and output or not')
    parser.add_argument('--energy', action='store_true', default=False,
                        help='calculate energy or not')
    parser.add_argument('--snn_model_path', default="", type=str,
                        help='snn_model_path')
    parser.add_argument('--suppress_over_fire', action='store_true', default=False,
                        help='suppress_over_fire')
    return parser


def main(args):
    misc.init_distributed_mode(args)

    print('job dir: {}'.format(os.path.dirname(os.path.realpath(__file__))))
    print("{}".format(args).replace(', ', ',\n'))

    device = torch.device("cpu")

    # fix the seed for reproducibility
    seed = args.seed + misc.get_rank()
    torch.manual_seed(seed)
    np.random.seed(seed)

    cudnn.benchmark = True

    dataset_val = build_dataset(is_train=False, args=args)
    sampler_val = torch.utils.data.SequentialSampler(dataset_val)
    os.makedirs(args.log_dir, exist_ok=True)
    args.log_dir = os.path.join(args.log_dir,
                                "{}_{}_{}_{}_{}_act{}_weightbit{}".format(args.project_name, args.model, args.dataset, args.act_layer, args.mode, args.level,args.weight_quantization_bit))
    os.makedirs(args.log_dir, exist_ok=True)

    data_loader_val = torch.utils.data.DataLoader(
        dataset_val, sampler=sampler_val,
        batch_size=args.batch_size,
        num_workers=0,
        pin_memory=args.pin_mem,
        drop_last=False
    )

    mixup_fn = None
    mixup_active = args.mixup > 0 or args.cutmix > 0. or args.cutmix_minmax is not None
    if mixup_active:
        print("Mixup is activated!")
        mixup_fn = Mixup(
            mixup_alpha=args.mixup, cutmix_alpha=args.cutmix, cutmix_minmax=args.cutmix_minmax,
            prob=args.mixup_prob, switch_prob=args.mixup_switch_prob, mode=args.mixup_mode,
            label_smoothing=args.smoothing, num_classes=args.nb_classes)

    if args.act_layer == "relu":
        activation = nn.ReLU
    elif args.act_layer == "gelu":
        activation = nn.GELU
    else:
        raise NotImplementedError

    if args.act_layer_teacher == "relu":
        activation_teacher = nn.ReLU
    elif args.act_layer_teacher == "gelu":
        activation_teacher = nn.GELU
    else:
        raise NotImplementedError

    normLayer = partial(nn.LayerNorm, eps=1e-6)
    if args.NormType == "layernorm":
        normLayer = partial(nn.LayerNorm, eps=1e-6)
    elif args.NormType == "powernorm":
        normLayer = partial(MaskPowerNorm, eps=1e-6)
    elif args.NormType == "mylayernorm":
        normLayer = partial(MyLayerNorm, eps=1e-6)
    elif args.NormType == "mybatchnorm":
        normLayer = partial(MyBatchNorm1d, eps=1e-6)
    elif args.NormType == "dyt":
        normLayer = partial(DyT)       
    elif args.NormType == "dyht":
        normLayer = partial(DyHT)       
    elif args.NormType == "dyht_relu":
        normLayer = partial(DyHT_ReLU)

    print("args.drop_path",args.drop_path)
    if "vit_small" in args.model:
            model = models_vit.__dict__[args.model](
            num_classes=args.nb_classes,
            drop_path_rate=args.drop_path,
            drop_rate = args.drop_rate,
            global_pool=args.global_pool,
            act_layer=activation,
            norm_layer=normLayer,
        )
    elif "swin_tiny_cifar" in args.model:
        model = timm.create_model("swin_cifar_patch4_window7_224",norm_layer=normLayer,act_layer=activation,pretrained=False, drop_path_rate=args.drop_path, img_size=args.input_size, num_classes=args.nb_classes)
    elif "swin_tiny_dvs" in args.model:
        model = timm.create_model("swin_dvs_patch4_window4_128",norm_layer=normLayer,act_layer=activation,pretrained=False, drop_path_rate=args.drop_path, in_chans=3, img_size=args.input_size, num_classes=args.nb_classes)
    elif "swin_tiny" in args.model:
        model = timm.create_model("swin_tiny_patch4_window7_224",norm_layer=normLayer,act_layer=activation,pretrained=False,drop_path_rate=args.drop_path)
    elif "swin_base" in args.model:
        model = timm.create_model("swin_base_patch4_window7_224",norm_layer=normLayer,act_layer=activation,pretrained=False,checkpoint_path="/data/kang_you1/swin_base_patch4_window7_224_22kto1k.pth",drop_path_rate=args.drop_path)
    else:
        model = models_vit.__dict__[args.model](
            num_classes=args.nb_classes,
            drop_path_rate=args.drop_path,
            drop_rate = args.drop_rate,
            global_pool=args.global_pool,
            act_layer=activation,
            norm_layer=normLayer,
        )
    if args.remove_softmax:
        remove_softmax(model)
    if args.NormType == "mybatchnorm" or args.NormType == "dyt" or args.NormType == "dyht" or args.NormType == "dyht_relu":
        add_bn_in_mlp(model, normLayer)


    if args.finetune and not args.eval and not (args.mode == "SNN") and not (args.mode == "QANN-QAT" and args.eval):
        if (args.dataset == "cifar10dvs" or args.dataset == "dvs128") and args.mode == "QANN_QAT":
            if not args.convEmbedding:
                model.patch_embed.proj = torch.nn.Sequential(torch.nn.Conv2d(2, 3, kernel_size=(1, 1), stride=(1, 1), bias=False), model.patch_embed.proj)        
            else:
                model.patch_embed.proj_conv = torch.nn.Sequential(torch.nn.Conv2d(2, 3, kernel_size=(1, 1), stride=(1, 1), bias=False), model.patch_embed.proj_conv) 
        checkpoint = torch.load(args.finetune, map_location='cpu',weights_only=False)

        print("Load pre-trained checkpoint from: %s !!!!!!!" % args.finetune)
        checkpoint_model = checkpoint if ".bin" in args.finetune else checkpoint['model']
        state_dict = model.state_dict()
        for k in ['head.weight', 'head.bias']:
            if k in checkpoint_model and checkpoint_model[k].shape != state_dict[k].shape:
                print(f"Removing key {k} from pretrained checkpoint")
                del checkpoint_model[k]

        # interpolate position embedding
        interpolate_pos_embed(model, checkpoint_model)

        # load pre-trained model
        msg = model.load_state_dict(checkpoint_model, strict=False)
        print(msg)

        # if args.global_pool:
        #     assert set(msg.missing_keys) == {'head.weight', 'head.bias', 'fc_norm.weight', 'fc_norm.bias'}
        # else:
        #     assert set(msg.missing_keys) == {'head.weight', 'head.bias'}

        # manually initialize fc layer
        # if not args.mode == "QANN-QAT":
        #     trunc_normal_(model.head.weight, std=2e-5)

    print("======================== ANN model ========================")
    f = open(f"{args.log_dir}/ann_model_arch.txt", "w+")
    f.write(str(model))
    f.close()
    if args.mode.count("QANN") > 0:
        myquan_replace(model, args.level, args.weight_quantization_bit, is_softmax = not args.remove_softmax)
        print("======================== QANN model =======================")
        f = open(f"qann_model_arch.txt", "w+")
        f.write(str(model))
        f.close()
        if args.prune:
            checkpoint = torch.load(args.finetune, map_location='cpu',weights_only=False)
            print("Load pre-trained checkpoint from: %s !!!!!!!" % args.finetune)
            checkpoint_model = checkpoint if ".bin" in args.finetune else checkpoint['model']
            state_dict = model.state_dict()
            for k in ['head.weight', 'head.bias']:
                if k in checkpoint_model and checkpoint_model[k].shape != state_dict[k].shape:
                    print(f"Removing key {k} from pretrained checkpoint")
                    del checkpoint_model[k]

            # interpolate position embedding
            interpolate_pos_embed(model, checkpoint_model)

            # load pre-trained model
            msg = model.load_state_dict(checkpoint_model, strict=False)
            print(msg)            
            set_init_false(model)
    elif args.mode == "SNN":
        if (args.dataset == "cifar10dvs" or args.dataset == "dvs128") and args.mode == "SNN":
            if not args.convEmbedding:
                model.patch_embed.proj = torch.nn.Sequential(torch.nn.Conv2d(2, 3, kernel_size=(1, 1), stride=(1, 1), bias=False), model.patch_embed.proj)        
            else:
                model.patch_embed.proj_conv = torch.nn.Sequential(torch.nn.Conv2d(2, 3, kernel_size=(1, 1), stride=(1, 1), bias=False), model.patch_embed.proj_conv) 
        
        myquan_replace(model, args.level, args.weight_quantization_bit, is_softmax = not args.remove_softmax)

        if len(args.finetune) > 0:
            checkpoint = torch.load(args.finetune, map_location='cpu',weights_only=False) if not args.eval else torch.load(args.resume,
                                                                                                    map_location='cpu',weights_only=False)
            print("Load pre-trained checkpoint from: %s" % args.finetune)
            checkpoint_model = checkpoint['model']
            state_dict = model.state_dict()
            for k in ['head.weight', 'head.bias']:
                if k in checkpoint_model and checkpoint_model[k].shape != state_dict[k].shape:
                    print(f"Removing key {k} from pretrained checkpoint")
                    del checkpoint_model[k]

            # interpolate position embedding
            interpolate_pos_embed(model, checkpoint_model)

            # load pre-trained model
            msg = model.load_state_dict(checkpoint_model, strict=True)
            print(msg)
        print("======================== QANN model =======================")
        f = open(f"qann_model_arch.txt", "w+")
        f.write(str(model))
        f.close()
        model_teacher = deepcopy(model)

        # if args.global_pool:
        #     assert set(msg.missing_keys) == {'head.weight', 'head.bias', 'fc_norm.weight', 'fc_norm.bias'}
        # else:
        #     assert set(msg.missing_keys) == {'head.weight', 'head.bias'}

        # manually initialize fc layer
        # trunc_normal_(model.head.weight, std=2e-5)
        model = SNNWrapperINT(ann_model=model, cfg=args, time_step=args.time_step, \
                           Encoding_type=args.encoding_type, level=args.level, neuron_type=args.neuron_type, \
                           model_name=args.model, is_softmax = not args.remove_softmax, suppress_over_fire = args.suppress_over_fire, \
                           record_inout=args.record_inout,learnable=args.hybrid_training,record_dir=args.log_dir+f"/output_bin_snn_{args.model}_w{args.weight_quantization_bit}_a{int(torch.log2(torch.tensor(args.level)))}_T{args.time_step}/")

        for name,child in model.named_modules():
            if isinstance(child, ST_BIFNeuron_SS):
                child.name = name
        
        print("======================== SNN model =======================")
        f = open(f"snn_model_arch.txt", "w+")
        f.write(str(model))
        f.close()

    if (args.dataset == "cifar10dvs" or args.dataset == "dvs128") and args.mode == "ANN":
        if not args.convEmbedding:
            model.patch_embed.proj = torch.nn.Sequential(torch.nn.Conv2d(2, 3, kernel_size=(1, 1), stride=(1, 1), bias=False), model.patch_embed.proj)        
        else:
            model.patch_embed.proj_conv = torch.nn.Sequential(torch.nn.Conv2d(2, 3, kernel_size=(1, 1), stride=(1, 1), bias=False), model.patch_embed.proj_conv) 

    model.to(device)
    model_teacher.to(device)

    model_without_ddp = model if args.mode != "SNN" else model.model
    n_parameters = sum(p.numel() for p in model.parameters() if p.requires_grad)

    # print("Model = %s" % str(model_without_ddp))
    print('number of params (M): %.2f' % (n_parameters / 1.e6))

    eff_batch_size = args.batch_size * args.accum_iter * misc.get_world_size()

    if args.lr is None:  # only base_lr is specified
        args.lr = args.blr * eff_batch_size / 256

    print("base lr: %.2e" % (args.lr * 256 / eff_batch_size))
    print("actual lr: %.2e" % args.lr)

    print("accumulate grad iterations: %d" % args.accum_iter)
    print("effective batch size: %d" % eff_batch_size)

    
    if args.eval:
        test_stats = evaluate(data_loader_val, model, device, "ANN", args)
        print(f"Accuracy of the network on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")
        exit(0)

    print(f"Start training for {args.epochs} epochs")
    start_time = time.time()
    max_accuracy = 0.0

    if args.dataset == "cifar10dvs" or args.dataset == "dvs128":
        train_snn_aug = transforms.Compose([
                        transforms.Resize(size=(args.input_size, args.input_size)),
                        transforms.RandomHorizontalFlip(p=0.5)
                        ])
        train_trivalaug = SNNAugmentWide()    
        test_snn_aug = transforms.Compose([
                        transforms.Resize(size=(args.input_size, args.input_size)),
                        ])
    else:
        train_snn_aug = None
        train_trivalaug = None
        test_snn_aug = None

    if not args.energy:
        # print("args.time_step",args.time_step)
        # test_stats = evaluate(data_loader_val, model_teacher, device, test_snn_aug, "ANN",  args)
        # print(f"Accuracy of the teacher network on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")

        test_stats = evaluateProfile(data_loader_val, model, device, test_snn_aug, args.mode,  args)
        print(f"Accuracy of the network on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")

        for t in range(args.time_step):
            print(f"Accuracy of the network on the {len(dataset_val)} test images at time step {t + 1}: {test_stats['acc@{}'.format(t + 1)]:.1f}%")
            # wandb.log({'acc1@{}_curve'.format(t + 1): test_stats['acc@{}'.format(t + 1)]}, step=epoch_1000x)
    
        exit(0)
    
    if args.energy:
        from energy_consumption_calculation import get_model_complexity_info
        if len(args.snn_model_path) > 0:
            checkpoint = torch.load(args.snn_model_path, map_location='cpu',weights_only=False)
            print("Load SNN checkpoint from: %s" % args.snn_model_path)
            checkpoint_model = checkpoint['model']
            new_state_dict = {}
            for k,v in checkpoint_model.items():
                new_state_dict["module.model."+k] = v
            msg = model.load_state_dict(new_state_dict, strict=True)
            print(msg)
            # msg = model.load_state_dict(checkpoint_model, strict=True)

        # test_stats = evaluate(data_loader_val, model, device,args.mode, args)
        # print(f"Accuracy of the network on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")

        ts1 = time.time()
        Nops, Nparams = get_model_complexity_info(model_teacher, (3, 224, 224), data_loader_val,ost = open(f"{args.log_dir}/energy_info.txt","w+"), as_strings=True, print_per_layer_stat=True, verbose=True, syops_units='Mac', param_units=' ', output_precision=3)
        print("Nops: ", Nops)
        print("Nparams: ", Nparams)
        t_cost = (time.time() - ts1) / 60
        print(f"Time cost: {t_cost} min")
        exit(0)
    # if args.mode == "SNN" and misc.is_main_process():
    #     for k, v in test_stats.items():
    #         print(k, v)
    #     with open(os.path.join(args.output_dir, "results.json"), 'w') as f:
    #         json.dump(test_stats, f)
    #     exit(0)
    # print(f"begin to align QANN and SNN!!!!!")
    # Align_QANN_SNN(model, model_teacher, criterion, data_loader_train,
    #         optimizer, device, 0, loss_scaler,
    #         args.clip_grad, mixup_fn,
    #         log_writer=log_writer,
    #         args=args)
    
    # test_stats = evaluate(data_loader_val, model, device, args.mode, args)
    # print(f"Accuracy of the spiking neural network after alignment on the {len(dataset_val)} test images: {test_stats['acc1']:.1f}%")


if __name__ == '__main__':
    args = get_args_parser()
    args = args.parse_args()
    if args.output_dir:
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
        args.output_dir = os.path.join(args.output_dir,
                                       "{}_{}_{}_{}_{}_act{}_weightbit{}".format(args.project_name, args.model, args.dataset, args.act_layer, args.mode, args.level,args.weight_quantization_bit))
        Path(args.output_dir).mkdir(parents=True, exist_ok=True)
        print(args.output_dir)
    main(args)

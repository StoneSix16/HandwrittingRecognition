#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include "custom_fuse.h"
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <chrono>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
static constexpr int BM = 64;
static constexpr int BN = 64;
static constexpr int BK = 64;

std::vector<torch::Tensor> custom_linear_fuse_int(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const c10::optional<torch::Tensor>& bias_opt,
    torch::Tensor q,
    torch::Tensor acc_q,
    const double v_th,
    const int64_t pos_max,
    const int64_t neg_min
) {
    // auto t_start = std::chrono::steady_clock::now();
    // 1) Ensure contiguous
    // auto in_contig = input.is_contiguous()  ? input  : input.contiguous();
    // auto wt_contig = weight.is_contiguous() ? weight : weight.contiguous();
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("SpMM_yk contiguous: %.6f ms\n",
    //    diff.count()*1000);

    // 2) Dimensions
    // printf("=================1==================\n");
    int64_t M = input.size(0);
    int64_t K = input.size(1);
    int64_t N = weight.size(1);

    TORCH_CHECK(weight.size(0) == K,
        "custom_linear: weight.size(0) must match input.size(1)");

    // 3) Allocate and init output
    // auto t_start = std::chrono::steady_clock::now();
    auto output1 = torch::empty({M, N}, weight.options());
    float* C = output1.data_ptr<float>();

    auto output2 = torch::empty({M, N}, input.options().dtype(torch::kInt8));
    int8_t* C2 = output2.data_ptr<int8_t>();

    bool q_cont = q.is_contiguous();
    bool acc_cont = acc_q.is_contiguous();

    torch::Tensor q_c     = q_cont     ? q     : q.contiguous();
    torch::Tensor acc_c   = acc_cont   ? acc_q : acc_q.contiguous();    
    // printf("=================2==================\n");

    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("SpMM_yk C allocation: %.6f ms\n",
    //    diff.count()*1000);

    // t_start = std::chrono::steady_clock::now();
    if (bias_opt.has_value() && bias_opt->defined()) {
        auto bias = bias_opt.value();
        TORCH_CHECK(bias.dim() == 1 && bias.size(0) == N,
            "custom_linear: bias must be 1D of length N");
        const float* bias_ptr = bias.data_ptr<float>();

        // init each row with bias
        #pragma omp parallel for num_threads(64) schedule(static)
        for (int64_t i = 0; i < M; ++i) {
            memcpy(C + i * N, bias_ptr, N * sizeof(float));
        }
    } 
    else {
        // zero init
        #pragma omp parallel for num_threads(64) schedule(static)
        for (int i = 0; i < M; ++i) {
            float* row = C + (size_t)i * N;
            memset(row, 0, N * sizeof(float));

            int8_t* row1 = C2 + (size_t)i * N;
            memset(row1, 0, N * sizeof(int8_t));
        }
        // std::fill_n(C, M * N, 0.0f);
    }
    // printf("=================3==================\n");
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("SpMM_yk bias calculation: %.6f ms\n",
    //    diff.count()*1000);

    // t_start = std::chrono::steady_clock::now();
    MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary_fusion(input.data_ptr<int8_t>(), weight.data_ptr<float>(), C, M, K, N, 
                                                            C2, q_c.data_ptr<float>(), acc_c.data_ptr<float>(), v_th, pos_max, neg_min);
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("SpMM_yk matrix multiplication: %.6f ms\n",
    //    diff.count()*1000);
    // printf("=================End==================\n");

    return {output2, q_c, acc_c};
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_linear_fuse_int(Tensor input, Tensor weight, Tensor? bias, Tensor q, Tensor acc_q, float v_th, int pos_max, int neg_min) -> Tensor[]");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_linear_fuse_int", TORCH_FN(custom_linear_fuse_int));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_linear_fuse_int", &custom_linear_fuse_int,
          "customized Linear fuse ST-BIF neuron matching aten::linear",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("q"),
          py::arg("acc_q"),
          py::arg("v_th"),
          py::arg("pos_max"),
          py::arg("neg_min")
    );
}



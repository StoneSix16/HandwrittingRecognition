#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include "neuron.h"
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <chrono>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
void custom_st_bif_in_scale(
    torch::Tensor input,
    torch::Tensor q,
    torch::Tensor acc_q,
    const double scale,
    const double v_th,
    const int64_t pos_max,
    const int64_t neg_min,
    const int64_t time_step) 
{
    // 简单检查（CPU + dtype）
    // TORCH_CHECK(input.device().is_cpu(), "input must be CPU tensor");
    // TORCH_CHECK(q.device().is_cpu(), "q must be CPU tensor");
    // TORCH_CHECK(acc_q.device().is_cpu(), "acc_q must be CPU tensor");

    // TORCH_CHECK(input.dtype() == torch::kFloat32, "input must be float32");
    // TORCH_CHECK(q.dtype() == torch::kFloat32, "q must be float32");
    // TORCH_CHECK(acc_q.dtype() == torch::kFloat32, "acc_q must be float32");

    int64_t N = input.numel();
    // Work on contiguous memory. If original is contiguous, operate directly.
    // Otherwise make a contiguous temp, run kernel, then copy back so Python sees changes.
    // bool input_cont = input.is_contiguous();
    // bool q_cont = q.is_contiguous();
    // bool acc_cont = acc_q.is_contiguous();
    // // printf("input_cont=%d, q_cont=%d, acc_cont=%d\n",input_cont,q_cont,acc_cont);

    // torch::Tensor input_c = input_cont ? input : input.contiguous();
    // torch::Tensor q_c     = q_cont     ? q     : q.contiguous();
    // torch::Tensor acc_c   = acc_cont   ? acc_q : acc_q.contiguous();

    // call your C kernel (ensure types match)
    // auto t_start = std::chrono::steady_clock::now();
    ST_BIF_forward_scale_in_scale(
        input.data_ptr<float>(),
        q.data_ptr<float>(),
        acc_q.data_ptr<float>(),
        static_cast<int>(N),
        static_cast<float>(scale),
        static_cast<float>(v_th),
        pos_max,
        neg_min
    );
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("yk checking1: %.6f ms\n",
    //    diff.count()*1000);

    // if any temp was created, copy back to original tensors so caller sees in-place update
    // t_start = std::chrono::steady_clock::now();
    // if (!input_cont) input.copy_(input_c);
    // if (!q_cont)     q.copy_(q_c);
    // if (!acc_cont)   acc_q.copy_(acc_c);
    // return { input, q, acc_q };
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_st_bif_in_scale(Tensor input, Tensor q, Tensor acc_q, float scale, float v_th, int pos_max, int neg_min, int time_step) -> ()");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_st_bif_in_scale", TORCH_FN(custom_st_bif_in_scale));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_st_bif_in_scale",
          &custom_st_bif_in_scale,
          "custom_st_bif_in_scale(input, q, acc_q, scale, v_th, pos_max, neg_min, time_step) -> (input, q, acc_q)",
          py::arg("input"),
          py::arg("q"),
          py::arg("acc_q"),
          py::arg("scale"),
          py::arg("v_th"),
          py::arg("pos_max"),
          py::arg("neg_min"),
          py::arg("time_step") = 0
    );
}

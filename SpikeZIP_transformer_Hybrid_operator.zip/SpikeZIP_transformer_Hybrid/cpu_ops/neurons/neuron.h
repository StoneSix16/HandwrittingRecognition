#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>
#include <cmath>

void ST_BIF_forward(float* x_t, float* V_t_1, int8_t* T_t_1, int N, float v_th, int T_max, int T_min);

void ST_BIF_forward_AVX_512(float* x_t, float* V_t_1, int8_t* T_t_1, int N, float v_th, int T_max, int T_min);

void ST_BIF_forward_scale(float* x_t, float* V_t_1, float* T_t_1, int N, float v_th, int T_max, int T_min);

void ST_BIF_forward_scale_int(float* x_t, float* V_t_1, int8_t* T_t_1, int8_t* output, int N, float v_th, int T_max, int T_min);

void ST_BIF_forward_scale_in_scale(float* x_t, float* V_t_1, float* T_t_1, int N, float scale, float v_th, int T_max, int T_min);

void ST_BIF_forward_scale_in_scale_int(float* x_t, float* V_t_1, int8_t* T_t_1, int8_t* output, int N, float scale, float v_th, int T_max, int T_min);
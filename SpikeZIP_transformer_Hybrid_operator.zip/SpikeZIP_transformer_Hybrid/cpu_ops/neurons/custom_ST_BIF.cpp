#include "neuron.h"
// class ST_BIFNodeATGF_SS(torch.autograd.Function):
//     @staticmethod
    // def forward(ctx, x_t: torch.Tensor, V_t_1: torch.Tensor, T_t_1: torch.Tensor, v_th: torch.Tensor, T_max: torch.Tensor, T_min: torch.Tensor, t: torch.Tensor):

    //     spike = x_t * 0.0
    //     H_t = V_t_1 + x_t
    //     spike_condition = (H_t >= v_th) & (T_t_1-T_max < 0)
    //     neg_spike_condition = (H_t < 0) & (T_t_1-T_min > 0)

    //     spike = torch.where(spike_condition, torch.ones_like(H_t),
    //                                   torch.where(neg_spike_condition, -torch.ones_like(H_t),
    //                                               torch.zeros_like(H_t)))

    //     V_t = H_t - v_th * spike
    //     T_t = T_t_1 + spike

    //     spike = spike * v_th

    //     return spike, V_t, T_t


void ST_BIF_forward(float* x_t, float* V_t_1, int8_t* T_t_1, int N, float v_th, int T_max, int T_min){
    
    // const size_t N = (size_t)rows * (size_t)cols;
    if (N == 0) return;
    const int num_threads = 64;
    const int chunk = N/(num_threads*8);
    // printf("chunk=%d,num_threads=%d\n", chunk, num_threads);

    const size_t simd_width = 8;
    const size_t vec_end = (N / simd_width) * simd_width;

    __m256 vth_ps = _mm256_set1_ps(v_th);
    __m256 zero_ps = _mm256_setzero_ps();

    __m256 one_ps = _mm256_set1_ps(1.0f);
    __m256 negone_ps = _mm256_set1_ps(-1.0f);
    __m256 vth_times_one = vth_ps; // same

    __m256i ones_epi32 = _mm256_set1_epi32(1);
    __m256i Tmax_epi32 = _mm256_set1_epi32(T_max);
    __m256i Tmin_epi32 = _mm256_set1_epi32(T_min);
    
    #pragma omp parallel for num_threads(64) schedule(static, chunk)
    for (size_t i = 0; i < vec_end; i += simd_width){
        // Temporaries for scalar fallback of integer updates
        alignas(32) int32_t tmp_t32[8];
        alignas(32) int32_t tmp_spike32[8];

        __m256 x_vec = _mm256_loadu_ps(x_t + i);         // original x_t
        __m256 Vprev = _mm256_loadu_ps(V_t_1 + i);      // previous V

        // H_t = V_t_1 + x_t
        __m256 H = _mm256_add_ps(Vprev, x_vec);

        // load Tprev int8 -> extend to int32
        // load 8 bytes into lower 64bits of __m128i        
        __m128i tbytes = _mm_loadl_epi64((const __m128i*)(T_t_1 + i)); // loads 8 int8s
        __m256i t32 = _mm256_cvtepi8_epi32(tbytes); // 8 x int32

        // (H_t >= v_th)
        __m256 cmp_ge = _mm256_cmp_ps(H, vth_ps, _CMP_GE_OQ); // mask ps
        __m256i cmp_ge_i = _mm256_castps_si256(cmp_ge); // cast to int mask

        // (H_t < 0)
        __m256 cmp_lt0 = _mm256_cmp_ps(H, zero_ps, _CMP_LT_OQ);
        __m256i cmp_lt0_i = _mm256_castps_si256(cmp_lt0);

        // (T_t_1-T_max < 0)
        __m256i t_lt_tmax_i = _mm256_cmpgt_epi32(Tmax_epi32, t32);

        // (T_t_1-T_min > 0)
        __m256i t_gt_tmin_i = _mm256_cmpgt_epi32(t32, Tmin_epi32);

        // pos_mask = (H >= v_th) & (Tprev < T_max)
        __m256i pos_mask_i = _mm256_and_si256(cmp_ge_i, t_lt_tmax_i); // true -> 0xFFFFFFFF

        // neg_mask = (H < 0) & (Tprev > T_min)
        __m256i neg_mask_i = _mm256_and_si256(cmp_lt0_i, t_gt_tmin_i); // true -> 0xFFFFFFFF

        // reduce masks to 0/1 per lane by AND with 1
        __m256i pos01 = _mm256_and_si256(pos_mask_i, ones_epi32); // 1 if true else 0
        __m256i neg01 = _mm256_and_si256(neg_mask_i, ones_epi32);

        // spike_int32 = pos01 - neg01  -> values in {-1,0,1}
        __m256i spike_i32 = _mm256_sub_epi32(pos01, neg01);

        // convert spike to float
        __m256 spike_f = _mm256_cvtepi32_ps(spike_i32); // -1,0,1

        // V_t = H_t - v_th * spike
        __m256 vth_mul_spike = _mm256_mul_ps(vth_ps, spike_f);
        __m256 Vnew = _mm256_sub_ps(H, vth_mul_spike);

        // store Vnew in-place to V_t_1 buffer
        _mm256_storeu_ps(V_t_1 + i, Vnew);

        // store spike_out into x_t (overwrite input)
        _mm256_storeu_ps(x_t + i, vth_mul_spike);

        // update T: Tnew = Tprev + spike (no clamping)
        _mm256_storeu_si256((__m256i*)tmp_t32, t32);         // store previous T as int32
        _mm256_storeu_si256((__m256i*)tmp_spike32, spike_i32); // store spike int32

        for (int k = 0; k < 8; ++k) {
            int32_t tnew = tmp_t32[k] + tmp_spike32[k];
            // **不做任何范围限制**，直接转为 int8_t（实现定义；常见平台为截断低8位）
            T_t_1[i + k] = (int8_t)tnew;
        }
    }
    // tail scalar loop
    for (size_t idx = vec_end; idx < N; ++idx) {
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        int8_t Tp = T_t_1[idx];
        float H = Vp + x;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        int8_t tnew = Tp + spike_i;
        x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        T_t_1[idx] = tnew; // 直接转换，不作 clamp
    }     

}

void ST_BIF_forward_AVX_512(float* x_t, float* V_t_1, int8_t* T_t_1, int N, float v_th, int T_max, int T_min)
{
    if (N == 0) return;

    // AVX-512 processes 16 floats per vector
    const size_t simd_width = 16;
    const size_t vec_end = (N / simd_width) * simd_width;

    // Broadcasted constants
    __m512 vth512 = _mm512_set1_ps(v_th);
    __m512 zero512 = _mm512_setzero_ps();

    __m512i ones_i32_512 = _mm512_set1_epi32(1);
    __m512i Tmax_i32 = _mm512_set1_epi32(T_max);
    __m512i Tmin_i32 = _mm512_set1_epi32(T_min);

    const int num_threads = 64;
    // choose chunk size per OpenMP schedule; avoid zero
    int chunk = 1;
    if (num_threads > 0) {
        size_t approx_chunk = N / ( (size_t)num_threads * simd_width );
        if (approx_chunk > 0) chunk = static_cast<int>(approx_chunk);
    }

    #pragma omp parallel for num_threads(num_threads) schedule(static, chunk)
    for (size_t i = 0; i < vec_end; i += simd_width) {
        // temporaries for scalar fallback of integer updates (16 lanes)
        alignas(64) int32_t tmp_t32[16];
        alignas(64) int32_t tmp_spike32[16];

        // load 16 floats
        __m512 x_vec = _mm512_loadu_ps(x_t + i);
        __m512 Vprev = _mm512_loadu_ps(V_t_1 + i);

        // H = Vprev + x
        __m512 H = _mm512_add_ps(Vprev, x_vec);

        // load 16 int8s into 128-bit register then extend to 16 x i32
        __m128i tbytes = _mm_loadu_si128((const __m128i*)(T_t_1 + i)); // 16 bytes
        __m512i t32 = _mm512_cvtepi8_epi32(tbytes); // converts 16 int8 -> 16 int32

        // comparisons on floats -> masks (per-lane)
        __mmask16 mask_ge = _mm512_cmp_ps_mask(H, vth512, _CMP_GE_OQ);  // H >= v_th
        __mmask16 mask_lt0 = _mm512_cmp_ps_mask(H, zero512, _CMP_LT_OQ); // H < 0

        // comparisons on ints -> masks
        __mmask16 mask_t_lt_tmax = _mm512_cmpgt_epi32_mask(Tmax_i32, t32); // Tmax > t -> t < Tmax
        __mmask16 mask_t_gt_tmin = _mm512_cmpgt_epi32_mask(t32, Tmin_i32); // t > Tmin

        // combine masks
        __mmask16 pos_mask = mask_ge & mask_t_lt_tmax;
        __mmask16 neg_mask = mask_lt0 & mask_t_gt_tmin;

        // Convert mask -> 0/1 int32 vector
        __m512i pos01 = _mm512_maskz_mov_epi32(pos_mask, ones_i32_512); // ones where pos_mask, else 0
        __m512i neg01 = _mm512_maskz_mov_epi32(neg_mask, ones_i32_512);

        // spike_i32 = pos01 - neg01
        __m512i spike_i32 = _mm512_sub_epi32(pos01, neg01); // values in {-1,0,1}

        // convert spike to float
        __m512 spike_f = _mm512_cvtepi32_ps(spike_i32);

        // Vnew = H - v_th * spike
        __m512 vth_mul_spike = _mm512_mul_ps(vth512, spike_f);
        __m512 Vnew = _mm512_sub_ps(H, vth_mul_spike);

        // store Vnew and spike_out (into x_t)
        _mm512_storeu_ps(V_t_1 + i, Vnew);
        _mm512_storeu_ps(x_t + i, vth_mul_spike);

        // compute tnew32 = t32 + spike_i32
        __m512i tnew32 = _mm512_add_epi32(t32, spike_i32);

        // store t32 and spike for scalar truncation to int8
        _mm512_storeu_si512((void*)tmp_t32, tnew32);
        _mm512_storeu_si512((void*)tmp_spike32, spike_i32); // not needed but keep for debug parity

        // write back int8 with defined truncation behavior (cast in C)
        for (int k = 0; k < 16; ++k) {
            int32_t tval = tmp_t32[k];
            T_t_1[i + k] = (int8_t)tval; // implementation-defined truncation (low 8 bits)
        }
    }

    // tail scalar loop for elements not divisible by 16
    for (size_t idx = vec_end; idx < N; ++idx) {
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        int8_t Tp = T_t_1[idx];
        float H = Vp + x;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        int8_t tnew = (int8_t)( (int32_t)Tp + (int32_t)spike_i ); // truncation as in vector path
        x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        T_t_1[idx] = tnew;
    }
}


void ST_BIF_forward_scale(float* x_t, float* V_t_1, float* T_t_1, int N, float v_th, int T_max, int T_min)
{
    if (N == 0) return;

    // AVX-512 processes 16 floats per vector
    const size_t simd_width = 16;
    const size_t vec_end = (N / simd_width) * simd_width;

    // Broadcasted constants
    __m512 vth512 = _mm512_set1_ps(v_th);
    __m512 zero512 = _mm512_setzero_ps();

    __m512i ones_i32_512 = _mm512_set1_epi32(1);
    __m512 Tmax_f32 = _mm512_set1_ps(T_max * v_th);
    __m512 Tmin_f32 = _mm512_set1_ps(T_min * v_th);

    const int num_threads = 64;
    // choose chunk size per OpenMP schedule; avoid zero
    int chunk = 1;
    if (num_threads > 0) {
        size_t approx_chunk = N / ( (size_t)num_threads * simd_width );
        if (approx_chunk > 0) chunk = static_cast<int>(approx_chunk);
    }

    #pragma omp parallel for num_threads(num_threads) schedule(static, chunk)
    for (size_t i = 0; i < vec_end; i += simd_width) {
        // load 16 floats
        __m512 x_vec = _mm512_loadu_ps(x_t + i);
        __m512 Vprev = _mm512_loadu_ps(V_t_1 + i);

        // H = Vprev + x
        __m512 H = _mm512_add_ps(Vprev, x_vec);

        // load 32-bit float T_t
        __m512 t32 = _mm512_loadu_ps(T_t_1 + i);

        // comparisons on floats -> masks (per-lane)
        __mmask16 mask_ge = _mm512_cmp_ps_mask(H, vth512, _CMP_GE_OQ);  // H >= v_th
        __mmask16 mask_lt0 = _mm512_cmp_ps_mask(H, zero512, _CMP_LT_OQ); // H < 0

        // comparisons on ints -> masks
        __mmask16 mask_t_lt_tmax = _mm512_cmp_ps_mask(t32, Tmax_f32, _CMP_LT_OQ); // Tmax > t -> t < Tmax
        __mmask16 mask_t_gt_tmin = _mm512_cmp_ps_mask(Tmin_f32, t32, _CMP_LT_OQ); // t > Tmin

        // combine masks
        __mmask16 pos_mask = mask_ge & mask_t_lt_tmax;
        __mmask16 neg_mask = mask_lt0 & mask_t_gt_tmin;

        // Convert mask -> 0/1 int32 vector
        __m512i pos01 = _mm512_maskz_mov_epi32(pos_mask, ones_i32_512); // ones where pos_mask, else 0
        __m512i neg01 = _mm512_maskz_mov_epi32(neg_mask, ones_i32_512);

        // spike_i32 = pos01 - neg01
        __m512i spike_i32 = _mm512_sub_epi32(pos01, neg01); // values in {-1,0,1}

        // convert spike to float
        __m512 spike_f = _mm512_cvtepi32_ps(spike_i32);

        // Vnew = H - v_th * spike
        __m512 vth_mul_spike = _mm512_mul_ps(vth512, spike_f);
        __m512 Vnew = _mm512_sub_ps(H, vth_mul_spike);

        // store Vnew and spike_out (into x_t)
        _mm512_storeu_ps(V_t_1 + i, Vnew);
        _mm512_storeu_ps(x_t + i, vth_mul_spike);

        // compute tnew32 = t32 + vth_mul_spike
        __m512 tnew32 = _mm512_add_ps(t32, vth_mul_spike);

        // store t32 and spike for scalar truncation to int8
        _mm512_storeu_ps(T_t_1 + i, tnew32);
    }

    // tail scalar loop for elements not divisible by 16
    for (size_t idx = vec_end; idx < N; ++idx) {
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        float Tp = T_t_1[idx];
        float H = Vp + x;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max*v_th)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min*v_th)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        float tnew = Tp + spike_out; // truncation as in vector path
        x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        T_t_1[idx] = tnew;
    }
}

void ST_BIF_forward_scale_in_scale(float* x_t, float* V_t_1, float* T_t_1, int N, float scale, float v_th, int T_max, int T_min)
{
    if (N == 0) return;

    // AVX-512 processes 16 floats per vector
    const size_t simd_width = 16;
    const size_t vec_end = (N / simd_width) * simd_width;

    // Broadcasted constants
    __m512 vth512 = _mm512_set1_ps(v_th);
    __m512 scale512 = _mm512_set1_ps(scale);
    __m512 zero512 = _mm512_setzero_ps();

    __m512i ones_i32_512 = _mm512_set1_epi32(1);
    __m512 Tmax_f32 = _mm512_set1_ps(T_max * v_th);
    __m512 Tmin_f32 = _mm512_set1_ps(T_min * v_th);

    const int num_threads = 64;
    // choose chunk size per OpenMP schedule; avoid zero
    int chunk = 1;
    if (num_threads > 0) {
        size_t approx_chunk = N / ( (size_t)num_threads * simd_width );
        if (approx_chunk > 0) chunk = static_cast<int>(approx_chunk);
    }

    #pragma omp parallel for num_threads(num_threads) schedule(static, chunk)
    for (size_t i = 0; i < vec_end; i += simd_width) {
        // load 16 floats
        __m512 x_vec = _mm512_loadu_ps(x_t + i);
        __m512 Vprev = _mm512_loadu_ps(V_t_1 + i);

        // H = Vprev + x
        __m512 H = _mm512_add_ps(Vprev, _mm512_mul_ps(x_vec, scale512));

        // load 32-bit float T_t
        __m512 t32 = _mm512_loadu_ps(T_t_1 + i);

        // comparisons on floats -> masks (per-lane)
        __mmask16 mask_ge = _mm512_cmp_ps_mask(H, vth512, _CMP_GE_OQ);  // H >= v_th
        __mmask16 mask_lt0 = _mm512_cmp_ps_mask(H, zero512, _CMP_LT_OQ); // H < 0

        // comparisons on ints -> masks
        __mmask16 mask_t_lt_tmax = _mm512_cmp_ps_mask(t32, Tmax_f32, _CMP_LT_OQ); // Tmax > t -> t < Tmax
        __mmask16 mask_t_gt_tmin = _mm512_cmp_ps_mask(Tmin_f32, t32, _CMP_LT_OQ); // t > Tmin

        // combine masks
        __mmask16 pos_mask = mask_ge & mask_t_lt_tmax;
        __mmask16 neg_mask = mask_lt0 & mask_t_gt_tmin;

        // Convert mask -> 0/1 int32 vector
        __m512i pos01 = _mm512_maskz_mov_epi32(pos_mask, ones_i32_512); // ones where pos_mask, else 0
        __m512i neg01 = _mm512_maskz_mov_epi32(neg_mask, ones_i32_512);

        // spike_i32 = pos01 - neg01
        __m512i spike_i32 = _mm512_sub_epi32(pos01, neg01); // values in {-1,0,1}

        // convert spike to float
        __m512 spike_f = _mm512_cvtepi32_ps(spike_i32);

        // Vnew = H - v_th * spike
        __m512 vth_mul_spike = _mm512_mul_ps(vth512, spike_f);
        __m512 Vnew = _mm512_sub_ps(H, vth_mul_spike);

        // store Vnew and spike_out (into x_t)
        _mm512_storeu_ps(V_t_1 + i, Vnew);
        _mm512_storeu_ps(x_t + i, vth_mul_spike);

        // compute tnew32 = t32 + vth_mul_spike
        __m512 tnew32 = _mm512_add_ps(t32, vth_mul_spike);

        // store t32 and spike for scalar truncation to int8
        _mm512_storeu_ps(T_t_1 + i, tnew32);
    }

    // tail scalar loop for elements not divisible by 16
    for (size_t idx = vec_end; idx < N; ++idx) {
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        float Tp = T_t_1[idx];
        float H = Vp + x * scale;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max*v_th)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min*v_th)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        float tnew = Tp + spike_out; // truncation as in vector path
        x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        T_t_1[idx] = tnew;
    }
}

void ST_BIF_forward_scale_int(float* x_t, float* V_t_1, int8_t* T_t_1, int8_t* output, int N, float v_th, int T_max, int T_min)
{
    if (N == 0) return;

    // AVX-512 processes 16 floats per vector
    const size_t simd_width = 16;
    const size_t vec_end = (N / simd_width) * simd_width;

    // Broadcasted constants
    __m512 vth512 = _mm512_set1_ps(v_th);
    __m512 zero512 = _mm512_setzero_ps();

    __m512i ones_i32_512 = _mm512_set1_epi32(1);
    __m512 Tmax_f32 = _mm512_set1_ps(T_max);
    __m512 Tmin_f32 = _mm512_set1_ps(T_min);

    const int num_threads = 64;
    // choose chunk size per OpenMP schedule; avoid zero
    int chunk = 1;
    if (num_threads > 0) {
        size_t approx_chunk = N / ( (size_t)num_threads * simd_width );
        if (approx_chunk > 0) chunk = static_cast<int>(approx_chunk);
    }

    #pragma omp parallel for num_threads(num_threads) schedule(static, chunk)
    for (size_t i = 0; i < vec_end; i += simd_width) {
        alignas(64) int32_t tmp_spike32[16];
        // load 16 floats
        __m512 x_vec = _mm512_loadu_ps(x_t + i);
        __m512 Vprev = _mm512_loadu_ps(V_t_1 + i);

        // 载入 16 个 int8 的 T
        __m128i t8raw     = _mm_loadu_si128((const __m128i*)(T_t_1 + i));  // 128 bits = 16×int8
        __m512i t32i      = _mm512_cvtepi8_epi32(t8raw);                  // 16×int8 -> 16×int32
        __m512  t32       = _mm512_cvtepi32_ps(t32i);                     // 16×int32 -> 16×float

        // H = Vprev + x
        __m512 H = _mm512_add_ps(Vprev, x_vec);

        // comparisons on floats -> masks (per-lane)
        __mmask16 mask_ge = _mm512_cmp_ps_mask(H, vth512, _CMP_GE_OQ);  // H >= v_th
        __mmask16 mask_lt0 = _mm512_cmp_ps_mask(H, zero512, _CMP_LT_OQ); // H < 0

        // comparisons on ints -> masks
        __mmask16 mask_t_lt_tmax = _mm512_cmp_ps_mask(t32, Tmax_f32, _CMP_LT_OQ); // Tmax > t -> t < Tmax
        __mmask16 mask_t_gt_tmin = _mm512_cmp_ps_mask(Tmin_f32, t32, _CMP_LT_OQ); // t > Tmin

        // combine masks
        __mmask16 pos_mask = mask_ge & mask_t_lt_tmax;
        __mmask16 neg_mask = mask_lt0 & mask_t_gt_tmin;

        // Convert mask -> 0/1 int32 vector
        __m512i pos01 = _mm512_maskz_mov_epi32(pos_mask, ones_i32_512); // ones where pos_mask, else 0
        __m512i neg01 = _mm512_maskz_mov_epi32(neg_mask, ones_i32_512);

        // spike_i32 = pos01 - neg01
        __m512i spike_i32 = _mm512_sub_epi32(pos01, neg01); // values in {-1,0,1}

        // convert spike to float
        __m512 spike_f = _mm512_cvtepi32_ps(spike_i32);

        // Vnew = H - v_th * spike
        __m512 vth_mul_spike = _mm512_mul_ps(vth512, spike_f);
        __m512 Vnew = _mm512_sub_ps(H, vth_mul_spike);

        // store Vnew and spike_out (into x_t)
        _mm512_storeu_ps(V_t_1 + i, Vnew);
        _mm512_storeu_si512((void*)tmp_spike32, spike_i32);

        for (int k = 0; k < 16; ++k) {
            int32_t tspike = tmp_spike32[k];
            output[i + k] = (int8_t)tspike; // implementation-defined truncation (low 8 bits)
        }
        // tnew = t32 + (v_th * spike)
        __m512 tnew_f = _mm512_add_ps(t32, spike_f);

        // 转回 int32
        __m512i tnew_i32 = _mm512_cvtps_epi32(tnew_f);   // float→int32 (四舍五入)
        // 如果想采用截断或向零舍入，可用 _mm512_cvttps_epi32()

        // 饱和到 int8
        __m128i tnew_i8 = _mm512_cvtepi32_epi8(tnew_i32); // 16×int32 -> 16×int8 (饱和)

        // 存回 T_t_1
        _mm_storeu_si128((__m128i*)(T_t_1 + i), tnew_i8);
    }

    // tail scalar loop for elements not divisible by 16
    for (size_t idx = vec_end; idx < N; ++idx) {
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        int8_t prevT_8 = T_t_1[idx];
        float Tp = (float)prevT_8;
        float H = Vp + x;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max*v_th)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min*v_th)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        float tnew = Tp + spike_i; // truncation as in vector path
        // x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        int t_s32 = static_cast<int>(std::lrintf(tnew)); 
        T_t_1[idx] = static_cast<int8_t>(t_s32);
        output[idx] = spike_i;
    }
}


void ST_BIF_forward_scale_in_scale_int(float* x_t, float* V_t_1, int8_t* T_t_1, int8_t* output, int N, float scale, float v_th, int T_max, int T_min)
{
    if (N == 0) return;

    // AVX-512 processes 16 floats per vector
    const size_t simd_width = 16;
    const size_t vec_end = (N / simd_width) * simd_width;

    // Broadcasted constants
    __m512 vth512 = _mm512_set1_ps(v_th);
    __m512 scale512 = _mm512_set1_ps(scale);
    __m512 zero512 = _mm512_setzero_ps();

    __m512i ones_i32_512 = _mm512_set1_epi32(1);
    __m512 Tmax_f32 = _mm512_set1_ps(T_max);
    __m512 Tmin_f32 = _mm512_set1_ps(T_min);

    const int num_threads = 64;
    // choose chunk size per OpenMP schedule; avoid zero
    int chunk = 1;
    if (num_threads > 0) {
        size_t approx_chunk = N / ( (size_t)num_threads * simd_width );
        if (approx_chunk > 0) chunk = static_cast<int>(approx_chunk);
    }

    #pragma omp parallel for num_threads(num_threads) schedule(static, chunk)
    for (size_t i = 0; i < vec_end; i += simd_width) {
        alignas(64) int32_t tmp_spike32[16];
        // load 16 floats
        __m512 x_vec = _mm512_loadu_ps(x_t + i);
        __m512 Vprev = _mm512_loadu_ps(V_t_1 + i);

        // 载入 16 个 int8 的 T
        __m128i t8raw     = _mm_loadu_si128((const __m128i*)(T_t_1 + i));  // 128 bits = 16×int8
        __m512i t32i      = _mm512_cvtepi8_epi32(t8raw);                  // 16×int8 -> 16×int32
        __m512  t32       = _mm512_cvtepi32_ps(t32i);                     // 16×int32 -> 16×float

        // H = Vprev + x
        __m512 H = _mm512_add_ps(Vprev, _mm512_mul_ps(x_vec, scale512));

        // comparisons on floats -> masks (per-lane)
        __mmask16 mask_ge = _mm512_cmp_ps_mask(H, vth512, _CMP_GE_OQ);  // H >= v_th
        __mmask16 mask_lt0 = _mm512_cmp_ps_mask(H, zero512, _CMP_LT_OQ); // H < 0

        // comparisons on ints -> masks
        __mmask16 mask_t_lt_tmax = _mm512_cmp_ps_mask(t32, Tmax_f32, _CMP_LT_OQ); // Tmax > t -> t < Tmax
        __mmask16 mask_t_gt_tmin = _mm512_cmp_ps_mask(Tmin_f32, t32, _CMP_LT_OQ); // t > Tmin

        // combine masks
        __mmask16 pos_mask = mask_ge & mask_t_lt_tmax;
        __mmask16 neg_mask = mask_lt0 & mask_t_gt_tmin;

        // Convert mask -> 0/1 int32 vector
        __m512i pos01 = _mm512_maskz_mov_epi32(pos_mask, ones_i32_512); // ones where pos_mask, else 0
        __m512i neg01 = _mm512_maskz_mov_epi32(neg_mask, ones_i32_512);

        // spike_i32 = pos01 - neg01
        __m512i spike_i32 = _mm512_sub_epi32(pos01, neg01); // values in {-1,0,1}

        // convert spike to float
        __m512 spike_f = _mm512_cvtepi32_ps(spike_i32);

        // Vnew = H - v_th * spike
        __m512 vth_mul_spike = _mm512_mul_ps(vth512, spike_f);
        __m512 Vnew = _mm512_sub_ps(H, vth_mul_spike);

        // store Vnew and spike_out (into x_t)
        _mm512_storeu_ps(V_t_1 + i, Vnew);
        _mm512_storeu_si512((void*)tmp_spike32, spike_i32);

        for (int k = 0; k < 16; ++k) {
            int32_t tspike = tmp_spike32[k];
            output[i + k] = (int8_t)tspike; // implementation-defined truncation (low 8 bits)
        }
        // tnew = t32 + (v_th * spike)
        __m512 tnew_f = _mm512_add_ps(t32, spike_f);

        // 转回 int32
        __m512i tnew_i32 = _mm512_cvtps_epi32(tnew_f);   // float→int32 (四舍五入)
        // 如果想采用截断或向零舍入，可用 _mm512_cvttps_epi32()

        // 饱和到 int8
        __m128i tnew_i8 = _mm512_cvtepi32_epi8(tnew_i32); // 16×int32 -> 16×int8 (饱和)

        // 存回 T_t_1
        _mm_storeu_si128((__m128i*)(T_t_1 + i), tnew_i8);
    }

    // tail scalar loop for elements not divisible by 16
    for (size_t idx = vec_end; idx < N; ++idx) {
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        int8_t prevT_8 = T_t_1[idx];
        float Tp = (float)prevT_8;
        float H = Vp + x * scale;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max*v_th)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min*v_th)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        float tnew = Tp + spike_i; // truncation as in vector path
        // x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        int t_s32 = static_cast<int>(std::lrintf(tnew)); 
        T_t_1[idx] = static_cast<int8_t>(t_s32);
        output[idx] = spike_i;
    }
}


void ST_BIF_forward_true(float* x_t, float* V_t_1, int8_t* T_t_1, int N, float v_th, int T_max, int T_min){
    
    // const size_t N = (size_t)rows * (size_t)cols;
    if (N == 0) return;

    for (size_t idx = 0; idx < N; ++idx){
        float x = x_t[idx];
        float Vp = V_t_1[idx];
        int8_t Tp = T_t_1[idx];
        float H = Vp + x;
        int8_t spike_i = 0;
        if (H >= v_th && (Tp < T_max)) spike_i = 1;
        else if (H < 0.0f && (Tp > T_min)) spike_i = -1;
        float spike_out = ((float)spike_i) * v_th;
        float Vnew = H - spike_out;
        int8_t tnew = Tp + spike_i;
        // printf("H=%f, v_th=%f, Tp=%d, T_max=%d, T_min=%d,spike_i=%d, Vnew=%f, tnew=%d\n",H,v_th, Tp, T_max, T_min, spike_i,Vnew,tnew);
        x_t[idx] = spike_out;
        V_t_1[idx] = Vnew;
        T_t_1[idx] = tnew; // 直接转换，不作 clamp
    }
}    

float* rand01_matrix_alloc(size_t rows, size_t cols, int seed) {
    if (rows == 0 || cols == 0) return NULL;
    size_t N = rows * cols;
    float *M = (float*)malloc(N * sizeof(float));
    if (!M) return NULL;

    if (seed == -1) srand((unsigned)time(NULL));
    else srand((unsigned)seed);

    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            unsigned int r = (unsigned int)rand(); // 0 .. RAND_MAX
            M[i*cols + j] = ((float)r / ((float)RAND_MAX + 1.0f) - 0.5)*2; // in [-1,1)
        }
    }
    return M;
}

int8_t* rand04_matrix_alloc(size_t rows, size_t cols, int seed) {
    if (rows == 0 || cols == 0) return NULL;
    size_t N = rows * cols;
    int8_t *M = (int8_t*)malloc(N * sizeof(int8_t));
    if (!M) return NULL;

    if (seed == -1) srand((unsigned)time(NULL));
    else srand((unsigned)seed);

    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            unsigned int r = (unsigned int)rand(); // 0 .. RAND_MAX
            M[i*cols + j] = (int8_t)(r%9) - 4; // in [-4,4]
        }
    }
    return M;
}


void print_matrix(float* A,int M, int N){
    for (int i = 0; i < M; ++i){
        for (int j = 0; j < N; ++j){
            printf("%.4f ", A[i*N+j]);
        }
        printf("\n");
    }
}

void print_matrix_int(int8_t* A,int M, int N){
    for (int i = 0; i < M; ++i){
        for (int j = 0; j < N; ++j){
            printf("%d ", A[i*N+j]);
        }
        printf("\n");
    }
}



int main(int argc, char** argv){

    int warmup_iter = 100;
    int test_iter = 100;

    const int M = static_cast<int>(atof(argv[1]));
    const int N = static_cast<int>(atof(argv[2]));
    const float v_th = static_cast<float>(atof(argv[3]));    
    int T_max = 4;
    int T_min = -4;
    printf("M=%d, N=%d, v_th=%f\n",M,N,v_th);

    float* x = rand01_matrix_alloc(M,N,42);
    // printf("=============x================\n");
    // print_matrix(x, M,N);

    float*x_input = rand01_matrix_alloc(M,N,42);
    memcpy(x_input, x, sizeof(float)*M*N);
    float*v = rand01_matrix_alloc(M,N,42);
    int8_t*T = rand04_matrix_alloc(M,N,42);

    for (int i = 0; i < warmup_iter; i++) {
        memcpy(x_input, x, sizeof(float)*M*N);
        ST_BIF_forward(x_input, v, T, M * N, v_th, T_max, T_min);
    }

    double spend_time1 = 0.0;
    for (int i = 0; i < test_iter; i++) {
        memcpy(x_input, x, sizeof(float)*M*N);
        auto t_start = std::chrono::steady_clock::now();
        ST_BIF_forward(x_input, v, T, M * N, v_th, T_max, T_min);
        auto t_end = std::chrono::steady_clock::now();
        std::chrono::duration<double> diff = t_end - t_start;
        spend_time1 = spend_time1 + (double)diff.count();
    }

    printf("ST_BIF_forward spend time=%.6f\n",spend_time1/test_iter);

    for (int i = 0; i < test_iter; i++) {
        float*x = rand01_matrix_alloc(M,N,42);

        float*x_input = rand01_matrix_alloc(M,N,42);
        memcpy(x_input, x, sizeof(float)*M*N);
        // printf("=============x_input================\n");
        // print_matrix(x_input, M,N);

        float*x_input2 = rand01_matrix_alloc(M,N,42);
        memcpy(x_input2, x, sizeof(float)*M*N);
        // printf("=============x_input2================\n");
        // print_matrix(x_input2, M,N);

        float*v = rand01_matrix_alloc(M,N,43);
        int8_t*T = rand04_matrix_alloc(M,N,44);
        // printf("=============v================\n");
        // print_matrix(v, M,N);
        // printf("=============T================\n");
        // print_matrix_int(T, M,N);
        float*v2 = rand01_matrix_alloc(M,N,43);
        int8_t*T2 = rand04_matrix_alloc(M,N,44);

        ST_BIF_forward(x_input, v, T, M * N, v_th, T_max, T_min);
        ST_BIF_forward_true(x_input2, v2, T2, M * N, v_th, T_max, T_min);

        memcpy(x_input, x, sizeof(float)*M*N);
        memcpy(x_input2, x, sizeof(float)*M*N);
        // printf("================================================================\n");

        ST_BIF_forward(x_input, v, T, M * N, v_th, T_max, T_min);
        ST_BIF_forward_true(x_input2, v2, T2, M * N, v_th, T_max, T_min);
        // printf("=============x_output================\n");
        // print_matrix(x_input, M,N);
        // printf("=============x_output2================\n");
        // print_matrix(x_input2, M,N);
            // 对比结果
        bool ok = true;
        int errors = 0;
        float tolerance = 1e-5f;
        const int max_show = 10;
        for (int i = 0; i < M; ++i) {
            for (int j = 0; j < N; ++j) {
                float ref = x_input2[i * N + j];
                float got = x_input[i * N + j];
                float diff = std::fabs(ref - got);
                if (diff > tolerance) {
                    ok = false;
                    if (errors < max_show) {
                        printf("ERROR [%d,%d]: ref=%.6f, gust=%.6f, diff=%.6f\n",
                            i, j, ref, got, diff);
                    }
                    ++errors;
                }
            }
        }
        if (ok) {
            printf("\033[1;32mcorrect\033[0m: all %d elements matched ✓\n", M * N);
        }
        else {
            printf("\033[1;31mINCORRECT\033[0m: %d errors out of %d elements\n",
                errors, M * N);
        }
    }

    return 0;
}


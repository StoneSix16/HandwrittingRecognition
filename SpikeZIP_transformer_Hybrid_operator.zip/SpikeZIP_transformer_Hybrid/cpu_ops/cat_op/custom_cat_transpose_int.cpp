#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include <ATen/ATen.h>
#include <ATen/Parallel.h>
#include <torch/extension.h>
#include <vector>
#include <algorithm>

using namespace at;

std::vector<Tensor> custom_cat_trans_int8(
    const Tensor& x1_t,
    const Tensor& x2_sum_t,
    const Tensor& x1_sum_t,
    const Tensor& x2_t,
    const Tensor& x1_cat,
    const Tensor& x2_cat
) {
    // 假设形状检查、设备检查、类型检查等都已在外部完成
    const int64_t B = x1_t.size(0);
    const int64_t H = x1_t.size(1);
    const int64_t N = x1_t.size(2);
    const int64_t K = x1_t.size(3);
    const int64_t M = x2_t.size(3);

    // 预先取出 data_ptr 和 stride，避免循环中反复 .index() 或 .select()
    // 这里只示例 float，如果实际情况有别，需要自行适配
    const int8_t* x1_t_ptr      = x1_t.data_ptr<int8_t>();
    const int8_t* x1_sum_t_ptr  = x1_sum_t.data_ptr<int8_t>();
    const int8_t* x2_t_ptr      = x2_t.data_ptr<int8_t>();
    const int8_t* x2_sum_t_ptr  = x2_sum_t.data_ptr<int8_t>();

    int8_t* x1_cat_ptr = x1_cat.data_ptr<int8_t>();
    int8_t* x2_cat_ptr = x2_cat.data_ptr<int8_t>();

    // stride
    // 注意：Torch 的 stride 是以元素为单位（而非字节），后续指针偏移无需再乘 sizeof(float)
    const auto x1_t_strides      = x1_t.strides();
    const auto x1_sum_t_strides  = x1_sum_t.strides();
    const auto x2_t_strides      = x2_t.strides();
    const auto x2_sum_t_strides  = x2_sum_t.strides();
    const auto x1_cat_strides    = x1_cat.strides();
    const auto x2_cat_strides    = x2_cat.strides();

    // 计算并行策略
    const int64_t BH = B * H;
    int64_t num_threads = at::get_num_threads();
    int64_t grain_size = std::max<int64_t>(static_cast<int64_t>(1), BH / (num_threads * 4));

    // 并行拷贝
    at::parallel_for(0, BH, grain_size, [&](int64_t begin, int64_t end) {
        for (int64_t idx = begin; idx < end; ++idx) {
            const int64_t b = idx / H;
            const int64_t h = idx % H;

            // 计算出本批、本头在原张量和目标张量中的偏移基址
            // x1_cat.shape = [B, H, N, 2K]，故对于第 (b, h)：
            //   out_x1_base = x1_cat_ptr + b*x1_cat_strides[0] + h*x1_cat_strides[1]
            int8_t* out_x1_base = x1_cat_ptr
                + b * x1_cat_strides[0]
                + h * x1_cat_strides[1];

            // x2_cat.shape = [B, H, 2K, M]
            int8_t* out_x2_base = x2_cat_ptr
                + b * x2_cat_strides[0]
                + h * x2_cat_strides[1];

            const int8_t* in_x1_sum_base = x1_sum_t_ptr
                + b * x1_sum_t_strides[0]
                + h * x1_sum_t_strides[1];
            const int8_t* in_x1_base = x1_t_ptr
                + b * x1_t_strides[0]
                + h * x1_t_strides[1];

            const int8_t* in_x2_base = x2_t_ptr
                + b * x2_t_strides[0]
                + h * x2_t_strides[1];
            const int8_t* in_x2_sum_base = x2_sum_t_ptr
                + b * x2_sum_t_strides[0]
                + h * x2_sum_t_strides[1];

            // 拷贝 x1：形状 (N,2K) = cat( [x1_sum_t: (N,K)], [x1_t: (N,K)] ) 按列拼
            for (int64_t n = 0; n < N; ++n) {
                const int8_t* row_x1_sum = in_x1_sum_base
                    + n * x1_sum_t_strides[2];
                const int8_t* row_x1     = in_x1_base
                    + n * x1_t_strides[2];

                int8_t* out_row = out_x1_base
                    + n * x1_cat_strides[2];

                // 先拷贝前 K 列（来自 x1_sum_t），再拷贝后 K 列（来自 x1_t）
                // 这里再循环一层 K，可以改成 memcpy，但仅当都保证连续时才安全。
                for (int64_t k = 0; k < K; ++k) {
                    out_row[k]      = row_x1_sum[k * x1_sum_t_strides[3]];
                    out_row[k + K]  = row_x1[k * x1_t_strides[3]];
                }
            }

            // 拷贝 x2：形状 (2K,M) = cat( [x2_t: (K,M)], [x2_sum_t: (K,M)] ) 按行拼
            // 对应 x2_cat 的第 2 维是 2K，所以第 0 维 strides[2] 之类的要看实际存储
            for (int64_t k_ = 0; k_ < K; ++k_) {
                const int8_t* row_x2     = in_x2_base
                    + k_ * x2_t_strides[2];
                const int8_t* row_x2_sum = in_x2_sum_base
                    + k_ * x2_sum_t_strides[2];

                // out_x2_base + 前半部分
                int8_t* out_x2_row_0 = out_x2_base
                    + k_ * x2_cat_strides[2];
                // out_x2_base + 后半部分
                int8_t* out_x2_row_1 = out_x2_base
                    + (k_ + K) * x2_cat_strides[2];

                // 按列拷贝 M
                for (int64_t m = 0; m < M; ++m) {
                    out_x2_row_0[m] = row_x2[m * x2_t_strides[3]];
                    out_x2_row_1[m] = row_x2_sum[m * x2_sum_t_strides[3]];
                }
            }
        }
    });

    return { x1_cat, x2_cat };
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_cat_trans_int8(Tensor x1_t, Tensor x2_sum_t, Tensor x1_sum_t, Tensor x2_t, Tensor x1_cat, Tensor x2_cat) -> Tensor[]");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_cat_trans_int8", TORCH_FN(custom_cat_trans_int8));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_cat_trans_int8", &custom_cat_trans_int8,
          "customized Linear matching aten::linear",
          py::arg("x1_t"),
          py::arg("x2_sum_t"),
          py::arg("x1_sum_t"),
          py::arg("x2_t"),
          py::arg("x1_cat"),
          py::arg("x2_cat")
    );
}



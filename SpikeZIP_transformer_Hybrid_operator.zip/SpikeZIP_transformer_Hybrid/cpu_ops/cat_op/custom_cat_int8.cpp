#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <chrono>
#include <ATen/ATen.h>
#include <vector>
#include <cstring> // memcpy

using at::Tensor;

std::vector<Tensor> custom_cat_int(
    const Tensor& x1_t,
    const Tensor& x2_sum_t,
    const Tensor& x1_sum_t,
    const Tensor& x2_t,
    const Tensor& x1_cat,
    const Tensor& x2_cat
) {

    // TORCH_CHECK(x1_t.dim() == 4 && x1_sum_t.dim() == 4, "x1 tensors must be 4D");
    // TORCH_CHECK(x2_t.dim() == 4 && x2_sum_t.dim() == 4, "x2 tensors must be 4D");
    // TORCH_CHECK(x1_t.sizes() == x1_sum_t.sizes(), "x1_sum_t shape must match x1_t");
    // TORCH_CHECK(x2_t.sizes() == x2_sum_t.sizes(), "x2_sum_t shape must match x2_t");

    // TORCH_CHECK(x1_t.device().is_cpu() && x2_t.device().is_cpu()
    //             && x1_sum_t.device().is_cpu() && x2_sum_t.device().is_cpu(),
    //             "All tensors must be on CPU");
    // TORCH_CHECK(x1_t.dtype() == at::kFloat && x1_sum_t.dtype() == at::kFloat
    //             && x2_t.dtype() == at::kFloat && x2_sum_t.dtype() == at::kFloat,
    //             "All tensors must be float32");
    // TORCH_CHECK(x1_t.is_contiguous() && x1_sum_t.is_contiguous()
    //             && x2_t.is_contiguous() && x2_sum_t.is_contiguous(),
    //             "All inputs must be contiguous");

    const int64_t B = x1_t.size(0);
    const int64_t H = x1_t.size(1);
    const int64_t N = x1_t.size(2);
    const int64_t K = x1_t.size(3);
    const int64_t M = x2_t.size(3);

    // Tensor x1_cat = at::empty({B, H, N, 2 * K}, x1_t.options());
    // Tensor x2_cat = at::empty({B, H, 2 * K, M}, x2_t.options());

    // add restrict to help compiler (GCC/Clang)
    const int8_t* __restrict__ p_x1_sum = x1_sum_t.data_ptr<int8_t>();
    const int8_t* __restrict__ p_x1     = x1_t.data_ptr<int8_t>();
    int8_t*       __restrict__ p_x1_cat = x1_cat.data_ptr<int8_t>();

    const int8_t* __restrict__ p_x2     = x2_t.data_ptr<int8_t>();
    const int8_t* __restrict__ p_x2_sum = x2_sum_t.data_ptr<int8_t>();
    int8_t*       __restrict__ p_x2_cat = x2_cat.data_ptr<int8_t>();

    const int64_t NH = B * H;

    const size_t K_t = static_cast<size_t>(K);
    const size_t N_t = static_cast<size_t>(N);
    const size_t M_t = static_cast<size_t>(M);

    const size_t x1_block_elems = N_t * K_t;   // elements per (b,h) block for x1
    const size_t x2_block_elems = K_t * M_t;   // elements per (b,h) block for x2

    const size_t x1_block_bytes = x1_block_elems * sizeof(int8_t);
    const size_t x2_block_bytes = x2_block_elems * sizeof(int8_t);

    // --- x1: collapse(bh, n) parallel ---
    #pragma omp parallel for num_threads(64) schedule(static) collapse(2)
    for (int64_t bh = 0; bh < NH; ++bh) {
        for (int64_t n = 0; n < N; ++n) {
            // compute block starts using pointer arithmetic to avoid large-int multiplications
            const int8_t* src1_block = p_x1_sum + static_cast<size_t>(bh) * x1_block_elems;
            const int8_t* src2_block = p_x1     + static_cast<size_t>(bh) * x1_block_elems;
            int8_t*       dst_block   = p_x1_cat + static_cast<size_t>(bh) * (2 * x1_block_elems);

            const int8_t* src1_ptr = src1_block + static_cast<size_t>(n) * K_t;
            const int8_t* src2_ptr = src2_block + static_cast<size_t>(n) * K_t;
            int8_t*       dst_ptr  = dst_block + static_cast<size_t>(n) * (2 * K_t);

            // prefetch next n (helpful when K large)
            if (n + 1 < N) {
                __builtin_prefetch(src1_block + static_cast<size_t>(n + 1) * K_t, 0, 1);
                __builtin_prefetch(src2_block + static_cast<size_t>(n + 1) * K_t, 0, 1);
            }

            // copy K floats: x1_sum -> dst[..., :K], x1 -> dst[..., K:2K]
            std::memcpy(dst_ptr, src1_ptr, static_cast<size_t>(K) * sizeof(int8_t));
            std::memcpy(dst_ptr + K_t, src2_ptr, static_cast<size_t>(K) * sizeof(int8_t));
        }
    }

    // --- x2: collapse(bh, k) parallel ---
    #pragma omp parallel for num_threads(64) schedule(static) collapse(2)
    for (int64_t bh = 0; bh < NH; ++bh) {
        for (int64_t k = 0; k < K; ++k) {
            const int8_t* src_block = p_x2 + static_cast<size_t>(bh) * x2_block_elems;
            const int8_t* src2_block = p_x2_sum + static_cast<size_t>(bh) * x2_block_elems;
            int8_t*       dst_block = p_x2_cat + static_cast<size_t>(bh) * (2 * x2_block_elems);

            const int8_t* src_ptr = src_block + static_cast<size_t>(k) * M_t;
            const int8_t* src2_ptr = src2_block + static_cast<size_t>(k) * M_t;
            int8_t*       dst_ptr = dst_block + static_cast<size_t>(k) * M_t;

            // prefetch next k
            if (k + 1 < K) {
                __builtin_prefetch(src_block + static_cast<size_t>(k + 1) * M_t, 0, 1);
                __builtin_prefetch(src2_block + static_cast<size_t>(k + 1) * M_t, 0, 1);
            }

            // copy M floats: x2 -> dst[k,:], x2_sum -> dst[k+K,:]
            std::memcpy(dst_ptr, src_ptr, static_cast<size_t>(M) * sizeof(int8_t));
            std::memcpy(dst_ptr + K_t * M_t, src2_ptr, static_cast<size_t>(M) * sizeof(int8_t));
        }
    }

    return { x1_cat, x2_cat };
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_cat_int(Tensor x1_t, Tensor x2_sum_t, Tensor x1_sum_t, Tensor x2_t, Tensor x1_cat, Tensor x2_cat) -> Tensor[]");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_cat_int", TORCH_FN(custom_cat_int));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_cat_int", &custom_cat_int,
          "customized Linear matching aten::linear",
          py::arg("x1_t"),
          py::arg("x2_sum_t"),
          py::arg("x1_sum_t"),
          py::arg("x2_t"),
          py::arg("x1_cat"),
          py::arg("x2_cat")
    );
}



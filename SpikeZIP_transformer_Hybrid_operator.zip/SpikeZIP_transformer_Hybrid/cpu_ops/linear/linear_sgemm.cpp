#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
torch::Tensor custom_linear(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const c10::optional<torch::Tensor>& bias_opt,
    bool fuse_relu
) {
    // 1) Ensure contiguous (avoiding copy if already contiguous)
    auto in_contig  = input.is_contiguous()  ? input  : input.contiguous();
    auto wt_contig  = weight.is_contiguous() ? weight : weight.contiguous();

    // 2) Dimensions
    int64_t M = in_contig.size(0);
    int64_t K = in_contig.size(1);
    int64_t N = wt_contig.size(0);

    TORCH_CHECK(wt_contig.size(1) == K,
        "custom_linear: weight.size(1) must match input.size(1)");

    // 3) Prepare output
    auto output = torch::empty({M, N}, in_contig.options());
    float* C = output.data_ptr<float>();

    const float* A = in_contig.data_ptr<float>();  // M×K
    const float* B = wt_contig.data_ptr<float>();  // N×K

    // 4) Bias handling: initialize C matrix with bias rows if provided
    bool has_bias = bias_opt.has_value() && bias_opt->defined();
    const float* bias_ptr = nullptr;
    if (has_bias) {
        auto bias = bias_opt.value();
        TORCH_CHECK(bias.dim() == 1 && bias.size(0) == N,
            "custom_linear: bias must be 1D of length N");
        bias_ptr = bias.data_ptr<float>();
        // Fill each row of C with bias
        #pragma omp parallel for
        for (int64_t i = 0; i < M; ++i) {
            memcpy(C + i * N, bias_ptr, sizeof(float) * N);
        }
    } else {
        // If no bias, zero initialize C
        output.zero_();
    }

    // 5) Optionally set MKL threads
    mkl_set_num_threads(omp_get_max_threads());

    // 6) GEMM: C = 1*A*Bᵀ + 1*C (if bias) or +0*C (if no bias)
    float alpha = 1.0f;
    float beta  = has_bias ? 1.0f : 0.0f;

    cblas_sgemm(
        CblasRowMajor,
        CblasNoTrans,   // A: M×K
        CblasTrans,     // Bᵀ: K×N
        M,              // rows of A and C
        N,              // cols of C
        K,              // inner dimension
        alpha,
        A, K,           // A, lda = K
        B, K,           // B, ldb = K
        beta,
        C, N            // C, ldc = N
    );


    if (fuse_relu) {
        output = at::gelu(output);
    }

    return output;
}


// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_linear(Tensor input, Tensor weight, Tensor? bias, bool fuse_relu) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_linear", TORCH_FN(custom_linear));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_linear", &custom_linear,
          "customized Linear matching aten::linear",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("fuse_relu") = false
    );
}


#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include "MKL_Sparse_Methods.h"
#include "custom_spmm_zjx.h"
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <chrono>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
static constexpr int BM = 64;
static constexpr int BN = 64;
static constexpr int BK = 64;

torch::Tensor custom_linear(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const c10::optional<torch::Tensor>& bias_opt,
    bool fuse_relu
) {
    // auto t_start = std::chrono::steady_clock::now();
    // 1) Ensure contiguous
    // auto in_contig = input.is_contiguous()  ? input  : input.contiguous();
    // auto wt_contig = weight.is_contiguous() ? weight : weight.contiguous();
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("SpMM_yk contiguous: %.6f ms\n",
    //    diff.count()*1000);

    // 2) Dimensions
    int64_t M = input.size(0);
    int64_t K = input.size(1);
    int64_t N = weight.size(1);

    TORCH_CHECK(weight.size(0) == K,
        "custom_linear: weight.size(0) must match input.size(1)");

    // 3) Allocate and init output
    // auto t_start = std::chrono::steady_clock::now();
    auto output = torch::empty({M, N}, input.options());
    float* C = output.data_ptr<float>();
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("SpMM_yk C allocation: %.6f ms\n",
    //    diff.count()*1000);

    // t_start = std::chrono::steady_clock::now();
    if (bias_opt.has_value() && bias_opt->defined()) {
        auto bias = bias_opt.value();
        TORCH_CHECK(bias.dim() == 1 && bias.size(0) == N,
            "custom_linear: bias must be 1D of length N");
        const float* bias_ptr = bias.data_ptr<float>();

        // init each row with bias
        #pragma omp parallel for num_threads(64) schedule(static)
        for (int64_t i = 0; i < M; ++i) {
            memcpy(C + i * N, bias_ptr, N * sizeof(float));
        }
    } 
    else {
        // zero init
        #pragma omp parallel for num_threads(64) schedule(static)
        for (int i = 0; i < M; ++i) {
            float* row = C + (size_t)i * N;
            memset(row, 0, N * sizeof(float));
        }
        // std::fill_n(C, M * N, 0.0f);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("SpMM_yk bias calculation: %.6f ms\n",
    //    diff.count()*1000);

    // t_start = std::chrono::steady_clock::now();
    MKL_Sparse_CooXDense_Fast_Gustavson_new_yk(input.data_ptr<float>(), weight.data_ptr<float>(), C, M, K, N, 0);
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("SpMM_yk matrix multiplication: %.6f ms\n",
    //    diff.count()*1000);

    if (fuse_relu) {
        output = at::gelu(output);
    }
    return output;
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_linear(Tensor input, Tensor weight, Tensor? bias, bool fuse_relu) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_linear", TORCH_FN(custom_linear));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_linear", &custom_linear,
          "customized Linear matching aten::linear",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("fuse_relu") = false
    );
}



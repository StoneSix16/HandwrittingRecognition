from torch.utils.cpp_extension import load
import torch

# 1. 编译并加载扩展
mkl_linear = load(
    name="linear_pytorch",
    sources=["linear_pytorch.cpp"],
    extra_ldflags=["-ldnnl"],  # 如果不使用 oneDNN，可以删掉这行
    verbose=True,
)

# 2. 构造输入数据
batch_size    = 8
in_features   = 128
out_features  = 64

x = torch.randn(batch_size, in_features, dtype=torch.float32)
w = torch.randn(out_features, in_features, dtype=torch.float32)
b = torch.randn(out_features, dtype=torch.float32)

# 3. 调用自定义的 mkl_linear
#    签名：mkl_linear(Tensor input, Tensor weight, Tensor? bias) -> Tensor
out = torch.ops.custom.custom_linear(x, w, b)

#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
torch::Tensor custom_linear(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const c10::optional<torch::Tensor>& bias_opt,
    bool fuse_relu
) {
    // Call into ATen's native linear
    torch::Tensor out;
    if (bias_opt.has_value() && bias_opt->defined()) {
        out = at::linear(input, weight, bias_opt.value());
    } else {
        out = at::linear(input, weight, c10::nullopt);
    }

    if (fuse_relu) {
        out = at::gelu(out);
    }

    return out;
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_linear(Tensor input, Tensor weight, Tensor? bias, bool fuse_relu) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_linear", TORCH_FN(custom_linear));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_linear", &custom_linear,
          "customized Linear matching aten::linear",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("fuse_relu") = false
    );
}

// optimized: acc_tile init moved outside kb loop, memcpy copy, reuse acc_tile per (cb,rb)
#include "MKL_Sparse_Methods.h"
#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>

// portable aligned alloc/free
static inline void* portable_aligned_alloc(size_t alignment, size_t size) {
    if (size == 0) return nullptr;
    size_t extra = alignment - 1 + sizeof(void*);
    void* raw = malloc(size + extra);
    if (!raw) return nullptr;
    uintptr_t raw_addr = (uintptr_t)raw + sizeof(void*);
    uintptr_t aligned = (raw_addr + (alignment - 1)) & ~(alignment - 1);
    void** store = (void**)(aligned - sizeof(void*));
    *store = raw;
    return (void*)aligned;
}
static inline void portable_aligned_free(void* p) {
    if (!p) return;
    void** store = (void**)((uintptr_t)p - sizeof(void*));
    void* raw = *store;
    free(raw);
}

#if defined(_MSC_VER)
static inline void prefetch_read(const void* p) { _mm_prefetch((const char*)p, _MM_HINT_T0); }
#else
static inline void prefetch_read(const void* p) { __builtin_prefetch(p, 0, 1); }
#endif

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk(
    float* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        float* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            c += (Ai[j] != 0.0f);
        }
        rowCounts[i] = c;
    }

    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    float density = (float)nnz/(float)(rowsA*colsA);
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<float> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        float* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) {
                int addr = base + off; 
                col_idx[addr] = (MKL_INT)j; 
                val[addr] = x; 
                ++off; 
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("\t Sparse×Dense (build CSR): %.6f ms\n",
    //    diff.count()*1000);
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);

    // 3) tiling params
    // t_start = std::chrono::steady_clock::now();
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304){
        Rb = 128, Kc = 128, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    // if (Rb > rowsA) Rb = rowsA;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }
    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::max(16, std::min(Nb, colsC));
    // Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("\t Sparse×Dense (tiling): %.6f ms\n",
    //    diff.count()*1000);
    
    // t_start = std::chrono::steady_clock::now();
    if (density < 0.01){
        int vec_end = (colsC / VEC_WIDTH) * VEC_WIDTH;
        #pragma omp parallel for num_threads(64) schedule(static)
        for (int rb = 0; rb < rowsA; ++rb) {
            // float* B_row_buffer = (float*)portable_aligned_alloc(ACC_ALIGN, sizeof(float)*colsC);
            MKL_INT start = row_ptr[rb], end = row_ptr[rb + 1];
            // float* C_row_buffer = (float*)portable_aligned_alloc(ACC_ALIGN, sizeof(float)*colsC);
            float* Crow = denseC + (size_t)(rb) * (size_t)colsC;
            // memcpy(C_row_buffer, Crow, sizeof(float)*colsC);

            MKL_INT p = start;
            // singletons
            for (; p < end; ++p) {
                MKL_INT k_col = col_idx[p];
                float v = val[p];
                const float* Brow = denseB + (size_t)(k_col) * (size_t)colsC;
                // memcpy(B_row_buffer, Brow, sizeof(float)*colsC);
                __m256 vv = _mm256_set1_ps(v);
                int j = 0;
                for (; j < vec_end; j += VEC_WIDTH) {
                    __m256 accv = _mm256_loadu_ps(Crow + j);
                    __m256 bvec = _mm256_loadu_ps(Brow + j);
                    accv = _mm256_fmadd_ps(vv, bvec, accv);
                    _mm256_storeu_ps(Crow + j, accv);
                }
                if (vec_end < colsC) {
                    for (int jj = vec_end; jj < colsC; ++jj) Crow[jj] += v * Brow[jj];
                }
            } // singletons
        }

    }
    else{
        #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                const MKL_INT* row_ptr_p = row_ptr.data();
                const MKL_INT* col_idx_p = col_idx.data();
                const float* val_p = val.data();
                const float* denseB_p = denseB;
                float* denseC_p = denseC;

                // FIX: nb_eff must be the remaining columns in this block
                int nb_eff = std::min(Nb, colsC - cb);
                if (nb_eff <= 0) continue;

                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
                size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
                size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
                if (acc_tile_max_elems == 0) continue;

                // allocate acc_tile buffer for this (cb,rb) - aligned
                void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
                bool acc_tile_buf_portable = true;
                if (!acc_tile_buf_tmp) {
                    acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                    acc_tile_buf_portable = false;
                    if (!acc_tile_buf_tmp) {
                        // allocation failed -> skip this tile (or handle error)
                        continue;
                    }
                }
                float* acc_tile_buf = (float*)acc_tile_buf_tmp;

                // allocate packedB buffer (kc_eff * nb_eff) later per kb loop; allocate max size now to reuse
                size_t pack_elems_max = (size_t)Kc * (size_t)nb_eff;
                void* packed_tmp = nullptr;
                bool packed_portable = false;
                if (pack_elems_max > 0) {
                    packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems_max * sizeof(float));
                    packed_portable = (packed_tmp != nullptr);
                    if (!packed_tmp) {
                        packed_tmp = malloc(pack_elems_max * sizeof(float));
                        packed_portable = false;
                        if (!packed_tmp) {
                            // allocation failed -> cleanup and continue
                            if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); else free(acc_tile_buf_tmp);
                            continue;
                        }
                    }
                }

                int rb_eff = std::min(Rb, rowsA - rb);
                float* acc_tile = acc_tile_buf; // prefix usage

                // init acc_tile from denseC (copy nb_eff floats), zero pad
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // cursor initialised to row_ptr for each local row
                // std::vector<MKL_INT> cursor(rb_eff);
                // for (int local_i = 0; local_i < rb_eff; ++local_i) cursor[local_i] = row_ptr_p[rb + local_i];

                // kb loop
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    int kblock_end = kb + kc_eff;
                    if (kc_eff <= 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    float* packedB = (float*)packed_tmp;
                    // pack B rows [kb .. kb+kc_eff) for columns [cb .. cb+nb_eff)
                    for (int kk = 0; kk < kc_eff; ++kk) {
                        const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                        float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                        if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    }

                    // process local rows
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                        if (start >= end) continue;
                        MKL_INT* base = col_idx.data();
                        MKL_INT* s = base + start;
                        MKL_INT* e = base + end;

                        MKL_INT* p0 = std::lower_bound(s, e, kb);
                        MKL_INT it0 = (MKL_INT)(p0 - base);

                        MKL_INT* p1 = std::lower_bound(p0, e, kblock_end);
                        MKL_INT it1 = (MKL_INT)(p1 - base);

                        MKL_INT p = it0;

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p[p];
                            float v = val_p[p];
                            const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                            __m256 vv = _mm256_set1_ps(v);
                            int j = 0;
                            for (; j < vec_end; j += VEC_WIDTH) {
                                __m256 accv = _mm256_load_ps(acc_row + j);
                                __m256 bvec = _mm256_load_ps(Brow + j);
                                accv = _mm256_fmadd_ps(vv, bvec, accv);
                                _mm256_store_ps(acc_row + j, accv);
                            }
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                            }
                        } // p
                    } // local_i
                } // kb

                // write back acc_tile to C
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_load_ps(src_row + j);    // aligned load (acc_tile is aligned)
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }

                // cleanup: free buffers (use correct portable flags)
                if (packed_tmp) {
                    if (packed_portable) portable_aligned_free(packed_tmp);
                    else free(packed_tmp);
                    packed_tmp = nullptr;
                }
                if (acc_tile_buf_tmp) {
                    if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp);
                    else free(acc_tile_buf_tmp);
                    acc_tile_buf_tmp = nullptr;
                }
            }
        }

    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("\t Sparse×Dense (calculation): %.6f ms\n",
    //    diff.count()*1000);
    return true;
}

bool MKL_Sparse_CooXDense_Fast_Gustavson_new_yk_ternary(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // auto t_start = std::chrono::steady_clock::now();
    // 1) build CSR (same as before)
    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j){
            if (Ai[j] != 0.0f) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    if (nnz == 0){
        return true;
    }
    float density = (float)nnz/(float)(rowsA*colsA);
    std::vector<int16_t> col_idx((size_t)nnz);
    std::vector<int8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        for (int j = 0; j < colsA; ++j) {
            float x = Ai[j];
            if (x != 0.0f) { 
                int addr = base + off;
                col_idx[addr] = (int16_t)j;
                val[addr] = x;
                ++off;
            }
        }
    }
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (mkl): %.6f s\n",
    //    diff.count());
    // 2) zero C
    // std::memset(denseC, 0, sizeof(float) * (size_t)rowsA * (size_t)colsC);
    // #pragma omp parallel for num_threads(64) schedule(static)
    // for (int i = 0; i < rowsA; ++i) {
    //     float* row = denseC + (size_t)i * colsC;
    //     std::fill_n(row, colsC, 0.0f);
    // }

    // 3) tiling params
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;

    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 197, Kc = 96, Nb = 48;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 197, Kc = 96, Nb = 48;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }
    if(rowsA == 197 && colsA == 768 && colsC == 768){
        Rb = 128, Kc = 256, Nb = 32;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304 && density > 0.4){
        Rb = 104, Kc = 160, Nb = 72;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 2304 && density <= 0.4){
        Rb = 136, Kc = 152, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072 && density > 0.4){
        Rb = 48, Kc = 48, Nb = 224;
    }
    else if(rowsA == 197 && colsA == 768 && colsC == 3072 && density <= 0.4){
        Rb = 128, Kc = 512, Nb = 64;
    }
    else if(rowsA == 197 && colsA == 3072 && colsC == 768){
        Rb = 128, Kc = 512, Nb = 32;
    }


    // if (Rb > rowsA) Rb = rowsA;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }
    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::max(16, std::min(Nb, colsC));
    // Rb = std::max(1, std::min(Rb, rowsA));
    // printf("Kc=%d,Nb=%d,Rb=%d\n",Kc,Nb, Rb);

    if (density < 0.01){
        int vec_end = (colsC / VEC_WIDTH) * VEC_WIDTH;
        #pragma omp parallel for num_threads(64) schedule(static)
        for (int rb = 0; rb < rowsA; ++rb) {
            // float* B_row_buffer = (float*)portable_aligned_alloc(ACC_ALIGN, sizeof(float)*colsC);
            MKL_INT start = row_ptr[rb], end = row_ptr[rb + 1];
            if (start >= end)
                continue;
            // float* C_row_buffer = (float*)portable_aligned_alloc(ACC_ALIGN, sizeof(float)*colsC);
            float* Crow = denseC + (size_t)(rb) * (size_t)colsC;
            // memcpy(C_row_buffer, Crow, sizeof(float)*colsC);

            MKL_INT p = start;
            // singletons
            for (; p < end; ++p) {
                int16_t k_col = col_idx[p];
                float v = val[p];
                const float* Brow = denseB + (size_t)(k_col) * (size_t)colsC;
                // memcpy(B_row_buffer, Brow, sizeof(float)*colsC);
                __m256 vv = _mm256_set1_ps(v);
                int j = 0;
                for (; j < vec_end; j += VEC_WIDTH) {
                    __m256 accv = _mm256_loadu_ps(Crow + j);
                    __m256 bvec = _mm256_loadu_ps(Brow + j);
                    accv = _mm256_fmadd_ps(vv, bvec, accv);
                    _mm256_storeu_ps(Crow + j, accv);
                }
                if (vec_end < colsC) {
                    for (int jj = vec_end; jj < colsC; ++jj) Crow[jj] += v * Brow[jj];
                }
            } // singletons
        }
    }
    else{
        #pragma omp parallel for num_threads(64) schedule(dynamic) collapse(2)
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                // Pointers to avoid capturing vectors etc.
                const MKL_INT* row_ptr_p = row_ptr.data();
                const int16_t* col_idx_p = col_idx.data();
                const int8_t* val_p = val.data();
                float* denseB_p = denseB;
                float* denseC_p = denseC;

                int nb_eff = std::min(Nb, colsC - cb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
                size_t max_rb_eff = (size_t)std::min(Rb, rowsA);
                size_t acc_tile_max_elems = max_rb_eff * (size_t)acc_elems_per_row;
                void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, acc_tile_max_elems * sizeof(float));
                bool acc_tile_buf_portable = true;
                if (!acc_tile_buf_tmp) {
                    acc_tile_buf_tmp = malloc(acc_tile_max_elems * sizeof(float));
                    acc_tile_buf_portable = false;
                }
                float* acc_tile_buf = (float*)acc_tile_buf_tmp;

                size_t pack_elems = (size_t)Kc * (size_t)nb_eff;
                void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, pack_elems * sizeof(float));
                bool packed_portable = true;
                if (!packed_tmp) {
                    packed_tmp = malloc(pack_elems * sizeof(float));
                    packed_portable = false;
                }

                int rb_eff = std::min(Rb, rowsA - rb);
                float* acc_tile = acc_tile_buf; // prefix
                // init acc_tile from denseC (per-row memcpy)
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    int kblock_end = kb + kc_eff;

                    if (kc_eff == 0 || nb_eff == 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    float* packedB = (float*)packed_tmp;
                    
                    for (int kk = 0; kk < kc_eff; ++kk) {
                        const float* Brow = denseB_p + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                        float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                        memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                        // printf("byte=%ld\n",sizeof(float) * (size_t)nb_eff);
                    }

                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                        if (start >= end) continue;
                        int16_t* base = col_idx.data();
                        int16_t* s = base + start;
                        int16_t* e = base + end;

                        int16_t* p0 = std::lower_bound(s, e, kb);
                        MKL_INT it0 = (MKL_INT)(p0 - base);

                        int16_t* p1 = std::lower_bound(p0, e, kblock_end);
                        MKL_INT it1 = (MKL_INT)(p1 - base);

                        MKL_INT p = it0;
                        // singletons
                        for (; p < it1; ++p) {
                            int16_t k_col = col_idx_p[p];
                            float v = val_p[p];
                            const float* Brow = packedB + (size_t)(k_col - kb) * (size_t)nb_eff;
                            __m256 vv = _mm256_set1_ps(v);
                            int j = 0;
                            for (; j < vec_end; j += VEC_WIDTH) {
                                __m256 accv = _mm256_load_ps(acc_row + j);
                                __m256 bvec = _mm256_loadu_ps(Brow + j);
                                accv = _mm256_fmadd_ps(vv, bvec, accv);
                                _mm256_store_ps(acc_row + j, accv);
                            }
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow[jj];
                            }
                        } // singletons
                    }
                }
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_load_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
                if (packed_tmp) { if (packed_portable) portable_aligned_free(packed_tmp); else free(packed_tmp); }
                if (acc_tile) { if (acc_tile_buf_portable) portable_aligned_free(acc_tile); else free(acc_tile); }
            }
        }
    }

    return true;
}

uint8_t csr_value_encode(float A, float B, float C, float D) {
    int A1 = A > 0 ? 1 : 0;
    int B1 = B > 0 ? 1 : 0;
    int C1 = C > 0 ? 1 : 0;
    int D1 = D > 0 ? 1 : 0;

    int A2 = A < 0 ? 1 : 0;
    int B2 = B < 0 ? 1 : 0;
    int C2 = C < 0 ? 1 : 0;
    int D2 = D < 0 ? 1 : 0;

    uint8_t result; // 高4位是pos，低四位是neg
    result = ((A1 << 7) + (B1 << 6) + (C1 << 5) + (D1 << 4)) + ((A2 << 3) + (B2 << 2) + (C2 << 1) + D2);
    return result;
}


bool MKL_Sparse_CooXDense_Fast_Gustavson_jx_ternery_LUT_new(
    int8_t* denseA,
    float* denseB,
    float* denseC,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    // Step 1: Pre-calculate the required memory sizes
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 64;
    int numThreads = 64;

    // if(rowsA == 197 && colsA == 768 && colsC == 768){
    //     Rb = 128, Kc = 256, Nb = 32;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 2304){
    //     Rb = 128, Kc = 128, Nb = 64;
    // }
    // else if(rowsA == 197 && colsA == 768 && colsC == 3072){
    //     Rb = 128, Kc = 512, Nb = 64;
    // }
    // else if(rowsA == 197 && colsA == 3072 && colsC == 768){
    //     Rb = 128, Kc = 512, Nb = 32;
    // }

    if (Rb < 1) {
        Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
        Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    }
    Kc = std::max(8, std::min(Kc, colsA));
    Nb = std::max(16, std::min(Nb, colsC));
    Rb = std::max(1, std::min(Rb, rowsA));

    size_t pack_elems = (size_t)LWIDTH_POW2 * (size_t)Kc * (size_t)Nb;
    size_t acc_elems_per_row = ((Nb + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;   // 向上取整
    size_t acc_tile_max_elems = Rb * acc_elems_per_row;

    bool packed_portable = true, acc_tile_buf_portable= true;
    void* packed_tmp = portable_aligned_alloc(ACC_ALIGN, numThreads * pack_elems * sizeof(float));
    if (!packed_tmp) {
        packed_tmp = malloc(numThreads * pack_elems * sizeof(float)); // fall back if alignment fails
        packed_portable = false;
    }
    float* packedB = (float*)packed_tmp;

    void* acc_tile_buf_tmp = portable_aligned_alloc(ACC_ALIGN, numThreads * acc_tile_max_elems * sizeof(float));
    if (!acc_tile_buf_tmp) {
        acc_tile_buf_tmp = malloc(numThreads * acc_tile_max_elems * sizeof(float)); // fall back if alignment fails
        acc_tile_buf_portable = false;
    }
    float* acc_tile = (float*)acc_tile_buf_tmp;

    // Pre-compute `row_ptr`, `col_idx`, and `val` arrays outside the loop

    std::vector<int> rowCounts(rowsA, 0);
    #pragma omp parallel for num_threads(numThreads) schedule(static, 2)
    for (int i = 0; i < rowsA; ++i) {
        int c = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;
        // LWIDTH表示一组的数据个数。

        for (int j = 0; j < chunkColsA; ++j){
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;     // 组内全0则跳过存储
                }
            }
            if (nonZero) ++c;
        } 
        rowCounts[i] = c;
    }
    std::vector<MKL_INT> row_ptr(rowsA + 1, 0);
    for (int i = 0; i < rowsA; ++i) row_ptr[i + 1] = row_ptr[i] + rowCounts[i];
    MKL_INT nnz = row_ptr[rowsA];
    std::vector<MKL_INT> col_idx((size_t)nnz);
    std::vector<uint8_t> val((size_t)nnz);
    #pragma omp parallel for num_threads(64) schedule(static, 4)
    for (int i = 0; i < rowsA; ++i) {
        int base = row_ptr[i], off = 0;
        int8_t* Ai = denseA + (size_t)i * colsA;
        int chunkColsA = (colsA + LWIDTH - 1) / LWIDTH;

        for (int j = 0; j < chunkColsA; ++j) {
            bool nonZero = false;
            int j_begin = j * LWIDTH;
            int j_eff = std::min((j + 1) * LWIDTH, colsA);
            for (int jj = j_begin; jj < j_eff; ++jj) {
                if (Ai[jj] != 0) {
                    nonZero = true;
                }
            }
            if (nonZero) {
                int pos = base + off;
                col_idx[pos] = j;
                // 考虑不能被4整除的情况
                int t = std::min((j + 1) * LWIDTH, colsA) - j * LWIDTH;
                int jj = j * LWIDTH;
                // printf("Ai[jj]=%d, Ai[jj + 1]=%d, Ai[jj + 2]=%d, Ai[jj + 3]=%d\n",Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                if (t == LWIDTH)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], Ai[jj + 3]);
                else if (t == LWIDTH - 1)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], Ai[jj + 2], 0);
                else if (t == LWIDTH - 2)
                    val[pos] = csr_value_encode(Ai[jj], Ai[jj + 1], 0, 0);
                else if (t == LWIDTH - 3)
                    val[pos] = csr_value_encode(Ai[jj], 0, 0, 0);
                ++off;
            }
        }
    }
    colsA = (colsA + LWIDTH - 1) / LWIDTH; // calculation of colsA reduce LWIDTH times

    // 2) zero C
    // #pragma omp parallel for num_threads(numThreads) schedule(static)
    // for (int i = 0; i < rowsA; ++i) {
    //     float* row = denseC + (size_t)i * colsC;
    //     std::fill_n(row, colsC, 0.0f);
    // }

    // // printf("rowsA=%d,colsA=%d,colsC=%d,Kc=%d,Nb=%d,Rb=%d\n",rowsA,colsA,colsC,Kc,Nb, Rb);

    #pragma omp parallel for num_threads(numThreads) schedule(dynamic) collapse(2)
    for (int cb = 0; cb < colsC; cb += Nb) {      // B的列块放在最外层
        for (int kb = 0; kb < colsA; kb += Kc) {  // B的行块放在第二层
            // 预先加载B矩阵当前块到连续内存
            int tid = omp_get_thread_num();
            float *packedB_thread = packedB + tid * pack_elems;
            float *acc_tile_thread = acc_tile + tid * acc_tile_max_elems;

            int nb_eff = std::min(Nb, colsC - cb);
            int kc_eff = std::min(Kc, colsA - kb);

            // 打包B矩阵当前块
            for (int lut_idx = 0; lut_idx < LWIDTH_POW2; ++lut_idx) {
                for (int kk = 0; kk < kc_eff; ++kk) {
                    const float* Brow = denseB + (size_t)lut_idx * (size_t)colsA * (size_t)colsC + 
                                        (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    float* dest = packedB_thread + (size_t)lut_idx * (size_t)Kc * (size_t)Nb + 
                                  (size_t)kk * (size_t)Nb;
                    if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                }
            }

            // Step 5: Process A's row blocks (unchanged from original)
            for (int rb = 0; rb < rowsA; rb += Rb) {
                const MKL_INT* row_ptr_p = row_ptr.data();
                const MKL_INT* col_idx_p = col_idx.data();
                const uint8_t* val_p = val.data();
                float* denseC_p = denseC;

                int rb_eff = std::min(Rb, rowsA - rb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;   // 向下取整

                // 初始化累加器
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile_thread + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // 处理当前A行块和B块的乘法
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* acc_row = acc_tile_thread + (size_t)local_i * (size_t)acc_elems_per_row;

                    MKL_INT start = row_ptr[i], end = row_ptr[i + 1];
                    if (start >= end) continue;
                    
                    MKL_INT* base = col_idx.data();
                    MKL_INT* s = base + start;
                    MKL_INT* e = base + end;

                    MKL_INT* p0 = std::lower_bound(s, e, kb);   // 二分查找当前行列号大等于kb的最小值
                    MKL_INT it0 = (MKL_INT)(p0 - base);

                    MKL_INT* p1 = std::lower_bound(p0, e, kb + kc_eff);
                    MKL_INT it1 = (MKL_INT)(p1 - base);

                    // 若当前块中不存在非零元素，则it0 = it1, 不进入循环
                    for (MKL_INT p = it0; p < it1; ++p) {
                        MKL_INT k_col = col_idx_p[p];
                        uint8_t v = val_p[p];
                        uint8_t pos_idx = (v >> LWIDTH) & 0x0F;   // 高位存正数
                        uint8_t neg_idx = v & 0x0F;   // 低位存负数
                        
                        const float* Brow_pos = packedB_thread + (size_t)pos_idx * (size_t)Kc * (size_t)Nb + 
                                            (size_t)(k_col - kb) * (size_t)Nb;
                        const float* Brow_neg = packedB_thread + (size_t)neg_idx * (size_t)Kc * (size_t)Nb + 
                                            (size_t)(k_col - kb) * (size_t)Nb;

                        int j = 0;
                        for (; j < vec_end; j += VEC_WIDTH) {
                            __m256 accv = _mm256_load_ps(acc_row + j);
                            __m256 bvec_pos = _mm256_load_ps(Brow_pos + j);
                            __m256 bvec_neg = _mm256_load_ps(Brow_neg + j);
                            accv = _mm256_add_ps(accv, _mm256_sub_ps(bvec_pos, bvec_neg));
                            _mm256_store_ps(acc_row + j, accv);
                        }
                        for (int jj = vec_end; jj < nb_eff; ++jj) {
                            acc_row[jj] += Brow_pos[jj] - Brow_neg[jj];
                        }
                    }
                }

                // 写回结果
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile_thread + (size_t)local_i * (size_t)acc_elems_per_row;
                    
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_load_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
            }
        }
    }

    if (packed_tmp) { 
        if (packed_portable) portable_aligned_free(packed_tmp); 
        else free(packed_tmp); 
    }
    if (acc_tile_buf_tmp) { 
        if (acc_tile_buf_portable) portable_aligned_free(acc_tile_buf_tmp); 
        else free(acc_tile_buf_tmp); 
    }

    return true;
}




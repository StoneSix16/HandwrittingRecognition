from torch.utils.cpp_extension import load
import torch

# 1. 编译并加载扩展
mkl_linear = load(
    name="linear_naive",
    sources=["linear_pytorch.cpp"],
    extra_ldflags=["-ldnnl"],  # 如果不使用 oneDNN，可以删掉这行
    verbose=True,
)

# 2. 构造输入数据
batch_size    = 8
in_features   = 128
out_features  = 64

x = torch.randn(batch_size, in_features, dtype=torch.float32)
w = torch.randn(out_features, in_features, dtype=torch.float32)
b = torch.randn(out_features, dtype=torch.float32)

# 3. 调用自定义的 mkl_linear
#    签名：mkl_linear(Tensor input, Tensor weight, Tensor? bias) -> Tensor
out = torch.ops.custom.custom_linear(x, w, b, False)

# 4. 对比 PyTorch 内置 linear 的结果
out_true = torch.nn.functional.linear(x, w, b)

# 5. 验证两者输出是否一致
match = torch.allclose(out, out_true, rtol=1e-3, atol=1e-5)
print(f"Match with bias: {match}")
print("out.shape      :", out.shape)
print("out_true.shape :", out_true.shape)

# 6. 测试无 bias 的情况
out_nb      = torch.ops.custom.custom_linear(x, w, None, False)
out_true_nb = torch.nn.functional.linear(x, w, None)
match_nb = torch.allclose(out_nb, out_true_nb, rtol=1e-3, atol=1e-5)
print(f"Match without bias: {match_nb}")
print("out_nb.shape      :", out_nb.shape)
print("out_true_nb.shape :", out_true_nb.shape)

# 6. 测试有 bias 带ReLU 的情况
out = torch.ops.custom.custom_linear(x, w, b, True)
out_true = torch.nn.functional.linear(x, w, b)
out_true = torch.nn.functional.gelu(out_true)
match = torch.allclose(out, out_true, rtol=1e-3, atol=1e-5)
print(f"Match with bias fuse ReLU: {match}")
print("out.shape      :", out.shape)
print("out_true.shape :", out_true.shape)

# 6. 测试无 bias 带ReLU 的情况
out = torch.ops.custom.custom_linear(x, w, None, True)
out_true = torch.nn.functional.linear(x, w, None)
out_true = torch.nn.functional.gelu(out_true)
match = torch.allclose(out, out_true, rtol=1e-3, atol=1e-5)
print(f"Match without bias fuse ReLU: {match}")
print("out.shape      :", out.shape)
print("out_true.shape :", out_true.shape)

#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <chrono>
#include <cmath>
#include <immintrin.h>
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <cstdio>
#include <vector>
#include <algorithm>
#include <chrono>
#include <omp.h>
#include <mkl.h>
#include <mkl_spblas.h>

#define MAX_THREAD 16
#define LWIDTH 4
#define LWIDTH_POW2 16
constexpr int L1_BYTES = 32 * 1024;
constexpr int L2_BYTES = 1024 * 1024;
constexpr int VEC_WIDTH = 8;         // AVX2: 8 floats
constexpr int VEC_WIDTH3 = 24;         // AVX2: 8 floats
constexpr int VEC_WIDTH4 = 32;         // AVX2: 8 floats
constexpr size_t ACC_ALIGN = 64;
constexpr int PREFETCH_P = 4;


static inline void* portable_aligned_alloc(size_t alignment, size_t size) {
    if (size == 0) return nullptr;
    size_t extra = alignment - 1 + sizeof(void*);
    void* raw = malloc(size + extra);
    if (!raw) return nullptr;
    uintptr_t raw_addr = (uintptr_t)raw + sizeof(void*);
    uintptr_t aligned = (raw_addr + (alignment - 1)) & ~(alignment - 1);
    void** store = (void**)(aligned - sizeof(void*));
    *store = raw;
    return (void*)aligned;
}
static inline void portable_aligned_free(void* p) {
    if (!p) return;
    void** store = (void**)((uintptr_t)p - sizeof(void*));
    void* raw = *store;
    free(raw);
}

bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk(
    float* denseA1,   // [batch][rowsA][colsA]
    float* denseB1,   // [batch][colsA][colsC]
    float* denseA2,   // [batch][rowsA][colsA]
    float* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);

bool GEMM_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/);
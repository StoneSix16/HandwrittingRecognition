#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <chrono>
#include "custom_spike_attention.h"

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
torch::Tensor custom_spike_attention(
    torch::Tensor x1_sum,
    torch::Tensor x2,
    torch::Tensor x1,
    torch::Tensor x2_sum) 
{
    // 简单检查（CPU + dtype）
    // auto t_start = std::chrono::steady_clock::now();
    TORCH_CHECK(x1_sum.device().is_cpu(), "x1_sum must be CPU tensor");
    TORCH_CHECK(x2.device().is_cpu(), "x2 must be CPU tensor");
    TORCH_CHECK(x1.device().is_cpu(), "x1 must be CPU tensor");
    TORCH_CHECK(x2_sum.device().is_cpu(), "x2_sum must be CPU tensor");

    TORCH_CHECK(x1_sum.dtype() == torch::kFloat32, "x1_sum must be float32");
    TORCH_CHECK(x2.dtype() == torch::kFloat32, "x2 must be float32");
    TORCH_CHECK(x1.dtype() == torch::kFloat32, "x1 must be float32");
    TORCH_CHECK(x2_sum.dtype() == torch::kFloat32, "x2_sum must be float32");
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (check): %.6f s\n",
    //    diff.count());


    // t_start = std::chrono::steady_clock::now();
    int B = x1_sum.size(0);
    int M = x1_sum.size(1);
    int K = x1_sum.size(2);
    int N = x2.size(2);
    // Work on contiguous memory. If original is contiguous, operate directly.
    // Otherwise make a contiguous temp, run kernel, then copy back so Python sees changes.
    bool x1_sum_cont = x1_sum.is_contiguous();
    bool x2_cont = x2.is_contiguous();
    bool x1_cont = x1.is_contiguous();
    bool x2_sum_cont = x2_sum.is_contiguous();
    // printf("input_cont=%d, q_cont=%d, acc_cont=%d\n",input_cont,q_cont,acc_cont);

    torch::Tensor x1_sum_c = x1_sum_cont ? x1_sum : x1_sum.contiguous();
    torch::Tensor x2_c     = x2_cont     ? x2     : x2.contiguous();
    torch::Tensor x1_c = x1_cont ? x1 : x1.contiguous();
    torch::Tensor x2_sum_c     = x2_sum_cont     ? x2_sum     : x2_sum.contiguous();
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (contiguous): %.6f s\n",
    //    diff.count());
    
    // t_start = std::chrono::steady_clock::now();
    auto output = torch::empty({B, M, N}, x1_sum_c.options()); 
    float* C = output.data_ptr<float>(); 
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static) 
    for (int b = 0; b < B; ++b) { 
        for (int i = 0; i < M; ++i) { 
            float* row = C + (size_t)i * N + (size_t)b * (size_t)M * (size_t)N; 
            memset(row, 0, N * sizeof(float)); } 
        }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (clear C): %.6f s\n",
    //    diff.count());

    // call your C kernel (ensure types match)
    // t_start = std::chrono::steady_clock::now();
    Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk(
        x1_sum_c.data_ptr<float>(), x2_c.data_ptr<float>(),
        x1_c.data_ptr<float>(), x2_sum_c.data_ptr<float>(),
        output.data_ptr<float>(),
        B,M,K,N,0
    );
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (calculation): %.6f s\n",
    //    diff.count());
    return output;
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_spike_attention(Tensor x1_sum, Tensor x2, Tensor x1, Tensor x2_sum) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_spike_attention", TORCH_FN(custom_spike_attention));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_spike_attention",
          &custom_spike_attention,
          "custom_spike_attention(Tensor x1_sum, Tensor x2, Tensor x1, Tensor x2_sum) -> output",
          py::arg("x1_sum"),
          py::arg("x2"),
          py::arg("x1"),
          py::arg("x2_sum")
    );
}

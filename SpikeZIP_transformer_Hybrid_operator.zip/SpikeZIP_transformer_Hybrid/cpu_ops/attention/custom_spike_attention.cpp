#include "custom_spike_attention.h"

bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk(
    float* denseA1,   // [batch][rowsA][colsA]
    float* denseB1,   // [batch][colsA][colsC]
    float* denseA2,   // [batch][rowsA][colsA]
    float* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;
    
    // Precompute tiling parameters (global)
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 8;
    // if (Rb < 1) {
    //     Kc = std::max<int>(8, target_bytes / (4 * std::max(1, Nb)) - 1);
    //     Rb = std::max<int>(1, static_cast<int>(target_bytes / (4 * std::max(1, Nb))) - Kc);
    // }

    // if (rowsA == 197 && colsA == 64 && colsC == 197){
    //     Kc = 64, Nb = std::min(colsC, 64); Rb = 4;
    // }
    // else if(rowsA == 197 && colsA == 197 && colsC == 64){
    //     Kc = 64, Nb = std::min(colsC, 64); Rb = 4;
    // }

    // Kc = std::max(8, std::min(Kc, colsA));
    // Nb = std::min(colsC, std::max(16, Nb));
    // Rb = std::max(1, std::min(Rb, rowsA));

    // auto t_start = std::chrono::steady_clock::now();
    // -------- Allocate per-batch containers (vectors) ----------
    // B1 CSR: rows = colsA, cols = colsC  (one CSR per batch)
    // std::vector<std::vector<int>> rowCounts1_batch(batch, std::vector<int>(colsA));
    int16_t* rowCounts1_batch = (int16_t*)malloc(sizeof(int16_t) * batch * colsA);
    MKL_INT* row_ptr1_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (colsA + 1));
    // std::vector<std::vector<MKL_INT>> row_ptr1_batch(batch);
    std::vector<std::vector<int16_t>> col_idx1_batch(batch);
    std::vector<std::vector<float>>   val1_batch(batch);

    // A2 CSR: rows = rowsA, cols = colsA (one CSR per batch)
    // std::vector<std::vector<int>> rowCounts2_batch(batch, std::vector<int>(rowsA));
    int16_t* rowCounts2_batch = (int16_t*)malloc(sizeof(int16_t) * batch * rowsA);
    MKL_INT* row_ptr2_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (rowsA + 1));
    // std::vector<std::vector<MKL_INT>> row_ptr2_batch(batch);
    std::vector<std::vector<int16_t>> col_idx2_batch(batch);
    std::vector<std::vector<float>>   val2_batch(batch);
    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (define variables): %.6f s\n",
    //    diff.count());

    // --- Step 1: compute rowCounts for B1 and A2 in parallel (collapse over batch & row) ---
    // B1 rowCounts: iterate over (b, i) where i in [0, colsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < colsA; ++i) {
            int cnt = 0;
            float* Bi = denseB1 + (size_t)b * (size_t)colsA * (size_t)colsC + (size_t)i * (size_t)colsC;
            for (int j = 0; j < colsC; ++j) if (Bi[j] != 0.0f) ++cnt;
            rowCounts1_batch[b*colsA+i] = cnt;
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (compute rowCounts for B1): %.6f s\n",
    //    diff.count());


    // A2 rowCounts: iterate over (b, i) where i in [0, rowsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            int cnt = 0;
            float* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) if (Ai[j] != 0.0f) ++cnt;
            rowCounts2_batch[b*rowsA + i] = cnt;
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (compute rowCounts for A2): %.6f s\n",
    //    diff.count());

    // --- Step 2: build row_ptr arrays and allocate col_idx/val per batch (parallel over b) ---
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        // B1
        // row_ptr1_batch[b].resize(colsA + 1);
        row_ptr1_batch[b*(colsA + 1)] = 0;
        for (int i = 0; i < colsA; ++i) row_ptr1_batch[b*(colsA + 1) + i+1] = row_ptr1_batch[b*(colsA + 1) + i] + rowCounts1_batch[b*colsA+i];
        MKL_INT nnz1 = row_ptr1_batch[b*(colsA + 1) + colsA];
        col_idx1_batch[b].assign((size_t)nnz1, 0);
        val1_batch[b].assign((size_t)nnz1, 0.0f);

        // A2
        // row_ptr2_batch[b].resize(rowsA + 1);
        row_ptr2_batch[b * (rowsA + 1)] = 0;
        for (int i = 0; i < rowsA; ++i) row_ptr2_batch[b * (rowsA + 1) + i+1] = row_ptr2_batch[b * (rowsA + 1) + i] + rowCounts2_batch[b*rowsA + i];
        MKL_INT nnz2 = row_ptr2_batch[b * (rowsA + 1) + rowsA];
        col_idx2_batch[b].assign((size_t)nnz2, 0);
        val2_batch[b].assign((size_t)nnz2, 0.0f);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (count nnz): %.6f s\n",
    //    diff.count());

    // --- Step 3: fill col_idx/val for B1 and A2 in parallel (collapse to distribute work) ---
    // fill B1 CSR: iterate (b, i in colsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < colsA; ++i) {
            MKL_INT base = row_ptr1_batch[b*(colsA + 1) + i];
            int off = 0;
            float* Bi = denseB1 + (size_t)b * (size_t)colsA * (size_t)colsC + (size_t)i * (size_t)colsC;
            for (int j = 0; j < colsC; ++j) {
                float x = Bi[j];
                if (x != 0.0f) {
                    MKL_INT idx = base + off++;
                    col_idx1_batch[b][idx] = (MKL_INT)j;
                    val1_batch[b][idx] = x;
                }
            }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (fill col_idx/val for B1): %.6f s\n",
    //    diff.count());

    // fill A2 CSR: iterate (b, i in rowsA)
    // t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            MKL_INT base = row_ptr2_batch[b * (rowsA + 1) + i];
            int off = 0;
            float* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) {
                float x = Ai[j];
                if (x != 0.0f) {
                    MKL_INT idx = base + off++;
                    col_idx2_batch[b][idx] = (MKL_INT)j;
                    val2_batch[b][idx] = x;
                }
            }
        }
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (fill col_idx/val for A2): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
    // --- zero out denseC (per-batch, per-row) ---
    // #pragma omp parallel num_threads(64)
    // {
    //     int nt = omp_get_num_threads();
    //     // 可选：根据情况只用 min(nt, batch)
    //     #pragma omp for schedule(static)
    //     for (int b = 0; b < batch; ++b) {
    //         float* Cb = denseC + (size_t)b * (size_t)rowsA * (size_t)colsC;
    //         for (int i = 0; i < rowsA; ++i) {
    //             float* Crow = Cb + (size_t)i * (size_t)colsC;
    //             memset(Crow, 0, (size_t)colsC * sizeof(float));
    //         }
    //     }
    // }

    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (zero denseC): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
    // --- Preallocate per-thread temporary buffers to avoid repeated malloc/free ---
    int num_threads = 64;
    // std::vector<void*> thread_packedA(num_threads, nullptr);
    // std::vector<void*> thread_packedB(num_threads, nullptr);
    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    // std::vector<size_t> thread_packedA_size(num_threads, 0);
    // std::vector<size_t> thread_packedB_size(num_threads, 0);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    size_t max_packA_elems = (size_t)Kc * (size_t)Rb; // packedA capacity per thread (rows x Kc)
    size_t max_packB_elems = (size_t)Kc * (size_t)Nb; // packedB capacity per thread (Kc x Nb)
    int max_acc_elems_per_row = ((Nb + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;
    
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        // size_t bytesA = max_packA_elems * sizeof(float);
        // void* pA = portable_aligned_alloc(ACC_ALIGN, bytesA);
        // if (!pA) pA = malloc(bytesA);
        // thread_packedA[t] = pA; thread_packedA_size[t] = bytesA;

        // size_t bytesB = max_packB_elems * sizeof(float);
        // void* pB = portable_aligned_alloc(ACC_ALIGN, bytesB);
        // if (!pB) pB = malloc(bytesB);
        // thread_packedB[t] = pB; thread_packedB_size[t] = bytesB;

        size_t bytesAcc = max_acc_tile_elems * sizeof(float);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc; thread_acc_tile_size[t] = bytesAcc;
    }

    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (C packing): %.6f s\n",
    //    diff.count());

    // t_start = std::chrono::steady_clock::now();
       // -------- Main compute: parallelize over (b, rb) to cover batch and row-blocks ----------
    #pragma omp parallel for collapse(2) num_threads(64) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                // pointer bases for this batch
                float* denseA_p1 = denseA1 + (size_t)b * (size_t)rowsA * (size_t)colsA;
                float* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                const MKL_INT* row_ptr_p1 = row_ptr1_batch + b*(colsA + 1);
                const int16_t* col_idx_p1 = col_idx1_batch[b].data();
                const float*   val_p1     = val1_batch[b].data();

                const MKL_INT* row_ptr_p2 = row_ptr2_batch + b * (rowsA + 1);
                const int16_t* col_idx_p2 = col_idx2_batch[b].data();
                const float*   val_p2     = val2_batch[b].data();

                int rb_eff = std::min(Rb, rowsA - rb);

                // local per-thread buffers (preallocated)
                // float* packedA = (float*)thread_packedA[tid];
                // float* packedB = (float*)thread_packedB[tid];
                float* acc_tile = (float*)thread_acc_tile[tid];


                int nb_eff = std::min(Nb, colsC - cb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;

                // init acc_tile from C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // loop over k-blocks
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0 || nb_eff == 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    // pack B2 block: kc_eff x nb_eff into packedB
                    // for (int kk = 0; kk < kc_eff; ++kk) {
                    //     const float* Brow = denseB_p2 + (size_t)(kb + kk) * (size_t)colsC + (size_t)cb;
                    //     float* dest = packedB + (size_t)kk * (size_t)nb_eff;
                    //     if (nb_eff > 0) memcpy(dest, Brow, sizeof(float) * (size_t)nb_eff);
                    // }

                    // pack A1 rows for this tile: rb_eff x kc_eff (stride = kc_eff)
                    // for (int mm = 0; mm < rb_eff; ++mm) {
                    //     const float* Arow = denseA_p1 + (size_t)(rb + mm) * (size_t)colsA + (size_t)kb;
                    //     float* dest = packedA + (size_t)mm * (size_t)kc_eff;
                    //     if (kc_eff > 0) memcpy(dest, Arow, sizeof(float) * (size_t)kc_eff);
                    // }

                    // --- Row-major calculation using A2 CSR and packedB ---
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr_p2[i], end = row_ptr_p2[i + 1];
                        if (start >= end) continue;
                        const int16_t* base = col_idx_p2;
                        const int16_t* s = base + start;
                        const int16_t* e = base + end;

                        const int16_t* p0ptr = std::lower_bound(s, e, (MKL_INT)kb);
                        const int16_t* p1ptr = std::lower_bound(p0ptr, e, (MKL_INT)(kb + kc_eff));
                        if (p0ptr == p1ptr) continue;
                        MKL_INT it0 = (MKL_INT)(p0ptr - base);
                        MKL_INT it1 = (MKL_INT)(p1ptr - base);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p2[p];
                            float v = val_p2[p];
                            int k_rel = (int)(k_col - kb);
                            if (k_rel < 0 || k_rel >= kc_eff) continue;
                            // const float* Brow = packedB + (size_t)k_rel * (size_t)nb_eff;
                            const float* Brow_global = denseB_p2 + (size_t)k_col * (size_t)colsC + (size_t)cb;
                            __m256 vv = _mm256_set1_ps(v);
                            int j = 0;
                            for (; j < vec_end; j += VEC_WIDTH) {
                                __m256 accv = _mm256_loadu_ps(acc_row + j);
                                __m256 bvec = _mm256_loadu_ps(Brow_global + j);
                                accv = _mm256_fmadd_ps(vv, bvec, accv);
                                _mm256_storeu_ps(acc_row + j, accv);
                            }
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) acc_row[jj] += v * Brow_global[jj];
                            }
                        }
                    }

                    // --- Col-major calculation using B1 CSR and packedA ---
                    for (int local_k = 0; local_k < kc_eff; ++local_k) {
                        int global_k = kb + local_k;
                        MKL_INT p_start = row_ptr_p1[global_k];
                        MKL_INT p_end   = row_ptr_p1[global_k + 1];
                        MKL_INT row_nnz = p_end - p_start;
                        if (row_nnz <= 0) continue;

                        const int16_t* base = col_idx_p1 + p_start;
                        const int16_t* p0 = std::lower_bound(base, base + row_nnz, (MKL_INT)cb);
                        const int16_t* p1 = std::lower_bound(p0, base + row_nnz, (MKL_INT)(cb + nb_eff));
                        if (p0 == p1) continue;
                        MKL_INT it0 = (MKL_INT)(p0 - col_idx_p1);
                        MKL_INT it1 = (MKL_INT)(p1 - col_idx_p1);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT jidx = col_idx_p1[p];
                            int dst = (int)(jidx - cb);
                            float vb = val_p1[p];
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                // float A_value = packedA[(size_t)local_i * (size_t)kc_eff + (size_t)local_k];
                                const float* Arow_global = denseA_p1 + (size_t)(rb + local_i) * (size_t)colsA;
                                float A_value = Arow_global[(size_t)kb + (size_t)local_k]; // element A[rb+local_i, kb+local_k]
                                float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                                acc_row[dst] += A_value * vb;
                            }
                        }
                    }
                } // kb

                // write back acc_tile into C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_loadu_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
            } // cb
        } // rb
    } // parallel over (b, rb)
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (computing): %.6f s\n",
    //    diff.count());
    
    // t_start = std::chrono::steady_clock::now();
    // free per-thread buffers
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        // if (thread_packedA[t]) portable_aligned_free(thread_packedA[t]);
        // if (thread_packedB[t]) portable_aligned_free(thread_packedB[t]);
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (free C): %.6f s\n",
    //    diff.count());

    return true;
}

// Main function: batch-parallel Gustavson-like fused A1@B1 + A2@B2
bool Sparse_CSRXDense_Fast_Gustavson_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;
    
    // Precompute tiling parameters (global)
    const double util_ratio = 0.5;
    const int target_bytes = static_cast<int>(L1_BYTES * util_ratio);
    int Kc = 64, Nb = std::min(colsC, 64);
    int Rb = 8;

    int16_t* rowCounts2_batch = (int16_t*)malloc(sizeof(int16_t) * batch * rowsA);
    MKL_INT* row_ptr2_batch = (MKL_INT*)malloc(sizeof(MKL_INT) * batch * (rowsA + 1));
    std::vector<std::vector<int16_t>> col_idx2_batch(batch);
    std::vector<std::vector<int8_t>>   val2_batch(batch);

    auto t_start = std::chrono::steady_clock::now();
    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            int cnt = 0;
            int8_t* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) if (Ai[j] != int8_t(0)) ++cnt;
            rowCounts2_batch[b*rowsA + i] = cnt;
        }
    }

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        // A2
        // row_ptr2_batch[b].resize(rowsA + 1);
        row_ptr2_batch[b * (rowsA + 1)] = 0;
        for (int i = 0; i < rowsA; ++i) row_ptr2_batch[b * (rowsA + 1) + i+1] = row_ptr2_batch[b * (rowsA + 1) + i] + rowCounts2_batch[b*rowsA + i];
        MKL_INT nnz2 = row_ptr2_batch[b * (rowsA + 1) + rowsA];
        col_idx2_batch[b].assign((size_t)nnz2, 0);
        val2_batch[b].assign((size_t)nnz2, int8_t(0));
    }

    #pragma omp parallel for collapse(2) num_threads(64) schedule(static)
    for (int b = 0; b < batch; ++b) {
        for (int i = 0; i < rowsA; ++i) {
            MKL_INT base = row_ptr2_batch[b * (rowsA + 1) + i];
            int off = 0;
            int8_t* Ai = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA + (size_t)i * (size_t)colsA;
            for (int j = 0; j < colsA; ++j) {
                int8_t x = Ai[j];
                if (x != int8_t(0)) {
                    MKL_INT idx = base + off++;
                    col_idx2_batch[b][idx] = (MKL_INT)j;
                    val2_batch[b][idx] = x;
                }
            }
        }
    }
    auto t_end = std::chrono::steady_clock::now();
    std::chrono::duration<double> diff = t_end - t_start;
    printf("Sparse×Dense (build CSR): %.6f s\n",
       diff.count());
    // #pragma omp parallel num_threads(64)
    // {
    //     int nt = omp_get_num_threads();
    //     // 可选：根据情况只用 min(nt, batch)
    //     #pragma omp for schedule(static)
    //     for (int b = 0; b < batch; ++b) {
    //         float* Cb = denseC + (size_t)b * (size_t)rowsA * (size_t)colsC;
    //         for (int i = 0; i < rowsA; ++i) {
    //             float* Crow = Cb + (size_t)i * (size_t)colsC;
    //             memset(Crow, 0, (size_t)colsC * sizeof(float));
    //         }
    //     }
    // }

    // --- Preallocate per-thread temporary buffers to avoid repeated malloc/free ---
    int num_threads = 64;
    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    size_t max_packA_elems = (size_t)Kc * (size_t)Rb; // packedA capacity per thread (rows x Kc)
    size_t max_packB_elems = (size_t)Kc * (size_t)Nb; // packedB capacity per thread (Kc x Nb)
    int max_acc_elems_per_row = ((Nb + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;
    
    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        size_t bytesAcc = max_acc_tile_elems * sizeof(float);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc; thread_acc_tile_size[t] = bytesAcc;
    }

    #pragma omp parallel for collapse(2) num_threads(64) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                // pointer bases for this batch
                int8_t* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                const MKL_INT* row_ptr_p2 = row_ptr2_batch + b * (rowsA + 1);
                const int16_t* col_idx_p2 = col_idx2_batch[b].data();
                const int8_t*   val_p2     = val2_batch[b].data();

                int rb_eff = std::min(Rb, rowsA - rb);

                float* acc_tile = (float*)thread_acc_tile[tid];


                int nb_eff = std::min(Nb, colsC - cb);
                int vec_end = (nb_eff / VEC_WIDTH) * VEC_WIDTH;
                int acc_elems_per_row = ((nb_eff + VEC_WIDTH - 1) / VEC_WIDTH) * VEC_WIDTH;

                // init acc_tile from C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    if (nb_eff > 0) memcpy(dest_row, Crow, sizeof(float) * (size_t)nb_eff);
                    for (int t = nb_eff; t < acc_elems_per_row; ++t) dest_row[t] = 0.0f;
                }

                // loop over k-blocks
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0 || nb_eff == 0) continue;
                    if ((size_t)kc_eff > SIZE_MAX / (size_t)nb_eff) continue;

                    // --- Row-major calculation using A2 CSR and packedB ---
                    for (int local_i = 0; local_i < rb_eff; ++local_i) {
                        int i = rb + local_i;
                        float* acc_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                        MKL_INT start = row_ptr_p2[i], end = row_ptr_p2[i + 1];
                        if (start >= end) continue;
                        const int16_t* base = col_idx_p2;
                        const int16_t* s = base + start;
                        const int16_t* e = base + end;

                        const int16_t* p0ptr = std::lower_bound(s, e, (MKL_INT)kb);
                        const int16_t* p1ptr = std::lower_bound(p0ptr, e, (MKL_INT)(kb + kc_eff));
                        if (p0ptr == p1ptr) continue;
                        MKL_INT it0 = (MKL_INT)(p0ptr - base);
                        MKL_INT it1 = (MKL_INT)(p1ptr - base);

                        for (MKL_INT p = it0; p < it1; ++p) {
                            MKL_INT k_col = col_idx_p2[p];
                            int8_t v = val_p2[p];
                            int k_rel = (int)(k_col - kb);
                            if (k_rel < 0 || k_rel >= kc_eff) continue;

                            // B 在全局布局为 denseB_p2 [colsA x colsC], 取第 k_col 行起始处再偏移 cb
                            const int8_t* Brow_global = (const int8_t*)(denseB_p2 + (size_t)k_col * (size_t)colsC + (size_t)cb);

                            // 把标量 v 转为 float 向量
                            __m256 vv_f = _mm256_set1_ps((float)v);

                            int j = 0;
                            // vec_end 预先计算为 nb_eff - (nb_eff % VEC_WIDTH)
                            for (; j < vec_end; j += VEC_WIDTH) {
                                // load 8 int8 bytes from Brow_global + j
                                __m128i b8 = _mm_loadl_epi64((const __m128i*)(Brow_global + j)); // loads 8 bytes into low 64 bits
                                // widen int8 -> int32 (8 lanes)
                                __m256i b32 = _mm256_cvtepi8_epi32(b8);
                                // convert int32 -> float
                                __m256 b_f = _mm256_cvtepi32_ps(b32);

                                // load acc_row (float) and fmadd: acc += v * b
                                __m256 accv = _mm256_loadu_ps(acc_row + j);
                                accv = _mm256_fmadd_ps(vv_f, b_f, accv);
                                _mm256_storeu_ps(acc_row + j, accv);
                            }

                            // tail scalar
                            if (vec_end < nb_eff) {
                                for (int jj = vec_end; jj < nb_eff; ++jj) {
                                    acc_row[jj] += (float)v * (float)Brow_global[jj];
                                }
                            }
                        }
                    }
                } // kb
                // write back acc_tile into C_b
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    float* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    int j = 0;
                    for (; j + VEC_WIDTH - 1 < nb_eff; j += VEC_WIDTH) {
                        __m256 tmpv = _mm256_loadu_ps(src_row + j);
                        _mm256_storeu_ps(Crow + j, tmpv);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = src_row[j];
                }
            } // cb
        } // rb
    } // parallel over (b, rb)

    #pragma omp parallel for num_threads(64) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }

    return true;
}

// Main function: batch-parallel Gustavson-like fused A1@B1 + A2@B2
bool GEMM_Batch_Attention_yk_int(
    int8_t* denseA2,   // [batch][rowsA][colsA]
    int8_t* denseB2,   // [batch][colsA][colsC]
    float* denseC,    // [batch][rowsA][colsC]
    int batch,
    int rowsA,
    int colsA,
    int colsC,
    int /*flag*/)
{
    if (batch <= 0) return true;

    #ifdef MKL_MAJOR_VERSION
    mkl_set_num_threads(1);
    #endif

    int Kc = 197, Nb = std::min(colsC, 128);
    int Rb = 8;

    if(rowsA == 197 && colsA == 128 && colsC == 197){
        Rb = 8, Kc = 128, Nb = 197;
    }
    else if(rowsA == 197 && colsA == 197 && colsC == 128){
        Rb = 16, Kc = 197, Nb = 128;
    }
    int num_threads = 64;

    const int MADDUBS_PAIR_OUT = 32; // 每次 _mm512_maddubs 处理后对应 32 列输出 (64 bytes in)
    const int BYTES_PER_LOAD = 64;   // 64 bytes per _mm512_loadu_si512 for packed pairs

    // 每线程 acc tile (int32)
    int max_acc_elems_per_row = ((Nb + 15) / 16) * 16; // 16 alignment for safeness
    size_t max_acc_tile_elems = (size_t)Rb * (size_t)max_acc_elems_per_row;

    std::vector<void*> thread_acc_tile(num_threads, nullptr);
    std::vector<size_t> thread_acc_tile_size(num_threads, 0);

    #pragma omp parallel for num_threads(num_threads) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        size_t bytesAcc = max_acc_tile_elems * sizeof(int32_t);
        void* pAcc = portable_aligned_alloc(ACC_ALIGN, bytesAcc);
        if (!pAcc) pAcc = malloc(bytesAcc);
        thread_acc_tile[t] = pAcc;
        thread_acc_tile_size[t] = bytesAcc;
        if (pAcc) memset(pAcc, 0, bytesAcc);
    }

    // constants used in inner kernel
    const __m512i xor_0x80_8 = _mm512_set1_epi8((char)0x80); // for unsigned conversion trick
    const __m512i ones8 = _mm512_set1_epi8((char)1);         // for pair sum via maddubs
    const __m512i zero512 = _mm512_setzero_si512();
    const __mmask64 alt_mask = 0xAAAAAAAAAAAAAAAAULL; // alternate bytes mask: 1 on odd bytes

    #pragma omp parallel for collapse(2) num_threads(num_threads) schedule(dynamic)
    for (int b = 0; b < batch; ++b) {
        for (int rb = 0; rb < rowsA; rb += Rb) {
            for (int cb = 0; cb < colsC; cb += Nb) {
                int tid = omp_get_thread_num();

                int8_t* denseA_p2 = denseA2 + (size_t)b * (size_t)rowsA * (size_t)colsA;
                int8_t* denseB_p2 = denseB2 + (size_t)b * (size_t)colsA * (size_t)colsC;
                float* denseC_p  = denseC  + (size_t)b * (size_t)rowsA * (size_t)colsC;

                int rb_eff = std::min(Rb, rowsA - rb);
                int32_t* acc_tile = (int32_t*)thread_acc_tile[tid];

                int nb_eff = std::min(Nb, colsC - cb);
                if (nb_eff == 0) continue;
                int acc_elems_per_row = ((nb_eff + 15) / 16) * 16;

                // init acc_tile from C: float -> int32 (truncate)
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int32_t* dest_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;
                    std::memset(dest_row, 0, (size_t)acc_elems_per_row * sizeof(int32_t));
                }
                // main k-block loop: process p in pairs (p, p+1) to use maddubs
                for (int kb = 0; kb < colsA; kb += Kc) {
                    int kc_eff = std::min(Kc, colsA - kb);
                    if (kc_eff == 0) continue;

                    // process p in pairs
                    int p = 0;
                    for (; p + 1 < kc_eff; p += 2) {
                        int k_index0 = kb + p;
                        int k_index1 = kb + p + 1;

                        // process columns in chunks of 32 outputs (64 bytes interleaved)
                        for (int jcol = 0; jcol < nb_eff; jcol += MADDUBS_PAIR_OUT) {
                            int chunk = std::min(MADDUBS_PAIR_OUT, nb_eff - jcol);
                            // if chunk < MADDUBS_PAIR_OUT, fallback to scalar per-column path
                            if (chunk < MADDUBS_PAIR_OUT) break;

                            // pack B: interleave B[k_index0, cb+jcol + idx] and B[k_index1, cb+jcol + idx]
                            // into 64-byte buffer: [b0_0, b1_0, b0_1, b1_1, ...]
                            alignas(64) int8_t b_interleaved[BYTES_PER_LOAD];
                            for (int idx = 0; idx < MADDUBS_PAIR_OUT; ++idx) {
                                b_interleaved[2*idx    ] = *(denseB_p2 + (size_t)k_index0 * (size_t)colsC + (size_t)(cb + jcol + idx));
                                b_interleaved[2*idx + 1] = *(denseB_p2 + (size_t)k_index1 * (size_t)colsC + (size_t)(cb + jcol + idx));
                            }
                            __m512i vb = _mm512_loadu_si512((const void*)b_interleaved); // 64 bytes load

                            // precompute sum_b_pairs16 = b0 + b1 for each pair (as int16 -> later to int32)
                            __m512i sum_b_pairs16 = _mm512_maddubs_epi16(ones8, vb); // 32 x int16

                            // For each local row, form a_pair = [a0,a1,a0,a1,...] and apply maddubs
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                int a_row = rb + local_i;
                                const int8_t a0 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index0);
                                const int8_t a1 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index1);

                                // build a_pair vector: alternate bytes (a0,a1,a0,a1,...)
                                __m512i a0v = _mm512_set1_epi8((char)a0);
                                __m512i a1v = _mm512_set1_epi8((char)a1);
                                __m512i a_pair = _mm512_mask_mov_epi8(a0v, alt_mask, a1v); // odd lanes take a1

                                // convert a_pair to unsigned domain by xor 0x80
                                __m512i a_pair_u = _mm512_xor_si512(a_pair, xor_0x80_8);

                                // prod16 = maddubs(a_pair_u, vb) -> 32 x int16 = (a^128)*b
                                __m512i prod16 = _mm512_maddubs_epi16(a_pair_u, vb); // 32 x int16

                                // sum_b_pairs16 already computed: sum_b_pairs16 = b0 + b1 (int16)
                                // Need to compute correction = 128 * sum_b_pairs (in int32), since:
                                // prod16 = (a^128)*b = a*b + 128*b  => a*b = prod16 - 128 * sum_b_pairs

                                // convert prod16 (32xint16) -> two halves of 16xint32
                                __m256i prod16_lo_256 = _mm512_castsi512_si256(prod16); // low 256 bits
                                __m256i prod16_hi_256 = _mm512_extracti64x4_epi64(prod16, 1); // high 256 bits

                                __m512i prod32_lo = _mm512_cvtepi16_epi32(prod16_lo_256); // 16 x int32
                                __m512i prod32_hi = _mm512_cvtepi16_epi32(prod16_hi_256); // 16 x int32

                                // convert sum_b_pairs16 -> int32 halves and compute correction = sum_b_pairs * 128
                                __m256i sum16_lo_256 = _mm512_castsi512_si256(sum_b_pairs16);
                                __m256i sum16_hi_256 = _mm512_extracti64x4_epi64(sum_b_pairs16, 1);
                                __m512i sum32_lo = _mm512_cvtepi16_epi32(sum16_lo_256);
                                __m512i sum32_hi = _mm512_cvtepi16_epi32(sum16_hi_256);

                                __m512i corr32_lo = _mm512_slli_epi32(sum32_lo, 7); // *128
                                __m512i corr32_hi = _mm512_slli_epi32(sum32_hi, 7);

                                // final product (a*b) in int32 lanes
                                __m512i final32_lo = _mm512_sub_epi32(prod32_lo, corr32_lo);
                                __m512i final32_hi = _mm512_sub_epi32(prod32_hi, corr32_hi);

                                // accumulate into acc_tile
                                int32_t* dst_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row + jcol;
                                // load current acc 16 int32 (lo)
                                __m512i acc_lo = _mm512_loadu_si512((const void*)(dst_row + 0));
                                acc_lo = _mm512_add_epi32(acc_lo, final32_lo);
                                _mm512_storeu_si512((void*)(dst_row + 0), acc_lo);

                                // load current acc 16 int32 (hi)
                                __m512i acc_hi = _mm512_loadu_si512((const void*)(dst_row + 16));
                                acc_hi = _mm512_add_epi32(acc_hi, final32_hi);
                                _mm512_storeu_si512((void*)(dst_row + 16), acc_hi);
                            } // local_i
                        } // jcol chunks of 32

                        // handle remaining columns < 32 in this pair with scalar or vector int32 path
                        int rem_start = (nb_eff / MADDUBS_PAIR_OUT) * MADDUBS_PAIR_OUT;
                        for (int jj = rem_start; jj < nb_eff; ++jj) {
                            int col_j = cb + jj;
                            int8_t b0 = *(denseB_p2 + (size_t)k_index0 * (size_t)colsC + (size_t)col_j);
                            int8_t b1 = *(denseB_p2 + (size_t)k_index1 * (size_t)colsC + (size_t)col_j);
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                int a_row = rb + local_i;
                                int8_t a0 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index0);
                                int8_t a1 = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_index1);
                                int32_t addv = (int32_t)((int)a0 * (int)b0 + (int)a1 * (int)b1);
                                int32_t* dst = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row + jj;
                                dst[0] += addv;
                            }
                        }
                    } // p pairs

                    // if kc_eff is odd, handle last p
                    if ((kc_eff & 1) != 0) {
                        int k_last = kb + kc_eff - 1;
                        // process last k scalar / vector (fallback to int32 mul)
                        for (int jcol = 0; jcol < nb_eff; ++jcol) {
                            int col_j = cb + jcol;
                            int8_t bval = *(denseB_p2 + (size_t)k_last * (size_t)colsC + (size_t)col_j);
                            for (int local_i = 0; local_i < rb_eff; ++local_i) {
                                int a_row = rb + local_i;
                                int8_t aval = *(denseA_p2 + (size_t)a_row * (size_t)colsA + (size_t)k_last);
                                int32_t addv = (int32_t)((int)aval * (int)bval);
                                int32_t* dst = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row + jcol;
                                dst[0] += addv;
                            }
                        }
                    }

                } // kb

                // write back acc_tile -> denseC (int32 -> float)
                for (int local_i = 0; local_i < rb_eff; ++local_i) {
                    int i = rb + local_i;
                    float* Crow = denseC_p + (size_t)i * (size_t)colsC + (size_t)cb;
                    int32_t* src_row = acc_tile + (size_t)local_i * (size_t)acc_elems_per_row;

                    int j = 0;
                    for (; j + 16 - 1 < nb_eff; j += 16) {
                        __m512i vi = _mm512_loadu_si512((const void*)(src_row + j));
                        __m512 vf = _mm512_cvtepi32_ps(vi);
                        _mm512_storeu_ps(Crow + j, vf);
                    }
                    for (; j < nb_eff; ++j) Crow[j] = (float) src_row[j];
                }

            } // cb
        } // rb
    } // parallel

    // free per-thread acc tiles
    #pragma omp parallel for num_threads(num_threads) schedule(static)
    for (int t = 0; t < num_threads; ++t) {
        if (thread_acc_tile[t]) portable_aligned_free(thread_acc_tile[t]);
    }

    return true;
}

#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <chrono>
#include "custom_spike_attention.h"

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
torch::Tensor custom_attention_int(
    torch::Tensor x1,
    torch::Tensor x2,
    torch::Tensor output
) 
{
    // 简单检查（CPU + dtype）
    int B = x1.size(0);
    int M = x1.size(1);
    int K = x1.size(2);
    int N = x2.size(2);

    // printf("B=%d,M=%d,K=%d,N=%d\n",B,M,K,N);

    // auto t_end = std::chrono::steady_clock::now();
    // std::chrono::duration<double> diff = t_end - t_start;
    // printf("Sparse×Dense (contiguous): %.6f s\n",
    //    diff.count());
    
    // t_start = std::chrono::steady_clock::now();
    // auto output = torch::empty({B, M, N}, x1.options().dtype(torch::kFloat32)); 
    // float* C = output.data_ptr<float>(); 
    // #pragma omp parallel for collapse(2) num_threads(64) schedule(static) 
    // for (int b = 0; b < B; ++b) { 
    //     for (int i = 0; i < M; ++i) { 
    //         float* row = C + (size_t)i * N + (size_t)b * (size_t)M * (size_t)N; 
    //         memset(row, 0, N * sizeof(float)); } 
    //     }
    
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (clear C): %.6f s\n",
    //    diff.count());

    // call your C kernel (ensure types match)
    // t_start = std::chrono::steady_clock::now();
    GEMM_Batch_Attention_yk_int(
        x1.data_ptr<int8_t>(), x2.data_ptr<int8_t>(),
        output.data_ptr<float>(),
        B,M,K,N,0
    );
    // t_end = std::chrono::steady_clock::now();
    // diff = t_end - t_start;
    // printf("Sparse×Dense (calculation): %.6f s\n",
    //    diff.count());
    return output;
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_attention_int(Tensor x1, Tensor x2, Tensor output) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_attention_int", TORCH_FN(custom_attention_int));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_attention_int",
          &custom_attention_int,
          "custom_attention_int(Tensor x1, Tensor x2, Tensor output) -> output",
          py::arg("x1"),
          py::arg("x2"),
          py::arg("output")
    );
}

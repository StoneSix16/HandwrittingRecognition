import torch
import torch.nn as nn
from timm.models.vision_transformer import Attention
from torch.utils.cpp_extension import load

custom_matmul = load(
    name="custom_matmul",
    sources=["../layers/matmul/matmul_sgemm.cpp"],
    extra_ldflags=["-ldnnl", "-mkl", "-lmkl_rt", "-mavx2", "-mfma", "-mavx512f", "-fopenmp"], 
    verbose=True,
)

class CustomMatmul_Scale(nn.Module):
    def __init__(self):
        super(CustomMatmul_Scale, self).__init__()

    def forward(self, x, y, scale):
        output = custom_matmul.custom_matmul(x, y.transpose(-2, -1), torch.tensor(scale))
        return output

class CustomMatmul(nn.Module):
    def __init__(self):
        super(CustomMatmul, self).__init__()

    def forward(self, x, y):
        output = custom_matmul.custom_matmul(x, y, None).transpose(1, 2)
        return output


class CustomAttention(Attention):
    def __init__(self, embed_dim, num_heads, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super(CustomAttention, self).__init__(
            dim=embed_dim,
            num_heads=num_heads,
            qkv_bias=qkv_bias,
            attn_drop=attn_drop,
            proj_drop=proj_drop
        )        
        self.matmul_scale = CustomMatmul_Scale()
        self.matmul = CustomMatmul()

    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]   # make torchscript happy (cannot use tensor as tuple)

        attn = self.matmul_scale(q,k,self.scale)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)

        x = self.matmul(attn, v).reshape(B, N, C)
        x = self.proj(x)
        x = self.proj_drop(x)
        return x


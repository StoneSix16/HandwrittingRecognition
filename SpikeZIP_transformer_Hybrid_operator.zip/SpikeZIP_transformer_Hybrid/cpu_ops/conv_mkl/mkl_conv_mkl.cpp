// mkl_conv.cpp
#include <torch/extension.h>
#include <dnnl.hpp>
#include <vector>
#include <unordered_map>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>       // SymInt 支持
#include <c10/util/ArrayRef.h>    // SymIntArrayRef

using namespace dnnl;

// 完全匹配 aten::conv2d 的 SymInt Schema：
//   conv2d(Tensor input, Tensor weight, Tensor? bias=None,
//          SymInt[2] stride=[1,1], SymInt[2] padding=[0,0],
//          SymInt[2] dilation=[1,1], SymInt groups=1) -> Tensor
torch::Tensor mkl_convolution(
    const torch::Tensor& input1,
    const torch::Tensor& weight1,
    const c10::optional<torch::Tensor>& bias_opt,
    c10::SymIntArrayRef stride,   // SymInt[2]
    c10::SymIntArrayRef padding,  // SymInt[2]
    c10::SymIntArrayRef dilation, // SymInt[2]
    c10::SymInt groups_sym        // SymInt
) {
    int64_t groups = groups_sym.as_int_unchecked();
    TORCH_CHECK(groups == 1, "Currently only groups=1 is supported");

    // Ensure contiguous
    torch::Tensor input  = input1.contiguous();
    torch::Tensor weight  = weight1.contiguous();
    bool has_bias = bias_opt.has_value() && bias_opt->defined();
    torch::Tensor bias = has_bias ? bias_opt.value().contiguous() : torch::Tensor();

    // 从 SymIntArrayRef 中取出 int64_t
    int64_t stride_h = stride[0].as_int_unchecked();
    int64_t stride_w = stride[1].as_int_unchecked();
    int64_t pad_h    = padding[0].as_int_unchecked();
    int64_t pad_w    = padding[1].as_int_unchecked();
    int64_t dil_h    = dilation[0].as_int_unchecked();
    int64_t dil_w    = dilation[1].as_int_unchecked();

    // Dimensions
    int N  = input.size(0), C = input.size(1), H = input.size(2), W = input.size(3);
    int O  = weight.size(0), KH = weight.size(2), KW = weight.size(3);
    int OH = (H + 2*pad_h - dil_h*(KH-1) - 1) / stride_h + 1;
    int OW = (W + 2*pad_w - dil_w*(KW-1) - 1) / stride_w + 1;

    // oneDNN engine & stream
    engine eng(engine::kind::cpu, 0);
    stream strm(eng);

    // Memory descriptors
    memory::dims src_dims    = {N, C, H, W};
    memory::dims weight_dims = {O, C, KH, KW};
    memory::dims dst_dims    = {N, O, OH, OW};
    memory::dims strides_dnnl   = {stride_h, stride_w};
    memory::dims pads_begin     = {pad_h, pad_w};
    memory::dims pads_end       = {pad_h, pad_w};
    memory::dims dilations_dnnl = {dil_h-1, dil_w-1};

    auto src_md    = memory::desc(src_dims,    memory::data_type::f32, memory::format_tag::nchw);
    auto weight_md = memory::desc(weight_dims, memory::data_type::f32, memory::format_tag::oihw);
    auto dst_md    = memory::desc(dst_dims,    memory::data_type::f32, memory::format_tag::nchw);
    memory::desc bias_md;
    if (has_bias) bias_md = memory::desc({O}, memory::data_type::f32, memory::format_tag::x);

    primitive_attr attr;
    auto conv_pd = has_bias
        ? convolution_forward::primitive_desc(
            eng, prop_kind::forward_inference, algorithm::convolution_direct,
            src_md, weight_md, bias_md, dst_md,
            strides_dnnl, pads_begin, pads_end, attr, false)
        : convolution_forward::primitive_desc(
            eng, prop_kind::forward_inference, algorithm::convolution_direct,
            src_md, weight_md, dst_md,
            strides_dnnl, pads_begin, pads_end, attr, false);

    auto src_mem    = memory(conv_pd.src_desc(),    eng, input.data_ptr<float>());
    auto weight_mem = memory(conv_pd.weights_desc(),eng, weight.data_ptr<float>());
    auto output     = torch::empty({N, O, OH, OW}, input.options());
    auto dst_mem    = memory(conv_pd.dst_desc(),    eng, output.data_ptr<float>());

    memory bias_mem;
    if (has_bias) bias_mem = memory(conv_pd.bias_desc(), eng, bias.data_ptr<float>());

    std::unordered_map<int, memory> args;
    args.emplace(DNNL_ARG_SRC,    src_mem);
    args.emplace(DNNL_ARG_WEIGHTS,weight_mem);
    if (has_bias) args.emplace(DNNL_ARG_BIAS, bias_mem);
    args.emplace(DNNL_ARG_DST,    dst_mem);

    convolution_forward(conv_pd).execute(strm, args);
    strm.wait();

    return output;
}

TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("mkl_convolution(Tensor input, Tensor weight, Tensor? bias, SymInt[] stride, SymInt[] padding, SymInt[] dilation, SymInt groups) -> Tensor");
}

// 注册 CPU backend 实现
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("mkl_convolution", TORCH_FN(mkl_convolution));
}

// 保留pybind11扩展接口（供Python直接调用）
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mkl_convolution", &mkl_convolution,
          "oneDNN optimized convolution matching aten::conv2d",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("stride") = std::vector<int64_t>{1,1},
          py::arg("padding") = std::vector<int64_t>{0,0},
          py::arg("dilation") = std::vector<int64_t>{1,1},
          py::arg("groups") = 1);
}
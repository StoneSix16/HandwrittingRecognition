from torch.utils.cpp_extension import load
import torch
import time

# 1. 编译并加载扩展
mkl_conv = load(
    name="mkl_conv",
    sources=["mkl_conv_template.cpp"],
    extra_ldflags=["-ldnnl"],
    verbose=True,
)

# 2. 构造输入数据
x = torch.randn(1, 128, 56, 56)
w = torch.randn(128, 128, 3, 3)
b = torch.randn(128)

# 3. 调用你自定义的 mkl_convolution
#    注意：新签名是
#       (Tensor input,
#        Tensor weight,
#        Tensor? bias,
#        int[2] stride,
#        int[2] padding,
#        int[2] dilation,
#        int   groups) -> Tensor

start = time.time()
out = torch.ops.custom.mkl_convolution(
    x, w, None,
    [1, 1],    # stride_h=2, stride_w=2
    [1, 1],    # pad_h=3,   pad_w=3
    [1, 1],    # dilation_h=1, dilation_w=1
    1,          # groups=1
    False
)
end = time.time()
time_ours = (end-start)*1000

# 4. 对比 PyTorch 内置 conv2d 的结果
start = time.time()
out_true = torch.nn.functional.conv2d(
    x, w, None,
    stride=(1, 1),
    padding=(1, 1),
    dilation=(1, 1),
    groups=1
    )
end = time.time()
time_pytorch = (end-start)*1000

# 5. 验证两者输出是否一致
print("Match:", torch.allclose(out, out_true, rtol=1e-2, atol=1e-4))
print("out.shape:", out.shape)       # 应是 [1,64,112,112]
print("out_true.shape:", out_true.shape)

for _ in range(10):
    x = torch.randn(1, 128, 56, 56)
    w = torch.randn(128, 128, 3, 3)
    b = torch.randn(128)
    out = torch.ops.custom.mkl_convolution(
        x, w, None,
        [1, 1],    # stride_h=2, stride_w=2
        [1, 1],    # pad_h=3,   pad_w=3
        [1, 1],    # dilation_h=1, dilation_w=1
        1,          # groups=1
        False
    )
# benchmark latency
start = time.time()
out = torch.ops.custom.mkl_convolution(
    x, w, None,
    [1, 1],    # stride_h=2, stride_w=2
    [1, 1],    # pad_h=3,   pad_w=3
    [1, 1],    # dilation_h=1, dilation_w=1
    1,          # groups=1
    False
)
end = time.time()
time_ours = (end-start)*1000

for _ in range(10):
    x = torch.randn(1, 128, 56, 56)
    w = torch.randn(128, 128, 3, 3)
    b = torch.randn(128)
    out_true = torch.nn.functional.conv2d(
        x, w, None,
        stride=(1, 1),
        padding=(1, 1),
        dilation=(1, 1),
        groups=1
        )


x = torch.randn(1, 128, 56, 56)
w = torch.randn(128, 128, 3, 3)
b = torch.randn(128)
# 4. 对比 PyTorch 内置 conv2d 的结果
start = time.time()
out_true = torch.nn.functional.conv2d(
    x, w, None,
    stride=(1, 1),
    padding=(1, 1),
    dilation=(1, 1),
    groups=1
    )
end = time.time()
time_pytorch = (end-start)*1000


print("custom mkl_convolution time:", time_ours, "ms")
print("pytorch convolution time:", time_pytorch, "ms")

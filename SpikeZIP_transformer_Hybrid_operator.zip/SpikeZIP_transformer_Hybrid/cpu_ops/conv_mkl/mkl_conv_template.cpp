// mkl_conv.cpp
#include <torch/extension.h>
#include <dnnl.hpp>
#include <vector>
#include <unordered_map>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>       // SymInt 支持
#include <c10/util/ArrayRef.h>    // SymIntArrayRef
#include <pthread.h>
#include <unistd.h>   // sysconf
#include <chrono>

using namespace dnnl;


// ---------- 线程任务参数 ----------
struct Im2ColTask {
    const float* data_im;   // N=1 slice, shape: C x H x W
    float*       data_col;  // shape: (C*KH*KW) x (OH*OW)
    int64_t      c_start;   // inclusive
    int64_t      c_end;     // exclusive

    int64_t C, H, W;
    int64_t KH, KW;
    int64_t pad_h, pad_w;
    int64_t stride_h, stride_w;
    int64_t dil_h, dil_w;
    int64_t OH, OW;
};

// ---------- 单线程 im2col 核心 ----------
static void im2col_single_channel_block(const Im2ColTask& t)
{
    const int64_t patch_area = t.OH * t.OW;
    for (int64_t c = t.c_start; c < t.c_end; ++c) {
        const float* im_ptr_base = t.data_im + c * t.H * t.W;
        for (int64_t kh = 0; kh < t.KH; ++kh) {
            for (int64_t kw = 0; kw < t.KW; ++kw) {
                const int64_t row_idx =
                    ((c * t.KH + kh) * t.KW + kw) * patch_area;
                float* col_ptr = t.data_col + row_idx;

                for (int64_t oh = 0; oh < t.OH; ++oh) {
                    const int64_t ih = oh * t.stride_h - t.pad_h +
                                       kh * t.dil_h;
                    for (int64_t ow = 0; ow < t.OW; ++ow) {
                        const int64_t iw = ow * t.stride_w - t.pad_w +
                                           kw * t.dil_w;
                        float val = 0.f;
                        if (ih >= 0 && ih < t.H && iw >= 0 && iw < t.W) {
                            val = im_ptr_base[ih * t.W + iw];
                        }
                        col_ptr[oh * t.OW + ow] = val;
                    }
                }
            }
        }
    }
}

// ---------- pthread 启动包装 ----------
static void* im2col_thread_entry(void* arg)
{
    auto* task = static_cast<Im2ColTask*>(arg);
    im2col_single_channel_block(*task);
    return nullptr;
}

// ---------- 多线程调度 ----------
static void im2col_pthreads(
        const float* data_im,
        float* data_col,
        int64_t C, int64_t H, int64_t W,
        int64_t KH, int64_t KW,
        int64_t pad_h, int64_t pad_w,
        int64_t stride_h, int64_t stride_w,
        int64_t dil_h, int64_t dil_w,
        int64_t OH, int64_t OW,
        int  num_threads)
{
    if (num_threads < 1) num_threads = 1;
    num_threads = std::min<int64_t>(num_threads, C);

    std::vector<pthread_t> threads(num_threads);
    std::vector<Im2ColTask> tasks(num_threads);

    // 划分通道区间
    int64_t chunk = (C + num_threads - 1) / num_threads;
    for (int t = 0; t < num_threads; ++t) {
        int64_t c0 = t * chunk;
        int64_t c1 = std::min<int64_t>(c0 + chunk, C);
        if (c0 >= c1) { threads.resize(t); break; }  // 剩余线程不启用

        tasks[t] = {data_im, data_col,
                    c0, c1,
                    C, H, W,
                    KH, KW,
                    pad_h, pad_w,
                    stride_h, stride_w,
                    dil_h, dil_w,
                    OH, OW};

        pthread_create(&threads[t], nullptr, im2col_thread_entry, &tasks[t]);
    }
    // 等待全部线程
    for (auto& th : threads) pthread_join(th, nullptr);
}

torch::Tensor mkl_convolution(
    const torch::Tensor& input1,
    const torch::Tensor& weight1,
    const c10::optional<torch::Tensor>& bias_opt,
    c10::SymIntArrayRef stride,   // SymInt[2]
    c10::SymIntArrayRef padding,  // SymInt[2]
    c10::SymIntArrayRef dilation, // SymInt[2]
    c10::SymInt groups_sym,        // SymInt
    bool fuse_relu
) {
    // 解包 SymInt -> int64_t
    TORCH_CHECK(input1.is_contiguous(),  "input must be contiguous");
    TORCH_CHECK(weight1.is_contiguous(), "weight must be contiguous");
    TORCH_CHECK(input1.dtype() == torch::kFloat,
                "this reference impl handles float32 only");

    // ---- 参数解析 ----
    const int64_t stride_h = stride[0].as_int_unchecked();
    const int64_t stride_w = stride[1].as_int_unchecked();
    const int64_t pad_h    = padding[0].as_int_unchecked();
    const int64_t pad_w    = padding[1].as_int_unchecked();
    const int64_t dil_h    = dilation[0].as_int_unchecked();
    const int64_t dil_w    = dilation[1].as_int_unchecked();
    const int64_t groups   = groups_sym.as_int_unchecked();
    TORCH_CHECK(groups == 1,
        "groups>1 is TODO in this reference (extend im2col per‑group if needed)");

    // ---- 维度 ----
    const int64_t N  = input1.size(0);
    const int64_t C  = input1.size(1);
    const int64_t H  = input1.size(2);
    const int64_t W  = input1.size(3);

    const int64_t O  = weight1.size(0);   // out‑channels
    const int64_t KH = weight1.size(2);
    const int64_t KW = weight1.size(3);

    const int64_t OH = (H + 2 * pad_h - dil_h * (KH - 1) - 1) / stride_h + 1;
    const int64_t OW = (W + 2 * pad_w - dil_w * (KW - 1) - 1) / stride_w + 1;

    // ---- 输出 ----
    auto output = torch::empty({N, O, OH, OW}, input1.options());

    // ---- 预变形 weight ----
    auto weight_2d = weight1.view({O, C * KH * KW}).contiguous();

    // ---- 线程数 ----
    int num_threads = 8;

    // ---- 遍历批次 ----
    for (int64_t n = 0; n < N; ++n) {
        // 1) im2col (多线程)
        const float* in_ptr  = input1[n].data_ptr<float>();
        auto col = torch::empty({C*KH*KW, OH*OW}, input1.options());
        float* col_ptr = col.data_ptr<float>();
        
        // auto t_start = std::chrono::high_resolution_clock::now();
        im2col_pthreads(in_ptr, col_ptr,
                        C, H, W,
                        KH, KW,
                        pad_h, pad_w,
                        stride_h, stride_w,
                        dil_h, dil_w,
                        OH, OW,
                        num_threads);
        // auto t_end = std::chrono::high_resolution_clock::now();
        // auto verify_time = std::chrono::duration_cast<std::chrono::microseconds>(t_end - t_start);
        // printf("im2col_pthreads time: %ld μs\n", verify_time.count());
        
        // t_start = std::chrono::high_resolution_clock::now();
        // 2) GEMM  (O x (C*KH*KW))  *  ((C*KH*KW) x (OH*OW))
        auto out_mat = torch::mm(weight_2d, col);                      // shape: O x (OH*OW)
        // t_end = std::chrono::high_resolution_clock::now();
        // verify_time = std::chrono::duration_cast<std::chrono::microseconds>(t_end - t_start);
        // printf("torch::mm time: %ld μs\n", verify_time.count());

        // 3) bias
        if (bias_opt.has_value()) {
            // t_start = std::chrono::high_resolution_clock::now();
            out_mat += bias_opt.value().view({-1, 1});
            // t_end = std::chrono::high_resolution_clock::now();
            // verify_time = std::chrono::duration_cast<std::chrono::microseconds>(t_end - t_start);
            // printf("bias time: %ld μs\n", verify_time.count());
        }

        // 4) 形状 & ReLU
        // t_start = std::chrono::high_resolution_clock::now();
        auto out_4d = out_mat.view({O, OH, OW});
        if (fuse_relu) out_4d = torch::relu(out_4d);
        // t_end = std::chrono::high_resolution_clock::now();
        // verify_time = std::chrono::duration_cast<std::chrono::microseconds>(t_end - t_start);
        // printf("relu time: %ld μs\n", verify_time.count());

        output[n].copy_(out_4d);
    }

    return output;
}

TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("mkl_convolution(Tensor input, Tensor weight, Tensor? bias, SymInt[] stride, SymInt[] padding, SymInt[] dilation, SymInt groups, bool fuse_relu) -> Tensor");
}

// 注册 CPU backend 实现
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("mkl_convolution", TORCH_FN(mkl_convolution));
}

// 保留pybind11扩展接口（供Python直接调用）
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mkl_convolution", &mkl_convolution,
          "oneDNN optimized convolution matching aten::conv2d",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("stride") = std::vector<int64_t>{1,1},
          py::arg("padding") = std::vector<int64_t>{0,0},
          py::arg("dilation") = std::vector<int64_t>{1,1},
          py::arg("groups") = 1,
          py::arg("fuse_relu") = false
        );
}
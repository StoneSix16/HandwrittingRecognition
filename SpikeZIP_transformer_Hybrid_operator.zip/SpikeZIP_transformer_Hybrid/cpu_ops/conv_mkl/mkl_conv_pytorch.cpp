// mkl_conv.cpp
#include <torch/extension.h>
#include <dnnl.hpp>
#include <vector>
#include <unordered_map>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>       // SymInt 支持
#include <c10/util/ArrayRef.h>    // SymIntArrayRef

using namespace dnnl;

// 完全匹配 aten::conv2d 的 SymInt Schema：
//   conv2d(Tensor input, Tensor weight, Tensor? bias=None,
//          SymInt[2] stride=[1,1], SymInt[2] padding=[0,0],
//          SymInt[2] dilation=[1,1], SymInt groups=1) -> Tensor
torch::Tensor mkl_convolution(
    const torch::Tensor& input1,
    const torch::Tensor& weight1,
    const c10::optional<torch::Tensor>& bias_opt,
    c10::SymIntArrayRef stride,   // SymInt[2]
    c10::SymIntArrayRef padding,  // SymInt[2]
    c10::SymIntArrayRef dilation, // SymInt[2]
    c10::SymInt groups_sym,        // SymInt
    bool fuse_relu
) {
    // 解包 SymInt -> int64_t
    std::vector<int64_t> stride_vec = {stride[0].as_int_unchecked(), stride[1].as_int_unchecked()};
    std::vector<int64_t> padding_vec = {padding[0].as_int_unchecked(), padding[1].as_int_unchecked()};
    std::vector<int64_t> dilation_vec = {dilation[0].as_int_unchecked(), dilation[1].as_int_unchecked()};
    int64_t groups = groups_sym.as_int_unchecked();

    // 调用 torch::conv2d
    torch::Tensor out;
    if (bias_opt.has_value() && bias_opt->defined()) {
        out = at::conv2d(input1, weight1, bias_opt.value(),
                         stride_vec, padding_vec, dilation_vec, groups);
    } else {
        out = at::conv2d(input1, weight1, c10::nullopt,
                         stride_vec, padding_vec, dilation_vec, groups);
    }

    // fuse ReLU
    if (fuse_relu) {
        out = at::relu(out);
    }

    return out;
}



TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("mkl_convolution(Tensor input, Tensor weight, Tensor? bias, SymInt[] stride, SymInt[] padding, SymInt[] dilation, SymInt groups, bool fuse_relu) -> Tensor");
}

// 注册 CPU backend 实现
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("mkl_convolution", TORCH_FN(mkl_convolution));
}

// 保留pybind11扩展接口（供Python直接调用）
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mkl_convolution", &mkl_convolution,
          "oneDNN optimized convolution matching aten::conv2d",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("stride") = std::vector<int64_t>{1,1},
          py::arg("padding") = std::vector<int64_t>{0,0},
          py::arg("dilation") = std::vector<int64_t>{1,1},
          py::arg("groups") = 1,
          py::arg("fuse_relu") = false
        );
}
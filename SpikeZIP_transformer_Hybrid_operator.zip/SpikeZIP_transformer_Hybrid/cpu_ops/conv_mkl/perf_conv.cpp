// file: test_mkl_conv_perf.cpp

#include <torch/torch.h>
#include <iostream>
#include "mkl_conv_template.cpp"

// 你的 mkl_convolution 声明（确保 link 时包含定义）
torch::Tensor mkl_convolution(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const c10::optional<torch::Tensor>& bias,
    c10::SymIntArrayRef stride,
    c10::SymIntArrayRef padding,
    c10::SymIntArrayRef dilation,
    c10::SymInt groups,
    bool fuse_relu
);

int main() {
    torch::manual_seed(123);

    const int N = 1, C = 3, H = 128, W = 128;
    const int O = 64, KH = 3, KW = 3;

    auto input = torch::rand({N, C, H, W}, torch::kFloat32);
    auto weight = torch::rand({O, C, KH, KW}, torch::kFloat32);
    c10::optional<torch::Tensor> bias = c10::nullopt;

    // 先 warm-up 几次
    for (int i = 0; i < 5; ++i) {
        auto out = mkl_convolution(input, weight, bias,
            {1,1}, {1,1}, {1,1}, 1, false);
    }

    // 实际测 100 次
    const int iters = 100;
    for (int i = 0; i < iters; ++i) {
        auto out = mkl_convolution(input, weight, bias,
            {1,1}, {1,1}, {1,1}, 1, false);
    }

    std::cout << "Done.\n";
    return 0;
}

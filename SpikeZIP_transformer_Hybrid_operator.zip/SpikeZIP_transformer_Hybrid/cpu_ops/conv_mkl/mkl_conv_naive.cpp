// mkl_conv.cpp
#include <torch/extension.h>
#include <dnnl.hpp>
#include <vector>
#include <unordered_map>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>       // SymInt 支持
#include <c10/util/ArrayRef.h>    // SymIntArrayRef
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>
#include <algorithm>

torch::Tensor mkl_convolution(
    const torch::Tensor& input1,
    const torch::Tensor& weight1,
    const c10::optional<torch::Tensor>& bias_opt,
    c10::SymIntArrayRef stride,    // SymInt[2]
    c10::SymIntArrayRef padding,   // SymInt[2]
    c10::SymIntArrayRef dilation,  // SymInt[2]
    c10::SymInt groups_sym         // SymInt
) {
  TORCH_CHECK(groups_sym.as_int_unchecked() == 1, "groups != 1 not supported");

  // 1) prepare contiguous tensors & raw pointers
  auto input  = input1.contiguous();
  auto weight = weight1.contiguous();
  bool has_bias = bias_opt.has_value() && bias_opt->defined();
  const float* bias_ptr = has_bias ? bias_opt->data_ptr<float>() : nullptr;

  const float* in_ptr  = input.data_ptr<float>();
  const float* wt_ptr  = weight.data_ptr<float>();

  int sh = stride[0].as_int_unchecked(),
      sw = stride[1].as_int_unchecked();
  int ph = padding[0].as_int_unchecked(),
      pw = padding[1].as_int_unchecked();
  int dh = dilation[0].as_int_unchecked(),
      dw = dilation[1].as_int_unchecked();

  int N  = input.size(0),
      C  = input.size(1),
      H  = input.size(2),
      W  = input.size(3);
  int O  = weight.size(0),
      KH = weight.size(2),
      KW = weight.size(3);
  int OH = (H + 2*ph - dh*(KH-1) - 1)/sh + 1;
  int OW = (W + 2*pw - dw*(KW-1) - 1)/sw + 1;

  auto output = torch::empty({N, O, OH, OW}, input.options());
  float* out_ptr = output.data_ptr<float>();

  // strides in elements
  auto in_str = input.strides();
  int64_t sN = in_str[0], sC = in_str[1], sH = in_str[2], sW = in_str[3];

  // block sizes (tune as needed)
  const int BOC = 16;  // output channel block
  const int BH  = 16;  // output height block
  const int BW  = 16;  // output width block

  // 2) direct convolution with blocking and OpenMP
  #pragma omp parallel for collapse(3) schedule(dynamic,1)
  for (int n = 0; n < N; ++n) {
    for (int ob = 0; ob < O; ob += BOC) {
      int o_max = std::min(ob + BOC, O);
      for (int hb = 0; hb < OH; hb += BH) {
        int h_max = std::min(hb + BH, OH);
        for (int wb = 0; wb < OW; wb += BW) {
          int w_max = std::min(wb + BW, OW);

          for (int o = ob; o < o_max; ++o) {
            for (int h = hb; h < h_max; ++h) {
              for (int w = wb; w < w_max; ++w) {
                // compute output[n,o,h,w]
                float sum = has_bias ? bias_ptr[o] : 0.0f;

                // iterate channels and kernel
                for (int c = 0; c < C; ++c) {
                  // pointer to input channel c of batch n
                  const float* in_nc = in_ptr + n*sN + c*sC;
                  // pointer to weight for output o, channel c
                  const float* wt_oc = wt_ptr + o*(C*KH*KW)
                                              + c*(KH*KW);
                  for (int kh = 0; kh < KH; ++kh) {
                    int ih = h*sh - ph + kh*dh;
                    if ((unsigned)ih >= (unsigned)H) continue;
                    for (int kw = 0; kw < KW; ++kw) {
                      int iw = w*sw - pw + kw*dw;
                      if ((unsigned)iw < (unsigned)W) {
                        sum += in_nc[ih*sH + iw*sW]
                             * wt_oc[kh*KW + kw];
                      }
                    }
                  }
                }

                // store result
                out_ptr[n*(O*OH*OW) + o*(OH*OW) + h*OW + w] = sum;
              }
            }
          }

        } // wb
      } // hb
    } // ob
  } // n

  return output;
}


TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("mkl_convolution(Tensor input, Tensor weight, Tensor? bias, SymInt[] stride, SymInt[] padding, SymInt[] dilation, SymInt groups) -> Tensor");
}

// 注册 CPU backend 实现
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("mkl_convolution", TORCH_FN(mkl_convolution));
}

// 保留pybind11扩展接口（供Python直接调用）
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mkl_convolution", &mkl_convolution,
          "oneDNN optimized convolution matching aten::conv2d",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("stride") = std::vector<int64_t>{1,1},
          py::arg("padding") = std::vector<int64_t>{0,0},
          py::arg("dilation") = std::vector<int64_t>{1,1},
          py::arg("groups") = 1);
}
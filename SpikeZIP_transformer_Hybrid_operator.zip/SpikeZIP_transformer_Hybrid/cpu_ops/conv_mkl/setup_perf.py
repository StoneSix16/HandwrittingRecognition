# setup_perf.py
from torch.utils.cpp_extension import CppExtension, BuildExtension
from setuptools import setup

setup(
    name="test_mkl_conv_perf",
    ext_modules=[
        CppExtension(
            "test_mkl_conv_perf",
            ["mkl_conv_template.cpp"],
            include_dirs=[],
        )
    ],
    cmdclass={"build_ext": BuildExtension}
)

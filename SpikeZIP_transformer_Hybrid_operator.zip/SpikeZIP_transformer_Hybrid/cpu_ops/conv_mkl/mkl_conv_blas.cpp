// mkl_conv.cpp
#include <torch/extension.h>
#include <dnnl.hpp>
#include <vector>
#include <unordered_map>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>       // SymInt 支持
#include <c10/util/ArrayRef.h>    // SymIntArrayRef
#include <mkl.h>
#include <mkl_spblas.h>
// 完全匹配 aten::conv2d 的 SymInt Schema：
//   conv2d(Tensor input, Tensor weight, Tensor? bias=None,
//          SymInt[2] stride=[1,1], SymInt[2] padding=[0,0],
//          SymInt[2] dilation=[1,1], SymInt groups=1) -> Tensor
// Helper: compute im2col for one image
static void im2col(
    const float* in_ptr,
    int N, int C, int H, int W,
    int KH, int KW,
    int OH, int OW,
    int sh, int sw,
    int ph, int pw,
    int dh, int dw,
    const int64_t* strides,  // tensor strides in elements: {sN,sC,sH,sW}
    float* A              // output M x K  (M=OH*OW, K=C*KH*KW)
) {
  int M = OH * OW;
  int K = C * KH * KW;
  for(int oh=0; oh<OH; ++oh) {
    for(int ow=0; ow<OW; ++ow) {
      int m = oh*OW + ow;
      for(int c=0; c<C; ++c) {
        for(int kh=0; kh<KH; ++kh) {
          for(int kw=0; kw<KW; ++kw) {
            int k = c*KH*KW + kh*KW + kw;
            int ih = oh*sh - ph + kh*dh;
            int iw = ow*sw - pw + kw*dw;
            float v = 0.f;
            if ((unsigned)ih < (unsigned)H && (unsigned)iw < (unsigned)W) {
              v = in_ptr[
                ih * strides[2] +
                iw * strides[3] +
                c  * strides[1] +
                /*n*strides[0]*/ 0 // assume caller offsets by batch
              ];
            }
            A[m*K + k] = v;
          }
        }
      }
    }
  }
}

torch::Tensor mkl_convolution(
    const torch::Tensor& input1,
    const torch::Tensor& weight1,
    const c10::optional<torch::Tensor>& bias_opt,
    c10::SymIntArrayRef stride,
    c10::SymIntArrayRef padding,
    c10::SymIntArrayRef dilation,
    c10::SymInt groups_sym
) {
  TORCH_CHECK(groups_sym.as_int_unchecked()==1, "only groups=1");
  auto input  = input1.contiguous();
  auto weight = weight1.contiguous();
  bool has_bias = bias_opt.has_value() && bias_opt->defined();
  const float* bias_ptr = has_bias ? bias_opt->data_ptr<float>() : nullptr;

  int sh = stride[0].as_int_unchecked(), sw = stride[1].as_int_unchecked();
  int ph = padding[0].as_int_unchecked(), pw = padding[1].as_int_unchecked();
  int dh = dilation[0].as_int_unchecked(), dw = dilation[1].as_int_unchecked();

  int N  = input.size(0), C = input.size(1), H  = input.size(2), W  = input.size(3);
  int O  = weight.size(0), KH = weight.size(2), KW = weight.size(3);
  int OH = (H + 2*ph - dh*(KH-1) - 1)/sh + 1;
  int OW = (W + 2*pw - dw*(KW-1) - 1)/sw + 1;

  auto out = torch::empty({N, O, OH, OW}, input.options());
  const float* in_ptr  = input.data_ptr<float>();
  const float* wt_ptr  = weight.data_ptr<float>();
        float* out_ptr = out.data_ptr<float>();

  // strides for manual indexing
  auto in_str = input.strides();
  int64_t sN=in_str[0], sC=in_str[1], sH=in_str[2], sW=in_str[3];

  int M = OH * OW;        // rows of A and C
  int K = C * KH * KW;    // cols of A, rows of B
  int P = O;              // cols of B and C

  // --- 1) pack B once ---
  static std::vector<float> B;
  static bool B_packed = false;
  static std::mutex pack_mutex;
  if (!B_packed) {
    std::lock_guard<std::mutex> lk(pack_mutex);
    if (!B_packed) {
      B.resize(K * P);
      // weight layout: [O, C, KH, KW] contiguous
      // pack into B[K][P]
      #pragma omp parallel for collapse(2)
      for(int o=0; o<O; ++o) {
        for(int k=0; k<K; ++k) {
          B[k*P + o] = wt_ptr[o*(C*KH*KW) + k];
        }
      }
      B_packed = true;
    }
  }

  // --- 2) allocate/reuse A and C buffers ---
  static std::vector<float> A;
  static std::vector<float> Cmat;
  A.resize(M * K);
  Cmat.resize(M * P);

  // --- 3) process each image in batch in parallel ---
  #pragma omp parallel for
  for(int n=0; n<N; ++n) {
    const float* in_n  = in_ptr  + n * sN;
          float* out_n = out_ptr + n * (O*OH*OW);

    // 3a) im2col -> A
    //   parallel inside im2col: over M rows
    #pragma omp parallel for
    for(int m=0; m<M; ++m) {
      int oh = m / OW, ow = m % OW;
      float* a_row = &A[m*K];
      // for each channel+kernel
      int idx = 0;
      for(int c=0; c<C; ++c) {
        for(int kh=0; kh<KH; ++kh) {
          for(int kw=0; kw<KW; ++kw, ++idx) {
            int ih = oh*sh - ph + kh*dh;
            int iw = ow*sw - pw + kw*dw;
            float v = 0.f;
            if ((unsigned)ih < (unsigned)H && (unsigned)iw < (unsigned)W) {
              v = in_n[c*sC + ih*sH + iw*sW];
            }
            a_row[idx] = v;
          }
        }
      }
    }

    // 3b) GEMM: Cmat = A * B
    cblas_sgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans,
                M, P, K,
                1.0f,
                A.data(),    K,
                B.data(),    P,
                0.0f,
                Cmat.data(), P);

    // 3c) write back + bias
    #pragma omp parallel for collapse(2)
    for(int m=0; m<M; ++m) {
      int oh = m / OW, ow = m % OW;
      for(int o=0; o<O; ++o) {
        float v = Cmat[m*P + o];
        if (has_bias) v += bias_ptr[o];
        out_n[o*(OH*OW) + oh*OW + ow] = v;
      }
    }
  }

  return out;
}


TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("mkl_convolution(Tensor input, Tensor weight, Tensor? bias, SymInt[] stride, SymInt[] padding, SymInt[] dilation, SymInt groups) -> Tensor");
}

// 注册 CPU backend 实现
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("mkl_convolution", TORCH_FN(mkl_convolution));
}

// 保留pybind11扩展接口（供Python直接调用）
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("mkl_convolution", &mkl_convolution,
          "oneDNN optimized convolution matching aten::conv2d",
          py::arg("input"),
          py::arg("weight"),
          py::arg("bias") = c10::nullopt,
          py::arg("stride") = std::vector<int64_t>{1,1},
          py::arg("padding") = std::vector<int64_t>{0,0},
          py::arg("dilation") = std::vector<int64_t>{1,1},
          py::arg("groups") = 1);
}
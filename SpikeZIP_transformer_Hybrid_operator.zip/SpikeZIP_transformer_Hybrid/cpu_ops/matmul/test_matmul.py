from torch.utils.cpp_extension import load
import torch

# 1. 编译并加载扩展
custom_matmul = load(
    name="custom_matmul",
    sources=["matmul_sgemm.cpp"],
    extra_ldflags=["-ldnnl", "-mkl", "-lmkl_rt", "-mavx2", "-mfma", "-mavx512f", "-fopenmp"],
    verbose=True,
)

# 2. 测试函数
def test_custom_matmul():
    for has_scale in [False, True]:
        print(f"\n[TEST] With scale = {has_scale}")
        
        # 随机生成输入张量
        input = torch.randn(2, 4, 4, 16)
        weight = torch.randn(2, 4, 16, 32)
        scale = torch.tensor(0.5) if has_scale else None

        # 调用自定义算子
        out = custom_matmul.custom_matmul(input, weight, scale)

        # 与 PyTorch 的原始 matmul 结果对比
        expected = torch.matmul(input, weight)
        if has_scale:
            expected *= scale

        # 结果对比
        if torch.allclose(out, expected, atol=1e-6):
            print("  PASS: Results match.")
        else:
            print("  FAIL: Results do not match!")
            print("Custom output:\n", out)
            print("Expected output:\n", expected)

# 3. 执行测试
if __name__ == "__main__":
    test_custom_matmul()

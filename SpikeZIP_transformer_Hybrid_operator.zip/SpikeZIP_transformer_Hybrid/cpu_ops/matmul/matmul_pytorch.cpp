#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
torch::Tensor custom_matmul(
    const torch::Tensor& input,
    const torch::Tensor& weight,
    const c10::optional<torch::Tensor>& scale
) {
    // Call into ATen's native linear
    if (scale.has_value() && scale->defined()) {
        return at::matmul(input, weight) * scale.value();
    } else {
        return at::matmul(input, weight);
    }
}

// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_matmul(Tensor input, Tensor weight, Tensor? scale) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_matmul", TORCH_FN(custom_matmul));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_matmul", &custom_matmul,
          "customized matmul matching aten::matmul",
          py::arg("input"),
          py::arg("weight"),
          py::arg("scale") = c10::nullopt
    );
}

#include <torch/extension.h>
#include <c10/util/Optional.h>
#include <c10/core/SymInt.h>
#include <c10/util/ArrayRef.h>
#include <mkl.h>
#include <mkl_spblas.h>
#include <omp.h>

// Fully match aten::linear schema:
//   linear(Tensor input, Tensor weight, Tensor? bias=None) -> Tensor
torch::Tensor custom_matmul(
    const torch::Tensor& input,    // [B1, B2, M, K]
    const torch::Tensor& weight,   // [B1, B2, K, N]
    const c10::optional<torch::Tensor>& scale_opt
) {
    // 1) 类型与维度检查
    TORCH_CHECK(input.dtype() == torch::kFloat32 && weight.dtype() == torch::kFloat32,
                "custom_matmul_4d only supports float32");
    TORCH_CHECK(input.dim() == 4 && weight.dim() == 4,
                "custom_matmul_4d requires 4D input and weight");
    auto A = input;
    auto B = weight;

    // 2) 读取 scale
    float alpha = 1.0f, beta = 0.0f;
    if (scale_opt.has_value() && scale_opt->defined()) {
        TORCH_CHECK(scale_opt->numel() == 1, "scale must be a scalar");
        alpha = scale_opt->item<float>();
    }

    // 3) 确保行主序 contiguous
    if (!A.is_contiguous() || A.stride(3) != 1) A = A.contiguous();
    if (!B.is_contiguous() || B.stride(3) != 1) B = B.contiguous();

    // 4) 提取维度
    int64_t B1 = A.size(0), B2 = A.size(1), M = A.size(2), K = A.size(3);
    int64_t K2 = B.size(2), N = B.size(3);
    TORCH_CHECK(K == K2, "matmul shapes misaligned");

    // 5) 构建输出
    auto C = torch::empty({B1, B2, M, N}, A.options());

    // 6) 扁平化 batch，两级 batch 合并成一个
    int batch = (int)(B1 * B2);
    const float* A_ptr = A.data_ptr<float>();
    const float* B_ptr = B.data_ptr<float>();
    float*       C_ptr = C.data_ptr<float>();

    // 7) 构建指针数组
    std::vector<const float*> A_ptrs(batch), B_ptrs(batch);
    std::vector<float*>       C_ptrs(batch);
    for (int i = 0; i < batch; ++i) {
        A_ptrs[i] = A_ptr + (size_t)i * M * K;
        B_ptrs[i] = B_ptr + (size_t)i * K * N;
        C_ptrs[i] = C_ptr + (size_t)i * M * N;
    }

    // 8) 准备 batch GEMM 参数
    std::vector<CBLAS_TRANSPOSE> transA(batch, CblasNoTrans), transB(batch, CblasNoTrans);
    std::vector<int> ms(batch, M), ns(batch, N), ks(batch, K);
    std::vector<int> ldAs(batch, K), ldBs(batch, N), ldCs(batch, N);
    std::vector<float> alphas(batch, alpha), betas(batch, beta);
    int group_count = 1;
    std::vector<int> group_size = { batch };

    // 9) 调用 cblas_sgemm_batch
    cblas_sgemm_batch(
        CblasRowMajor,
        transA.data(), transB.data(),
        ms.data(), ns.data(), ks.data(),
        alphas.data(),
        A_ptrs.data(), ldAs.data(),
        B_ptrs.data(), ldBs.data(),
        betas.data(),
        C_ptrs.data(), ldCs.data(),
        group_count,
        group_size.data()
    );

    return C;
}
// Register schema in custom namespace
TORCH_LIBRARY_FRAGMENT(custom, m) {
    m.def("custom_matmul(Tensor input, Tensor weight, Tensor? scale) -> Tensor");
}

// Provide CPU backend implementation
TORCH_LIBRARY_IMPL(custom, CPU, m) {
    m.impl("custom_matmul", TORCH_FN(custom_matmul));
}

// Expose to Python via pybind11
PYBIND11_MODULE(TORCH_EXTENSION_NAME, m) {
    m.def("custom_matmul", &custom_matmul,
          "customized matmul matching aten::matmul",
          py::arg("input"),
          py::arg("weight"),
          py::arg("scale") = c10::nullopt
    );
}

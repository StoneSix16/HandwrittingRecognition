g++ -O3 -std=c++17 -mfma -mavx2 -pthread -funroll-loops -ffast-math \
    main.cpp MKL_Sparse_Methods.cpp custom_spmm_yk.cpp csr_builder.cpp tilling.cpp \
    -I${MKLROOT}/include \
    -L${MKLROOT}/lib/intel64 \
    -Wl,--no-as-needed \
    -lmkl_intel_lp64 -lmkl_core -lmkl_intel_thread \
    -liomp5 -lm -ldl -fopenmp \
    -o spmm_mkl_iomp

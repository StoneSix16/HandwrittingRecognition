sparsities=(0.5 0.75 0.9 0.95 0.98 0.99)

# Define matrix dimensions
dims_M=(197)
dims_N=(768 2304 3072)
dims_K=(768 2304 3072)
# Output log file
logfile="spmm_results.log"
: > "$logfile"  # truncate or create

# Iterate over all combinations
for s in "${sparsities[@]}"; do
    for M in "${dims_M[@]}"; do
        for N in "${dims_N[@]}"; do
            for K in "${dims_K[@]}"; do
                echo "Running: sparsity=$s, M=$M, N=$N, K=$K" | tee -a "$logfile"
                ./spmm_mkl_iomp "$s" "$M" "$N" "$K" 2>&1 | tee -a "$logfile"
            done
        done
    done
done

echo "All experiments completed. Results logged to $logfile." | tee -a "$logfile"
